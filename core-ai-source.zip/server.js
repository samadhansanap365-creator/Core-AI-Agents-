'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const Store = require('./lib/store');
const { id, nowIso, sha256, hashPassword, verifyPassword, slugify, truncate, readJsonBody, sendJson, sendCors } = require('./lib/util');
const { htmlToText, extractTitle, extractMetaDescription, tokenize, chunkText } = require('./lib/text');
const { fetchUrl, extractLinks } = require('./lib/crawl');
const { Index, synthesize } = require('./lib/retrieve');
const { chatCompletion } = require('./lib/llm');
const { executeWorkflow, runNode, nextCron } = require('./lib/engine');
const { encrypt, decrypt } = require('./lib/crypto');
const registry = require('./lib/registry');
const { plan: planWorkflow } = require('./lib/planner');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const PUBLIC_DIR = path.join(ROOT, 'public');
const PORT = process.env.PORT || 8080;

const store = new Store(DATA_DIR);
const index = new Index();

// ---------------------------------------------------------------------------
// Built-in knowledge (used for the public demo bot + quick-start source)
// ---------------------------------------------------------------------------
const CORE_KB = [
  ['What is Core AI?', 'Core AI is an AI customer-support platform that lets you build, train, and embed chatbots trained on your own content — your website, files, or pasted text. The bot answers visitor questions instantly, 24/7, in 95+ languages, and can capture leads and hand conversations to a human when needed.'],
  ['How does training work?', 'You add training sources in three ways: paste a website URL (Core AI crawls the pages and extracts the text), upload files (TXT, MD, CSV, HTML, JSON, XML, and text-based PDFs), or paste raw text. Core AI splits the content into chunks, indexes it, and uses it to answer questions with citations back to the source.'],
  ['How do I put the chatbot on my website?', 'Go to the Embed tab, copy the one-line snippet, and paste it before the closing </body> tag on any site. The chat widget inherits your bot\'s name, colors, logo, welcome message, and quick prompts automatically.'],
  ['Can the chatbot capture leads?', 'Yes. The widget can ask visitors for their email and name, and every captured lead is stored in the Leads tab where you can export it as CSV. You can also configure a webhook to push new leads to your own system in real time.'],
  ['Can it hand off to a human?', 'Yes. Visitors can tap "Talk to a human" at any time. The conversation appears in your Handoff queue, and when you reply from the dashboard your message is delivered back to the visitor inside the chat widget.'],
  ['What analytics are available?', 'The Analytics tab shows messages and conversations over time, unique visitors, captured leads, escalation rate, and positive/negative feedback — all computed from your real conversations.'],
  ['Is there an API?', 'Yes. Generate an API key in Settings and use the REST API (api/v1) to create chatbots, chat programmatically, list conversations, and trigger retraining. The embed snippet and the webhook work without any API key.'],
  ['What does the free plan include?', 'Every new account starts on a 7-day free trial of the Growth plan with one chatbot. You can train it on up to 1,000 pages, chat with it in the Playground, embed it, and review conversations, leads, and analytics.'],
  ['How is my data handled?', 'Your training content and conversations are stored in your own workspace and are never used to train shared models. Password hashes are salted with scrypt, and the embed widget communicates over HTTPS with CORS enabled.'],
  ['How do I retrain or refresh the knowledge?', 'From the Training tab you can refresh any URL source to re-crawl it, re-upload files, edit pasted text, or hit Retrain to rebuild the index from all current sources.'],
  ['Which languages are supported?', 'The chatbot reads and answers in the visitor\'s language by matching your content — so as long as your training data covers a language, the bot can respond in it.'],
  ['What can I customize?', 'You can set the bot\'s name, welcome message, placeholder text, primary color, logo (emoji or image), personality/system prompt, quick prompts, and tone. Everything updates in the preview and the embed instantly.'],
];

function ensureDemo() {
  let demoUser = null;
  for (const u of Object.values(store.all('users'))) {
    if (u.email === 'demo@coreai.app') { demoUser = u; break; }
  }
  if (!demoUser) {
    const { salt, hash } = hashPassword('demo-pass-1234');
    demoUser = { id: 'user_demo', name: 'Core AI', email: 'demo@coreai.app', salt, hash, plan: 'Growth', trialEndsAt: null, createdAt: nowIso(), apiKeys: [], llm: { baseUrl: '', apiKey: '', model: '' } };
    store.set('users', demoUser.id, demoUser);
  }
  let bot = null;
  for (const b of Object.values(store.all('chatbots'))) {
    if (b.id === 'demo') { bot = b; break; }
  }
  if (!bot) {
    bot = {
      id: 'demo', userId: demoUser.id, name: 'Core AI Assistant',
      welcomeMessage: "Hi there! 👋 I'm the Core AI assistant. Ask me anything about Core AI — pricing, training, embedding, or anything else.",
      placeholder: 'Ask me anything about Core AI…',
      primaryColor: '#6366f1', logo: '✦', position: 'bottom-right',
      personality: 'You are the friendly Core AI assistant. Answer from the provided knowledge. Keep replies short, warm, and helpful. If you do not know, say so and offer to connect the visitor with a human.',
      quickPrompts: ['What is Core AI?', 'How does training work?', 'How do I embed the chatbot?', 'Can it capture leads?'],
      model: 'balanced', enabled: true, webhookUrl: '', createdAt: nowIso(), updatedAt: nowIso(),
      training: { sourcesCount: 0, chunksCount: 0, lastTrainedAt: null },
    };
    store.set('chatbots', bot.id, bot);
  }
  // seed sources if none
  const existing = Object.values(store.all('sources')).filter((s) => s.chatbotId === 'demo');
  if (existing.length === 0) {
    const text = CORE_KB.map(([q, a]) => q + '\n' + a).join('\n\n');
    const source = {
      id: id('src_'), chatbotId: 'demo', type: 'text', title: 'Core AI knowledge base',
      url: null, content: text, status: 'ready', chars: text.length, chunks: 0,
      addedAt: nowIso(), refreshedAt: nowIso(), error: null,
    };
    store.set('sources', source.id, source);
    // one chunk per Q&A entry for precise answers
    CORE_KB.forEach(([q, a], i) => {
      const ch = { id: id('chk_'), chatbotId: 'demo', sourceId: source.id, index: i, text: q + ' ' + a };
      store.set('chunks', ch.id, ch);
    });
    source.chunks = CORE_KB.length;
    source.refreshedAt = nowIso();
    store.set('sources', source.id, source);
    updateTrainingMeta('demo');
  }
  rebuildIndex('demo');
}

// ---------------------------------------------------------------------------
// Ingestion helpers
// ---------------------------------------------------------------------------
function ingestSource(sourceId) {
  const source = store.get('sources', sourceId);
  if (!source) return;
  // remove old chunks
  for (const ch of Object.values(store.all('chunks'))) {
    if (ch.sourceId === sourceId) store.del('chunks', ch.id);
  }
  const chunks = chunkText(source.content || '');
  const created = [];
  chunks.forEach((text, i) => {
    const ch = { id: id('chk_'), chatbotId: source.chatbotId, sourceId: source.id, index: i, text };
    store.set('chunks', ch.id, ch);
    created.push(ch.id);
  });
  source.chunks = chunks.length;
  source.status = chunks.length ? 'ready' : 'empty';
  source.refreshedAt = nowIso();
  store.set('sources', source.id, source);
  updateTrainingMeta(source.chatbotId);
  rebuildIndex(source.chatbotId);
}

function removeSource(sourceId) {
  const source = store.get('sources', sourceId);
  if (!source) return;
  for (const ch of Object.values(store.all('chunks'))) {
    if (ch.sourceId === sourceId) store.del('chunks', ch.id);
  }
  store.del('sources', sourceId);
  updateTrainingMeta(source.chatbotId);
  rebuildIndex(source.chatbotId);
}

function updateTrainingMeta(chatbotId) {
  const bot = store.get('chatbots', chatbotId);
  if (!bot) return;
  const sources = Object.values(store.all('sources')).filter((s) => s.chatbotId === chatbotId);
  const chunks = Object.values(store.all('chunks')).filter((c) => c.chatbotId === chatbotId);
  bot.training = { sourcesCount: sources.length, chunksCount: chunks.length, lastTrainedAt: nowIso() };
  bot.updatedAt = nowIso();
  store.set('chatbots', chatbotId, bot);
}

function rebuildIndex(chatbotId) {
  const chunks = Object.values(store.all('chunks')).filter((c) => c.chatbotId === chatbotId);
  const sources = store.all('sources');
  index.build(chatbotId, chunks, sources);
}

function initIndexes() {
  for (const bot of Object.values(store.all('chatbots'))) rebuildIndex(bot.id);
}

// ---------------------------------------------------------------------------
// Conversations & chat
// ---------------------------------------------------------------------------
function getOrCreateConversation(chatbotId, visitorId, channel, visitorMeta = {}) {
  let conv = null;
  for (const c of Object.values(store.all('conversations'))) {
    if (c.chatbotId === chatbotId && c.visitorId === visitorId && c.channel === channel && !c.resolved) { conv = c; break; }
  }
  if (!conv) {
    conv = {
      id: id('conv_'), chatbotId, visitorId, channel,
      visitorEmail: visitorMeta.email || null, visitorName: visitorMeta.name || null,
      startedAt: nowIso(), lastMessageAt: nowIso(), messages: [],
      escalated: false, handoff: null, agentJoined: false, resolved: false, sample: false,
    };
    store.set('conversations', conv.id, conv);
  }
  return conv;
}

function generateReply({ chatbotId, message }) {
  const bot = store.get('chatbots', chatbotId);
  if (!bot) return { text: 'This assistant is not available.', mode: 'none' };
  const qna = Object.values(store.all('qna')).filter((q) => q.chatbotId === chatbotId);
  const user = store.get('users', bot.userId);
  const llmCfg = user && user.llm && user.llm.apiKey ? user.llm : null;

  const synth = synthesize({ chatbotId, query: message, index, qna });

  if (synth.mode === 'qa') {
    return { text: synth.text, sources: null, mode: 'qa' };
  }
  if (synth.mode === 'retrieval') {
    if (llmCfg) {
      // async LLM enhancement handled by caller; here we return retrieval baseline
      return { text: synth.text, sources: synth.sources, mode: 'retrieval', retrievalText: synth.text, retrievalSources: synth.sources };
    }
    return { text: synth.text, sources: synth.sources, mode: 'retrieval' };
  }
  return { text: null, mode: 'none' };
}

const FALLBACKS = [
  "I couldn't find that in my knowledge base yet. Try rephrasing the question, or tap \"Talk to a human\" and I'll connect you with the team.",
  "Hmm, I don't have a confident answer for that from my training content. Could you rephrase it? A human can also jump in if you'd like.",
  "That one's outside what I've been trained on. If you leave your email or tap \"Talk to a human\", someone from the team will follow up shortly.",
];

async function answerMessage({ chatbotId, message, conv }) {
  const bot = store.get('chatbots', chatbotId);
  const result = generateReply({ chatbotId, message });

  // greeting intent
  const t = message.toLowerCase().trim().replace(/[^a-z ]/g, ' ');
  const isGreeting = /^(hi|hello|hey|hiya|howdy|good (morning|afternoon|evening)|yo|sup)\b/.test(t) && t.split(' ').length <= 3;
  const asksHuman = /(human|agent|person|representative|support team|talk to (a |someone|somebody)|speak to)/.test(t);
  const asksEmail = /(email|contact|reach|follow ?up|call me|callback)/.test(t);

  if (asksHuman && result.mode === 'none') {
    return { text: "No problem — I've flagged this for a human. If you leave your email, the team will get back to you shortly. You can also tap \"Talk to a human\" below.", mode: 'handoff-hint', sources: null };
  }
  if (isGreeting && result.mode === 'none') {
    return { text: "Hi! 👋 I'm " + bot.name + ". " + (bot.welcomeMessage ? '' : '') + "Ask me anything — I'll pull answers from what I've been trained on.", mode: 'greeting', sources: null };
  }

  if (result.mode === 'retrieval' && result.retrievalText && bot.userId) {
    const user = store.get('users', bot.userId);
    if (user && user.llm && user.llm.apiKey) {
      const context = (result.retrievalSources || []).map((s) => '- ' + s.title + ': ' + s.text).join('\n\n');
      const system = (bot.personality || 'Answer helpfully from the provided context only.') +
        '\n\nCONTEXT (from training data):\n' + truncate(context, 6000) +
        '\n\nIf the context does not contain the answer, say you do not know and suggest contacting support. Keep answers under 120 words.';
      const llmText = await chatCompletion({ baseUrl: user.llm.baseUrl, apiKey: user.llm.apiKey, model: user.llm.model, system, user: message });
      if (llmText) {
        return { text: llmText, sources: result.retrievalSources, mode: 'llm' };
      }
    }
    return result;
  }
  if (result.mode === 'none') {
    if (asksEmail) {
      return { text: "I'd be happy to connect you with the team! Leave your email below and someone will follow up — or tap \"Talk to a human\" for immediate handoff.", mode: 'lead-hint', sources: null };
    }
    return { text: FALLBACKS[Math.floor(Math.random() * FALLBACKS.length)], mode: 'fallback', sources: null };
  }
  return result;
}

// ---------------------------------------------------------------------------
// PDF text extraction (naive, text-based PDFs only)
// ---------------------------------------------------------------------------
function extractPdfText(buf) {
  const s = buf.toString('latin1');
  const texts = [];
  const streamRe = /stream\r?\n([\s\S]*?)endstream/g;
  let m;
  while ((m = streamRe.exec(s)) !== null) {
    let data = m[1];
    try {
      data = require('zlib').inflateSync(Buffer.from(data, 'latin1')).toString('latin1');
    } catch (e) { /* not flate — try raw */ }
    // extract text-showing operators
    const tjRe = /\((?:[^()\\]|\\.)*\)\s*Tj/g;
    let tj;
    let out = '';
    while ((tj = tjRe.exec(data)) !== null) {
      out += tj[0].replace(/\)\s*Tj$/, '').slice(1) + ' ';
    }
    const tjArrRe = /\[((?:\([^)]*\)|[-0-9. ]+)+)\]\s*TJ/g;
    while ((tj = tjArrRe.exec(data)) !== null) {
      const inner = tj[1].replace(/\(([^)]*)\)/g, '$1 ').replace(/[-0-9. ]+/g, ' ');
      out += inner;
    }
    out = out.replace(/\\\(/g, '(').replace(/\\\)/g, ')').replace(/\\\\/g, '\\').replace(/\\n/g, ' ');
    if (out.trim().length > 20) texts.push(out);
  }
  const joined = texts.join(' ').replace(/[ \t]+/g, ' ').trim();
  return joined;
}

// ---------------------------------------------------------------------------
// Auth helpers
// ---------------------------------------------------------------------------
function authInfo(req) {
  const h = req.headers['authorization'] || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  let token = m ? m[1] : (req.headers['x-session'] || '');
  let via = m ? 'Authorization' : (token ? 'x-session' : 'none');
  // Cookie fallback: some proxies drop custom headers, so also accept the
  // session token from a same-origin cookie (set by the client on sign-in).
  if (!token && req.headers.cookie) {
    const cm = String(req.headers.cookie).match(/(?:^|;\s*)coreai_token=([^;\s]+)/);
    if (cm) { token = decodeURIComponent(cm[1]); via = 'cookie'; }
  }
  // Query-param fallback: some sandboxed preview iframes block cookies and
  // storage AND proxies may strip Authorization/x-session, so the client can
  // carry the token on the URL as a last resort.
  if (!token) {
    try {
      const q = new URL(req.url, 'http://local').searchParams.get('tok');
      if (q) { token = q; via = 'query'; }
    } catch (e) {}
  }
  if (!token) return { user: null, via };
  const session = store.get('sessions', token);
  if (!session) return { user: null, via: via + '+bad-session' };
  return { user: store.get('users', session.userId) || null, via };
}
function userFromReq(req) {
  return authInfo(req).user;
}

function requireUser(req, res) {
  const user = userFromReq(req);
  if (!user) { sendJson(res, 401, { error: 'unauthorized' }); return null; }
  return user;
}

function botForUser(user, botId) {
  const bot = store.get('chatbots', botId);
  if (!bot || bot.userId !== user.id) return null;
  return bot;
}

function publicBot(botId) {
  const bot = store.get('chatbots', botId);
  if (!bot) return null;
  return bot;
}

// ---------------------------------------------------------------------------
// Analytics (computed from real conversations)
// ---------------------------------------------------------------------------
function dateKey(ts) {
  const d = new Date(ts);
  const y = d.getFullYear();
  const mo = String(d.getMonth() + 1).padStart(2, '0');
  const da = String(d.getDate()).padStart(2, '0');
  return y + '-' + mo + '-' + da;
}

function computeAnalytics(chatbotId) {
  const convs = Object.values(store.all('conversations')).filter((c) => c.chatbotId === chatbotId && c.channel !== 'playground');
  const leads = Object.values(store.all('leads')).filter((l) => l.chatbotId === chatbotId);
  const days = {};
  let totalMessages = 0, upvotes = 0, downvotes = 0, escalated = 0, resolved = 0;
  const visitors = new Set();
  const sourceHits = {};
  for (const c of convs) {
    visitors.add(c.visitorId);
    if (c.escalated) escalated++;
    if (c.resolved) resolved++;
    for (const msg of c.messages) {
      totalMessages++;
      const dk = dateKey(msg.ts);
      days[dk] = days[dk] || { messages: 0, conversations: new Set() };
      days[dk].messages++;
      days[dk].conversations.add(c.id);
      if (msg.rating === 'up') upvotes++;
      if (msg.rating === 'down') downvotes++;
      if (msg.sources) for (const s of msg.sources) sourceHits[s.title] = (sourceHits[s.title] || 0) + 1;
    }
  }
  const leadsByDay = {};
  for (const l of leads) {
    const dk = dateKey(l.capturedAt);
    leadsByDay[dk] = (leadsByDay[dk] || 0) + 1;
  }
  // last 30 days series
  const series = [];
  const today = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - i);
    const dk = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const cell = days[dk];
    series.push({
      date: dk,
      label: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      messages: cell ? cell.messages : 0,
      conversations: cell ? cell.conversations.size : 0,
      leads: leadsByDay[dk] || 0,
    });
  }
  const avgPerConv = convs.length ? Math.round((totalMessages / convs.length) * 10) / 10 : 0;
  const topSources = Object.entries(sourceHits).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([title, count]) => ({ title, count }));
  return {
    totals: {
      conversations: convs.length,
      messages: totalMessages,
      uniqueVisitors: visitors.size,
      leads: leads.length,
      escalated,
      resolved,
      upvotes,
      downvotes,
      avgPerConv,
    },
    series,
    topSources,
    recent: convs.sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt)).slice(0, 8).map(summarizeConv),
  };
}

function summarizeConv(c) {
  const last = c.messages[c.messages.length - 1];
  return {
    id: c.id, visitorId: c.visitorId, visitorEmail: c.visitorEmail, visitorName: c.visitorName,
    startedAt: c.startedAt, lastMessageAt: c.lastMessageAt,
    messageCount: c.messages.length, escalated: c.escalated, resolved: c.resolved, sample: c.sample,
    lastPreview: last ? truncate(last.text, 90) : '', lastRole: last ? last.role : null,
  };
}

// ---------------------------------------------------------------------------
// Webhook (fire-and-forget)
// ---------------------------------------------------------------------------
function fireWebhook(url, payload) {
  if (!url) return;
  try {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? require('https') : require('http');
    const body = JSON.stringify(payload);
    const req = lib.request(u, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } }, () => {});
    req.setTimeout(5000, () => req.destroy());
    req.on('error', () => {});
    req.write(body);
    req.end();
  } catch (e) { /* ignore */ }
}

// ---------------------------------------------------------------------------
// Sample data
// ---------------------------------------------------------------------------
const SAMPLE_QUESTIONS = [
  'What is this assistant trained on?', 'How does training work?', 'How do I embed the chatbot?',
  'Can it capture leads?', 'What analytics are available?', 'Is there an API?',
  'Which languages are supported?', 'How do I retrain the knowledge?', 'What can I customize?',
  'Can it hand off to a human?', 'What does the free plan include?', 'How is my data handled?',
];
const SAMPLE_NAMES = ['Aisha', 'Rohan', 'Priya', 'David', 'Mei', 'Carlos', 'Sara', 'Tom', 'Nina', 'Omar', 'Lena', 'Kiran'];
const SAMPLE_EMAILS = ['aisha@example.com', 'rohan@example.com', 'priya@example.com', 'david@example.com', 'mei@example.com', 'carlos@example.com'];

function loadSampleData(chatbotId) {
  const bot = store.get('chatbots', chatbotId);
  if (!bot) return 0;
  const today = new Date();
  let created = 0;
  for (let i = 29; i >= 0; i--) {
    const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - i);
    const n = (i % 3 === 0) ? 2 : 1; // 1-2 convs/day
    for (let k = 0; k < n; k++) {
      const visitorId = id('vis_');
      const conv = getOrCreateConversation(chatbotId, visitorId, 'web');
      conv.sample = true;
      conv.startedAt = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 9 + (k * 4), 12).toISOString();
      const q = SAMPLE_QUESTIONS[(created + k) % SAMPLE_QUESTIONS.length];
      const a = generateReply({ chatbotId, message: q });
      const answerText = a.text || 'I couldn\'t find that in my knowledge base yet — a human can help.';
      conv.messages.push({ role: 'user', text: q, ts: conv.startedAt });
      conv.messages.push({ role: 'bot', text: truncate(answerText, 400), ts: new Date(new Date(conv.startedAt).getTime() + 4000).toISOString(), mode: a.mode || 'retrieval', sources: a.sources || null, rating: Math.random() > 0.3 ? 'up' : null });
      conv.lastMessageAt = new Date(new Date(conv.startedAt).getTime() + 4000).toISOString();
      // some escalate / leads
      if (created % 7 === 0) {
        conv.escalated = true; conv.handoff = { requestedAt: conv.lastMessageAt, note: 'Wanted a callback' };
        if (created % 14 === 0) conv.resolved = true;
      }
      if (created % 3 === 0) {
        const lead = { id: id('lead_'), chatbotId, email: SAMPLE_EMAILS[created % SAMPLE_EMAILS.length], name: SAMPLE_NAMES[created % SAMPLE_NAMES.length], phone: null, source: 'chat-widget', conversationId: conv.id, capturedAt: conv.lastMessageAt };
        store.set('leads', lead.id, lead);
        conv.visitorEmail = lead.email; conv.visitorName = lead.name;
      }
      store.set('conversations', conv.id, conv);
      created++;
    }
  }
  return created;
}

function clearSampleData(chatbotId) {
  let removed = 0;
  for (const c of Object.values(store.all('conversations'))) {
    if (c.chatbotId === chatbotId && c.sample) { store.del('conversations', c.id); removed++; }
  }
  return removed;
}

// ---------------------------------------------------------------------------
// MIME map
// ---------------------------------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.md': 'text/markdown; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8', '.csv': 'text/csv; charset=utf-8', '.map': 'application/json', '.pdf': 'application/pdf',
};

function serveStatic(req, res, pathname) {
  if (pathname === '/' ) pathname = '/index.html';
  if (pathname === '/app' || pathname === '/app/') pathname = '/app.html';
  if (pathname === '/studio' || pathname === '/studio/') pathname = '/studio.html';
  if (pathname === '/widget.js') {
    const file = path.join(PUBLIC_DIR, 'widget.js');
    if (!fs.existsSync(file)) { sendJson(res, 404, { error: 'not_found' }); return; }
    const body = fs.readFileSync(file);
    sendCors(res, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache' });
    res.end(body);
    return;
  }
  let file = path.join(PUBLIC_DIR, path.normalize(pathname).replace(/^(\.\.(\/|\\|$))+/, ''));
  if (!file.startsWith(PUBLIC_DIR)) { sendJson(res, 403, { error: 'forbidden' }); return; }
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
  if (!fs.existsSync(file)) {
    // SPA fallback to index.html for unknown routes (except /api)
    if (pathname.startsWith('/api')) { sendJson(res, 404, { error: 'not_found' }); return; }
    file = path.join(PUBLIC_DIR, 'index.html');
  }
  if (!fs.existsSync(file)) { sendJson(res, 404, { error: 'not_found' }); return; }
  const ext = path.extname(file).toLowerCase();
  const cacheCtl = (ext === '.html' || ext === '.js' || ext === '.css') ? 'no-store' : 'public, max-age=300';
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cacheCtl });
  const stream = fs.createReadStream(file);
  stream.on('error', () => { if (!res.headersSent) sendJson(res, 500, { error: 'read_error' }); else res.destroy(); });
  stream.pipe(res);
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
const routes = [];

function route(method, pattern, handler) {
  routes.push({ method, pattern, handler });
}

function matchRoute(method, pathname) {
  for (const r of routes) {
    if (r.method !== method) continue;
    const m = pathname.match(r.pattern);
    if (m) return { handler: r.handler, params: m.slice(1) };
  }
  return null;
}

// ---- public (no auth) ----
route('GET', /^\/api\/health$/, (req, res) => sendJson(res, 200, { ok: true, time: nowIso() }));

route('POST', /^\/api\/auth\/signup$/, async (req, res) => {
  const body = await readJsonBody(req);
  const email = String(body.email || '').toLowerCase().trim();
  const password = String(body.password || '');
  const name = String(body.name || '').trim() || email.split('@')[0];
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return sendJson(res, 400, { error: 'Please enter a valid email address.' });
  if (password.length < 8) return sendJson(res, 400, { error: 'Password must be at least 8 characters.' });
  for (const u of Object.values(store.all('users'))) if (u.email === email) return sendJson(res, 409, { error: 'An account with this email already exists. Try signing in.' });
  const { salt, hash } = hashPassword(password);
  const user = { id: id('user_'), name, email, salt, hash, plan: 'Growth', createdAt: nowIso(), apiKeys: [], llm: { baseUrl: '', apiKey: '', model: 'gpt-4o-mini' } };
  store.set('users', user.id, user);
  onboardUser(user.id);
  const token = id('tok_');
  store.set('sessions', token, { userId: user.id, createdAt: nowIso() });
  sendJson(res, 201, { token, user: publicUser(user) });
});

route('POST', /^\/api\/auth\/login$/, async (req, res) => {
  const body = await readJsonBody(req);
  const email = String(body.email || '').toLowerCase().trim();
  const password = String(body.password || '');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return sendJson(res, 400, { error: 'Please enter a valid email address.' });
  let user = null;
  for (const u of Object.values(store.all('users'))) if (u.email === email) { user = u; break; }
  if (!user) {
    // Any email can sign in: auto-provision an account on first sign-in.
    const pw = password.length >= 8 ? password : 'auto-' + id('p');
    const { salt, hash } = hashPassword(pw);
    user = { id: id('user_'), name: email.split('@')[0], email, salt, hash, plan: 'Growth', createdAt: nowIso(), apiKeys: [], llm: { baseUrl: '', apiKey: '', model: 'gpt-4o-mini' } };
    store.set('users', user.id, user);
    onboardUser(user.id);
  } else if (!verifyPassword(password, user.salt, user.hash)) {
    return sendJson(res, 401, { error: 'Invalid password for this account.' });
  }
  const token = id('tok_');
  store.set('sessions', token, { userId: user.id, createdAt: nowIso() });
  sendJson(res, 200, { token, user: publicUser(user) });
});

// No-credentials entry: auto-provision (or resume) a guest workspace. The
// client sends a stable guestId (kept in localStorage) so the same browser
// always lands in the same workspace and work persists across visits.
route('POST', /^\/api\/auth\/guest$/, async (req, res) => {
  const body = await readJsonBody(req);
  const guestId = String(body.guestId || '').slice(0, 80);
  let user = null;
  if (guestId) {
    for (const u of Object.values(store.all('users'))) if (u.guestId === guestId) { user = u; break; }
  }
  if (!user) {
    const gid = guestId || id('g_');
    user = {
      id: id('user_'), name: 'Guest', email: 'guest-' + gid.slice(0, 16) + '@coreai.app',
      guestId: gid, salt: '', hash: '', plan: 'Growth', createdAt: nowIso(),
      apiKeys: [], llm: { baseUrl: '', apiKey: '', model: 'gpt-4o-mini' },
    };
    store.set('users', user.id, user);
    onboardUser(user.id);
  }
  const token = id('tok_');
  store.set('sessions', token, { userId: user.id, createdAt: nowIso() });
  sendJson(res, 200, { token, user: publicUser(user) });
});

route('POST', /^\/api\/auth\/logout$/, async (req, res) => {
  const h = req.headers['authorization'] || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  if (m) store.del('sessions', m[1]);
  sendJson(res, 200, { ok: true });
});

// ---- account ----
route('GET', /^\/api\/me$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  sendJson(res, 200, { user: publicUser(user) });
});

route('PATCH', /^\/api\/me$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  if (body.name !== undefined) user.name = String(body.name).slice(0, 80);
  if (body.llm !== undefined) user.llm = { baseUrl: String(body.llm.baseUrl || ''), apiKey: String(body.llm.apiKey || ''), model: String(body.llm.model || 'gpt-4o-mini') };
  store.set('users', user.id, user);
  sendJson(res, 200, { user: publicUser(user) });
});

route('POST', /^\/api\/account\/llm-test$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const cfg = { baseUrl: body.baseUrl, apiKey: body.apiKey, model: body.model };
  const out = await chatCompletion({ ...cfg, system: 'Reply with exactly: OK', user: 'ping' });
  sendJson(res, 200, { ok: !!out, sample: out ? truncate(out, 120) : null });
});

// ---- registry (AI providers / models / integrations / agents) ----
route('GET', /^\/api\/registry$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  sendJson(res, 200, registry.publicRegistry(user));
});

// ---- credentials (encrypted at rest) ----
function maskedSecret(v) {
  if (!v) return null;
  const s = String(v);
  return s.length <= 4 ? '••••' : '••••' + s.slice(-4);
}
function maskedCredential(c) {
  let decrypted = {};
  try { decrypted = JSON.parse(decrypt(c.enc) || '{}'); } catch (e) {}
  const fields = {};
  for (const k of Object.keys(decrypted)) fields[k] = maskedSecret(decrypted[k]);
  return { id: c.id, name: c.name, type: c.type, provider: c.provider, fields, createdAt: c.createdAt, updatedAt: c.updatedAt };
}
function credentialForUser(user, credId) {
  const c = store.get('credentials', credId);
  if (!c || c.userId !== user.id) return null;
  let fields = {};
  try { fields = JSON.parse(decrypt(c.enc) || '{}'); } catch (e) { fields = {}; }
  return { id: c.id, name: c.name, type: c.type, provider: c.provider, fields };
}

route('GET', /^\/api\/credentials$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const list = Object.values(store.all('credentials')).filter((c) => c.userId === user.id)
    .map(maskedCredential).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  sendJson(res, 200, { credentials: list });
});

route('POST', /^\/api\/credentials$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const name = String(body.name || '').slice(0, 80);
  if (!name) return sendJson(res, 400, { error: 'Give the credential a name.' });
  const type = String(body.type || 'apiKey');
  const provider = String(body.provider || '');
  const fields = body.fields && typeof body.fields === 'object' ? body.fields : {};
  // Never accept a raw secret from anywhere other than the fields map, and
  // store it encrypted. Nothing in plaintext hits the DB.
  const c = {
    id: id('cred_'), userId: user.id, name, type, provider,
    enc: encrypt(JSON.stringify(fields)),
    createdAt: nowIso(), updatedAt: nowIso(),
  };
  store.set('credentials', c.id, c);
  sendJson(res, 201, { credential: maskedCredential(c) });
});

route('PATCH', /^\/api\/credentials\/([^/]+)$/, async (req, res, credId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const c = store.get('credentials', credId);
  if (!c || c.userId !== user.id) return sendJson(res, 404, { error: 'not_found' });
  const body = await readJsonBody(req);
  if (body.name !== undefined) c.name = String(body.name).slice(0, 80);
  if (body.fields && typeof body.fields === 'object') c.enc = encrypt(JSON.stringify(body.fields));
  c.updatedAt = nowIso();
  store.set('credentials', c.id, c);
  sendJson(res, 200, { credential: maskedCredential(c) });
});

route('DELETE', /^\/api\/credentials\/([^/]+)$/, (req, res, credId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const c = store.get('credentials', credId);
  if (!c || c.userId !== user.id) return sendJson(res, 404, { error: 'not_found' });
  store.del('credentials', credId);
  sendJson(res, 200, { ok: true });
});

// ---- favorites & recently used (per user) ----
function userList(collection, userId) {
  return store.get(collection, userId) || { items: [] };
}
route('GET', /^\/api\/favorites$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  sendJson(res, 200, { items: userList('favorites', user.id).items });
});
route('POST', /^\/api\/favorites$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const rec = userList('favorites', user.id);
  if (!rec.items.some((i) => i.kind === body.kind && i.ref === body.ref)) {
    rec.items.unshift({ kind: body.kind, ref: body.ref, label: body.label || '', at: nowIso() });
    store.set('favorites', user.id, rec);
  }
  sendJson(res, 200, { items: rec.items });
});
route('DELETE', /^\/api\/favorites$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const q = new URL(req.url, 'http://local').searchParams;
  const rec = userList('favorites', user.id);
  rec.items = rec.items.filter((i) => !(i.kind === q.get('kind') && i.ref === q.get('ref')));
  store.set('favorites', user.id, rec);
  sendJson(res, 200, { items: rec.items });
});
route('GET', /^\/api\/recent$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  sendJson(res, 200, { items: userList('recent', user.id).items });
});
route('POST', /^\/api\/recent$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const rec = userList('recent', user.id);
  rec.items = rec.items.filter((i) => !(i.kind === body.kind && i.ref === body.ref));
  rec.items.unshift({ kind: body.kind, ref: body.ref, label: body.label || '', at: nowIso() });
  rec.items = rec.items.slice(0, 20);
  store.set('recent', user.id, rec);
  sendJson(res, 200, { items: rec.items });
});

// ---- Build with AI (deterministic planner; LLM-assisted name when key set) ----
route('POST', /^\/api\/ai\/build$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const prompt = String(body.prompt || '').slice(0, 2000);
  if (!prompt) return sendJson(res, 400, { error: 'Describe the workflow you want to build.' });
  const p = planWorkflow(prompt);
  // If a workspace LLM key is configured, let the model suggest a nicer name
  // (best-effort — the deterministic plan is authoritative either way).
  if (user.llm && user.llm.apiKey && user.llm.model) {
    const name = await chatCompletion({ baseUrl: user.llm.baseUrl, apiKey: user.llm.apiKey, model: user.llm.model, system: 'You name workflows. Reply with a short 2-5 word workflow name only, no punctuation.', user: prompt, timeoutMs: 8000 });
    if (name) p.name = String(name).slice(0, 60);
  }
  sendJson(res, 200, { plan: p, planner: user.llm && user.llm.apiKey ? 'llm-assisted' : 'deterministic' });
});

// ---- templates ----
route('GET', /^\/api\/templates$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const list = Object.values(store.all('templates')).filter((t) => t.userId === user.id)
    .map((t) => ({ id: t.id, name: t.name, description: t.description || '', nodeCount: (t.workflow && t.workflow.nodes || []).length, createdAt: t.createdAt }))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  sendJson(res, 200, { templates: list });
});
route('POST', /^\/api\/templates$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const t = {
    id: id('tpl_'), userId: user.id,
    name: String(body.name || 'Untitled template').slice(0, 80),
    description: String(body.description || '').slice(0, 240),
    workflow: body.workflow || { nodes: [], connections: [], settings: {} },
    createdAt: nowIso(),
  };
  store.set('templates', t.id, t);
  sendJson(res, 201, { template: { id: t.id, name: t.name, description: t.description, nodeCount: t.workflow.nodes.length, createdAt: t.createdAt } });
});
route('GET', /^\/api\/templates\/([^/]+)$/, (req, res, tplId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const t = store.get('templates', tplId);
  if (!t || t.userId !== user.id) return sendJson(res, 404, { error: 'not_found' });
  sendJson(res, 200, { template: t });
});

route('DELETE', /^\/api\/templates\/([^/]+)$/, (req, res, tplId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const t = store.get('templates', tplId);
  if (!t || t.userId !== user.id) return sendJson(res, 404, { error: 'not_found' });
  store.del('templates', tplId);
  sendJson(res, 200, { ok: true });
});

// ---- workflows ----
function workflowForUser(user, wfId) {
  const wf = store.get('workflows', wfId);
  if (!wf || wf.userId !== user.id) return null;
  return wf;
}

function summarizeWorkflow(wf) {
  const execs = Object.values(store.all('executions')).filter((e) => e.workflowId === wf.id);
  const last = execs.sort((a, b) => b.startedAt.localeCompare(a.startedAt))[0] || null;
  return {
    id: wf.id, name: wf.name, description: wf.description || '',
    active: !!wf.active, nodeCount: (wf.nodes || []).length,
    createdAt: wf.createdAt, updatedAt: wf.updatedAt,
    schedule: wf.schedule || null,
    lastStatus: last ? last.status : null, lastRunAt: last ? last.finishedAt || last.startedAt : null,
    executionCount: execs.length,
  };
}

function searchKnowledgeForUser(user, question, k) {
  const bots = Object.values(store.all('chatbots')).filter((b) => b.userId === user.id);
  const out = [];
  for (const b of bots) {
    const res = index.search(b.id, question, k);
    for (const r of res) out.push({ title: r.title, text: r.text, score: r.score, bot: b.name });
  }
  out.sort((a, b) => b.score - a.score);
  return out.slice(0, k);
}

function onboardWorkflow(userId) {
  const wf = {
    id: id('wf_'), userId, name: 'My First Workflow',
    description: 'A simple starter workflow: a manual trigger feeds an AI Agent.',
    active: false,
    nodes: [
      { id: id('nd_'), type: 'trigger.manual', name: 'Manual Trigger', position: { x: 60, y: 200 }, parameters: { initialData: '{"topic": "Core AI"}' } },
      { id: id('nd_'), type: 'ai.agent', name: 'AI Agent', position: { x: 380, y: 200 }, parameters: { system: 'You are a helpful Core AI agent.', prompt: 'Write a short, friendly welcome message about {{ $json.topic }}.' } },
    ],
    connections: [],
    settings: { env: {}, webhookSecret: '' },
    createdAt: nowIso(), updatedAt: nowIso(),
  };
  wf.connections.push({ from: wf.nodes[0].id, out: 'main', to: wf.nodes[1].id, in: 0 });
  store.set('workflows', wf.id, wf);
  return wf;
}

route('GET', /^\/api\/workflows$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const wfs = Object.values(store.all('workflows')).filter((w) => w.userId === user.id)
    .map(summarizeWorkflow).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  sendJson(res, 200, { workflows: wfs });
});

route('POST', /^\/api\/workflows$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const name = String(body.name || 'Untitled workflow').slice(0, 80);
  const wf = {
    id: id('wf_'), userId: user.id, name, description: String(body.description || '').slice(0, 240),
    active: false, specification: '',
    nodes: [{ id: id('nd_'), type: 'trigger.manual', name: 'Manual Trigger', position: { x: 60, y: 200 }, parameters: {} }],
    connections: [], settings: { env: {}, webhookSecret: '' },
    createdAt: nowIso(), updatedAt: nowIso(),
  };
  store.set('workflows', wf.id, wf);
  sendJson(res, 201, { workflow: wf });
});

route('GET', /^\/api\/workflows\/([^/]+)$/, (req, res, wfId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const wf = workflowForUser(user, wfId);
  if (!wf) return sendJson(res, 404, { error: 'not_found' });
  sendJson(res, 200, { workflow: wf });
});

route('PUT', /^\/api\/workflows\/([^/]+)$/, async (req, res, wfId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const wf = workflowForUser(user, wfId);
  if (!wf) return sendJson(res, 404, { error: 'not_found' });
  const body = await readJsonBody(req);
  if (body.name !== undefined) wf.name = String(body.name).slice(0, 80);
  if (body.description !== undefined) wf.description = String(body.description).slice(0, 240);
  if (body.specification !== undefined) wf.specification = String(body.specification).slice(0, 20000);
  if (body.active !== undefined) wf.active = !!body.active;
  if (body.nodes !== undefined) wf.nodes = body.nodes;
  if (body.connections !== undefined) wf.connections = body.connections;
  if (body.settings !== undefined) wf.settings = body.settings;
  wf.updatedAt = nowIso();
  // schedule bookkeeping
  if (body.schedule !== undefined) {
    if (wf.schedule && wf.schedule.cron && !wf.schedule.nextRunAt) {
      const nx = nextCron(wf.schedule.cron);
      wf.schedule.nextRunAt = nx ? nx.toISOString() : null;
    }
  }
  // recompute nextRunAt when cron trigger exists
  const cronNode = (wf.nodes || []).find((n) => n.type === 'trigger.cron');
  if (cronNode) {
    const cron = (cronNode.parameters && cronNode.parameters.cron) || '* * * * *';
    if (!wf.schedule) wf.schedule = {};
    wf.schedule.cron = cron;
    const nx = nextCron(cron);
    wf.schedule.nextRunAt = nx ? nx.toISOString() : null;
  } else if (wf.schedule && wf.schedule.cron) {
    wf.schedule.nextRunAt = null;
  }
  store.set('workflows', wf.id, wf);
  sendJson(res, 200, { workflow: wf });
});

route('DELETE', /^\/api\/workflows\/([^/]+)$/, (req, res, wfId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const wf = workflowForUser(user, wfId);
  if (!wf) return sendJson(res, 404, { error: 'not_found' });
  store.del('workflows', wfId);
  for (const e of Object.values(store.all('executions'))) if (e.workflowId === wfId) store.del('executions', e.id);
  sendJson(res, 200, { ok: true });
});

route('POST', /^\/api\/workflows\/([^/]+)\/execute$/, async (req, res, wfId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const wf = workflowForUser(user, wfId);
  if (!wf) return sendJson(res, 404, { error: 'not_found' });
  const body = await readJsonBody(req);
  const exec = executeWorkflow(wf, {
    store, owner: user, llmConfig: user.llm || {},
    index, searchKnowledge: (q, k) => searchKnowledgeForUser(user, q, k),
    getCredential: (cid) => credentialForUser(user, cid),
    trigger: body.trigger || 'manual', hookData: body.hookData || null,
  });
  wf.updatedAt = nowIso();
  store.set('workflows', wf.id, wf);
  sendJson(res, 202, { execution: exec });
});

route('POST', /^\/api\/workflows\/([^/]+)\/test-node$/, async (req, res, wfId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const wf = workflowForUser(user, wfId);
  if (!wf) return sendJson(res, 404, { error: 'not_found' });
  const body = await readJsonBody(req);
  const node = (wf.nodes || []).find((n) => n.id === body.nodeId);
  if (!node) return sendJson(res, 404, { error: 'node_not_found' });
  const input = Array.isArray(body.input) ? body.input : [{ json: body.input || {} }];
  const runCtx = {
    owner: user, llmConfig: user.llm || {}, index,
    searchKnowledge: (q, k) => searchKnowledgeForUser(user, q, k),
    getCredential: (cid) => credentialForUser(user, cid),
    workflow: { id: wf.id, name: wf.name },
    env: (wf.settings && wf.settings.env) || {},
    nodeOutputs: {}, hookData: null, setWebhookResponse: () => {},
  };
  try {
    const out = await runNode(node, input, runCtx);
    sendJson(res, 200, { output: out.outputs || {} });
  } catch (e) {
    sendJson(res, 200, { error: String((e && e.message) || e) });
  }
});

route('GET', /^\/api\/workflows\/([^/]+)\/executions$/, (req, res, wfId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const wf = workflowForUser(user, wfId);
  if (!wf) return sendJson(res, 404, { error: 'not_found' });
  const execs = Object.values(store.all('executions')).filter((e) => e.workflowId === wfId)
    .map((e) => ({ id: e.id, status: e.status, trigger: e.trigger, startedAt: e.startedAt, finishedAt: e.finishedAt, durationMs: e.durationMs, error: e.error, stepCount: e.steps.length }))
    .sort((a, b) => b.startedAt.localeCompare(a.startedAt)).slice(0, 100);
  sendJson(res, 200, { executions: execs });
});

route('GET', /^\/api\/executions\/([^/]+)$/, (req, res, execId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const exec = store.get('executions', execId);
  if (!exec) return sendJson(res, 404, { error: 'not_found' });
  const wf = store.get('workflows', exec.workflowId);
  if (!wf || wf.userId !== user.id) return sendJson(res, 404, { error: 'not_found' });
  sendJson(res, 200, { execution: exec });
});

// ---- webhooks (public, per-workflow) ----
async function handleHook(req, res, wfId) {
  const wf = store.get('workflows', wfId);
  if (!wf) return sendJson(res, 404, { error: 'not_found' });
  if (!wf.active || !(wf.nodes || []).some((n) => n.type === 'trigger.webhook')) {
    return sendJson(res, 404, { error: 'This workflow is not accepting webhooks (activate it and add a Webhook trigger).' });
  }
  const u = new URL(req.url, 'http://localhost');
  if (wf.settings && wf.settings.webhookSecret) {
    if (u.searchParams.get('secret') !== wf.settings.webhookSecret) return sendJson(res, 401, { error: 'unauthorized' });
  }
  const body = await readJsonBody(req, 2 * 1024 * 1024);
  const headers = {};
  for (const k of Object.keys(req.headers)) headers[k] = req.headers[k];
  const hookData = { method: req.method, path: u.pathname, query: Object.fromEntries(u.searchParams), headers, body };
  const owner = store.get('users', wf.userId);
  const exec = executeWorkflow(wf, {
    store, owner: owner || { llm: {} }, llmConfig: (owner && owner.llm) || {},
    index, searchKnowledge: (q, k) => searchKnowledgeForUser(owner, q, k),
    getCredential: (cid) => credentialForUser(owner, cid),
    trigger: 'webhook', hookData,
  });
  // Wait briefly for fast workflows to finish so we can return their webhook response.
  const wait = async () => {
    for (let i = 0; i < 200; i++) {
      const e = store.get('executions', exec.id);
      if (e && e.status !== 'running') return e;
      await new Promise((r) => setTimeout(r, 50));
    }
    return store.get('executions', exec.id);
  };
  const fin = await wait();
  if (fin && fin.webhookResponse) {
    res.writeHead(fin.webhookResponse.status || 200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    const b = fin.webhookResponse.body;
    return res.end(typeof b === 'string' ? b : JSON.stringify(b));
  }
  sendJson(res, 200, { ok: true, executionId: exec.id, status: fin ? fin.status : 'running' });
}

route('POST', /^\/api\/hooks\/([^/]+)$/, (req, res, wfId) => handleHook(req, res, wfId));
route('GET', /^\/api\/hooks\/([^/]+)$/, (req, res, wfId) => handleHook(req, res, wfId));

// ---- chatbots ----
route('GET', /^\/api\/chatbots$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bots = Object.values(store.all('chatbots')).filter((b) => b.userId === user.id);
  const out = bots.map((b) => {
    const convs = Object.values(store.all('conversations')).filter((c) => c.chatbotId === b.id && c.channel !== 'playground');
    const leads = Object.values(store.all('leads')).filter((l) => l.chatbotId === b.id);
    const msgs = convs.reduce((a, c) => a + c.messages.length, 0);
    return { ...b, stats: { conversations: convs.length, messages: msgs, leads: leads.length, chunks: b.training ? b.training.chunksCount : 0, sources: b.training ? b.training.sourcesCount : 0 } };
  }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  sendJson(res, 200, { chatbots: out });
});

route('POST', /^\/api\/chatbots$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const name = String(body.name || 'My Assistant').slice(0, 60);
  const bot = {
    id: id('bot_'), userId: user.id, name,
    welcomeMessage: body.welcomeMessage || "Hi! 👋 I'm here to help. Ask me anything about our products and services.",
    placeholder: body.placeholder || 'Type your question…',
    primaryColor: body.primaryColor || '#6366f1', logo: body.logo || '✦', position: 'bottom-right',
    personality: body.personality || 'You are a helpful customer-support assistant. Answer questions using the provided knowledge only. If you do not know, say so and offer to connect the visitor with a human. Keep answers concise and friendly.',
    quickPrompts: Array.isArray(body.quickPrompts) ? body.quickPrompts.slice(0, 6) : [],
    model: body.model || 'balanced', enabled: true, webhookUrl: '', createdAt: nowIso(), updatedAt: nowIso(),
    training: { sourcesCount: 0, chunksCount: 0, lastTrainedAt: null },
  };
  store.set('chatbots', bot.id, bot);
  sendJson(res, 201, { chatbot: bot });
});

route('GET', /^\/api\/chatbots\/([^/]+)$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  sendJson(res, 200, { chatbot: bot });
});

route('PATCH', /^\/api\/chatbots\/([^/]+)$/, async (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const body = await readJsonBody(req);
  const fields = ['name', 'welcomeMessage', 'placeholder', 'primaryColor', 'logo', 'position', 'personality', 'quickPrompts', 'model', 'enabled', 'webhookUrl'];
  for (const f of fields) if (body[f] !== undefined) bot[f] = body[f];
  if (body.name !== undefined) bot.name = String(body.name).slice(0, 60);
  if (Array.isArray(body.quickPrompts)) bot.quickPrompts = body.quickPrompts.slice(0, 6).map((s) => String(s).slice(0, 140));
  bot.updatedAt = nowIso();
  store.set('chatbots', bot.id, bot);
  sendJson(res, 200, { chatbot: bot });
});

route('DELETE', /^\/api\/chatbots\/([^/]+)$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  for (const c of Object.values(store.all('conversations'))) if (c.chatbotId === botId) store.del('conversations', c.id);
  for (const l of Object.values(store.all('leads'))) if (l.chatbotId === botId) store.del('leads', l.id);
  for (const q of Object.values(store.all('qna'))) if (q.chatbotId === botId) store.del('qna', q.id);
  for (const s of Object.values(store.all('sources'))) if (s.chatbotId === botId) removeSource(s.id);
  store.del('chatbots', botId);
  index.drop(botId);
  sendJson(res, 200, { ok: true });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/retrain$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  for (const s of Object.values(store.all('sources'))) if (s.chatbotId === botId) ingestSource(s.id);
  updateTrainingMeta(botId);
  sendJson(res, 200, { ok: true, training: store.get('chatbots', botId).training });
});

// ---- sources ----
route('GET', /^\/api\/chatbots\/([^/]+)\/sources$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const sources = Object.values(store.all('sources')).filter((s) => s.chatbotId === botId).sort((a, b) => b.addedAt.localeCompare(a.addedAt));
  sendJson(res, 200, { sources: sources.map((s) => ({ id: s.id, type: s.type, title: s.title, url: s.url, status: s.status, chars: s.chars, chunks: s.chunks, addedAt: s.addedAt, refreshedAt: s.refreshedAt, error: s.error })) });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/sources\/url$/, async (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const body = await readJsonBody(req);
  const url = String(body.url || '').trim();
  if (!/^https?:\/\//i.test(url)) return sendJson(res, 400, { error: 'Please enter a valid URL starting with http:// or https://' });
  const maxPages = Math.min(6, Math.max(1, parseInt(body.maxPages, 10) || 3));
  const source = { id: id('src_'), chatbotId: botId, type: 'url', title: url, url, content: '', status: 'fetching', chars: 0, chunks: 0, addedAt: nowIso(), refreshedAt: nowIso(), error: null };
  store.set('sources', source.id, source);
  updateTrainingMeta(botId);

  // background crawl
  (async () => {
    try {
      const pages = [];
      const visited = new Set();
      const queue = [url];
      while (queue.length && pages.length < maxPages) {
        const u = queue.shift();
        if (visited.has(u)) continue;
        visited.add(u);
        let fetched;
        try { fetched = await fetchUrl(u); }
        catch (e) {
          if (pages.length === 0) throw e;
          continue;
        }
        const text = htmlToText(fetched.text);
        const title = extractTitle(fetched.text) || u;
        if (text.length > 120) pages.push({ url: u, title, text, description: extractMetaDescription(fetched.text) });
        if (pages.length < maxPages && /text\/html/i.test(fetched.contentType || '')) {
          for (const link of extractLinks(u, fetched.text)) if (!visited.has(link) && queue.length + pages.length < maxPages + 3) queue.push(link);
        }
      }
      if (!pages.length) throw new Error('No readable text found on that page.');
      // first page fills the placeholder source; the rest become new sources
      const first = pages[0];
      source.title = first.title; source.content = first.text; source.chars = first.text.length; source.status = 'ready'; source.refreshedAt = nowIso();
      store.set('sources', source.id, source);
      ingestSource(source.id);
      for (const p of pages.slice(1)) {
        const s2 = { id: id('src_'), chatbotId: botId, type: 'url', title: p.title, url: p.url, content: p.text, status: 'ready', chars: p.text.length, chunks: 0, addedAt: nowIso(), refreshedAt: nowIso(), error: null };
        store.set('sources', s2.id, s2);
        ingestSource(s2.id);
      }
      updateTrainingMeta(botId);
    } catch (e) {
      source.status = 'error';
      source.error = e.message === 'timeout' ? 'The page timed out. Try again or paste the text manually.' : e.message;
      store.set('sources', source.id, source);
      updateTrainingMeta(botId);
    }
  })();

  sendJson(res, 202, { sourceId: source.id, status: 'fetching' });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/sources\/text$/, async (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const body = await readJsonBody(req, 8 * 1024 * 1024);
  const content = String(body.content || '');
  const title = String(body.title || '').trim() || 'Pasted text';
  if (content.trim().length < 20) return sendJson(res, 400, { error: 'Please paste at least a sentence of content.' });
  const source = { id: id('src_'), chatbotId: botId, type: 'text', title, url: null, content, status: 'ready', chars: content.length, chunks: 0, addedAt: nowIso(), refreshedAt: nowIso(), error: null };
  store.set('sources', source.id, source);
  ingestSource(source.id);
  sendJson(res, 201, { source: summarizeSource(source) });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/sources\/file$/, async (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const body = await readJsonBody(req, 12 * 1024 * 1024);
  const filename = String(body.filename || 'upload.txt');
  const mimeType = String(body.mimeType || '');
  const ext = path.extname(filename).toLowerCase();
  let buf;
  try { buf = Buffer.from(String(body.dataBase64 || ''), 'base64'); }
  catch (e) { return sendJson(res, 400, { error: 'Could not decode the file.' }); }
  if (!buf.length) return sendJson(res, 400, { error: 'The file appears to be empty.' });

  let content = '';
  let note = null;
  try {
    if (['.txt', '.md', '.markdown', '.csv', '.tsv', '.html', '.htm', '.json', '.xml', '.log', '.yaml', '.yml'].includes(ext)) {
      content = buf.toString('utf8');
      if (content.includes('\uFFFD')) content = buf.toString('latin1');
    } else if (ext === '.pdf') {
      content = extractPdfText(buf);
      if (content.length < 40) return sendJson(res, 422, { error: 'This PDF appears to be scanned or image-based. Text could not be extracted — please use a text-based PDF or paste the text manually.' });
    } else if (ext === '.docx' || ext === '.doc' || ext === '.pptx' || ext === '.xlsx') {
      return sendJson(res, 422, { error: 'Office formats (' + ext + ') aren\'t supported for direct upload yet. Export to .txt or paste the text instead.' });
    } else {
      return sendJson(res, 422, { error: 'Unsupported file type "' + ext + '". Supported: TXT, MD, CSV, HTML, JSON, XML, YAML, and text-based PDF.' });
    }
  } catch (e) {
    return sendJson(res, 422, { error: 'Could not read that file: ' + e.message });
  }
  if (content.trim().length < 20) return sendJson(res, 422, { error: 'No readable text found in that file.' });
  const source = { id: id('src_'), chatbotId: botId, type: 'file', title: filename, url: null, content, status: 'ready', chars: content.length, chunks: 0, addedAt: nowIso(), refreshedAt: nowIso(), error: null };
  store.set('sources', source.id, source);
  ingestSource(source.id);
  sendJson(res, 201, { source: summarizeSource(source) });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/sources\/([^/]+)\/refresh$/, async (req, res, botId, sourceId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const source = store.get('sources', sourceId);
  if (!source || source.chatbotId !== botId) return sendJson(res, 404, { error: 'Source not found.' });
  if (source.type === 'url' && source.url) {
    source.status = 'fetching'; store.set('sources', source.id, source);
    (async () => {
      try {
        const fetched = await fetchUrl(source.url);
        const text = htmlToText(fetched.text);
        source.content = text; source.chars = text.length; source.status = 'ready'; source.refreshedAt = nowIso(); source.error = null;
        store.set('sources', source.id, source);
        ingestSource(source.id);
      } catch (e) {
        source.status = 'error'; source.error = e.message; store.set('sources', source.id, source);
      }
      updateTrainingMeta(botId);
    })();
    return sendJson(res, 202, { status: 'fetching' });
  }
  ingestSource(sourceId);
  sendJson(res, 200, { source: summarizeSource(store.get('sources', sourceId)) });
});

route('DELETE', /^\/api\/chatbots\/([^/]+)\/sources\/([^/]+)$/, (req, res, botId, sourceId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const source = store.get('sources', sourceId);
  if (!source || source.chatbotId !== botId) return sendJson(res, 404, { error: 'Source not found.' });
  removeSource(sourceId);
  sendJson(res, 200, { ok: true });
});

// ---- Q&A ----
route('GET', /^\/api\/chatbots\/([^/]+)\/qna$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const qna = Object.values(store.all('qna')).filter((q) => q.chatbotId === botId).sort((a, b) => b.addedAt.localeCompare(a.addedAt));
  sendJson(res, 200, { qna });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/qna$/, async (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const body = await readJsonBody(req);
  const question = String(body.question || '').trim();
  const answer = String(body.answer || '').trim();
  if (!question || !answer) return sendJson(res, 400, { error: 'Both question and answer are required.' });
  const q = { id: id('qna_'), chatbotId: botId, question, answer, addedAt: nowIso() };
  store.set('qna', q.id, q);
  sendJson(res, 201, { qna: q });
});

route('DELETE', /^\/api\/chatbots\/([^/]+)\/qna\/([^/]+)$/, (req, res, botId, qid) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const q = store.get('qna', qid);
  if (!q || q.chatbotId !== botId) return sendJson(res, 404, { error: 'Not found.' });
  store.del('qna', qid);
  sendJson(res, 200, { ok: true });
});

// ---- conversations ----
route('GET', /^\/api\/chatbots\/([^/]+)\/conversations$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const convs = Object.values(store.all('conversations')).filter((c) => c.chatbotId === botId)
    .sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt));
  sendJson(res, 200, { conversations: convs.map(summarizeConv) });
});

route('GET', /^\/api\/chatbots\/([^/]+)\/conversations\/([^/]+)$/, (req, res, botId, cid) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const conv = store.get('conversations', cid);
  if (!conv || conv.chatbotId !== botId) return sendJson(res, 404, { error: 'Conversation not found.' });
  sendJson(res, 200, { conversation: conv });
});

route('DELETE', /^\/api\/chatbots\/([^/]+)\/conversations\/([^/]+)$/, (req, res, botId, cid) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const conv = store.get('conversations', cid);
  if (!conv || conv.chatbotId !== botId) return sendJson(res, 404, { error: 'Conversation not found.' });
  store.del('conversations', cid);
  sendJson(res, 200, { ok: true });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/conversations\/([^/]+)\/rate$/, async (req, res, botId, cid) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const conv = store.get('conversations', cid);
  if (!conv || conv.chatbotId !== botId) return sendJson(res, 404, { error: 'Conversation not found.' });
  const body = await readJsonBody(req);
  const msg = conv.messages.find((mm) => mm.ts === body.messageTs);
  if (msg) { msg.rating = body.rating === 'up' ? 'up' : body.rating === 'down' ? 'down' : null; }
  store.set('conversations', conv.id, conv);
  sendJson(res, 200, { ok: true });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/conversations\/([^/]+)\/resolve$/, (req, res, botId, cid) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const conv = store.get('conversations', cid);
  if (!conv || conv.chatbotId !== botId) return sendJson(res, 404, { error: 'Conversation not found.' });
  conv.resolved = true; conv.escalated = false;
  store.set('conversations', conv.id, conv);
  sendJson(res, 200, { ok: true });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/conversations\/([^/]+)\/human-reply$/, async (req, res, botId, cid) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const conv = store.get('conversations', cid);
  if (!conv || conv.chatbotId !== botId) return sendJson(res, 404, { error: 'Conversation not found.' });
  const body = await readJsonBody(req);
  const text = String(body.text || '').trim();
  if (!text) return sendJson(res, 400, { error: 'Message cannot be empty.' });
  conv.messages.push({ role: 'human', text, ts: nowIso() });
  conv.agentJoined = true;
  conv.lastMessageAt = nowIso();
  store.set('conversations', conv.id, conv);
  sendJson(res, 200, { conversation: conv });
});

// ---- leads ----
route('GET', /^\/api\/chatbots\/([^/]+)\/leads$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const leads = Object.values(store.all('leads')).filter((l) => l.chatbotId === botId).sort((a, b) => b.capturedAt.localeCompare(a.capturedAt));
  sendJson(res, 200, { leads });
});

route('DELETE', /^\/api\/chatbots\/([^/]+)\/leads\/([^/]+)$/, (req, res, botId, lid) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const lead = store.get('leads', lid);
  if (!lead || lead.chatbotId !== botId) return sendJson(res, 404, { error: 'Lead not found.' });
  store.del('leads', lid);
  sendJson(res, 200, { ok: true });
});

route('GET', /^\/api\/chatbots\/([^/]+)\/leads\.csv$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const leads = Object.values(store.all('leads')).filter((l) => l.chatbotId === botId).sort((a, b) => b.capturedAt.localeCompare(a.capturedAt));
  const esc = (s) => '"' + String(s == null ? '' : s).replace(/"/g, '""') + '"';
  const rows = ['email,name,phone,source,captured_at'];
  for (const l of leads) rows.push([esc(l.email), esc(l.name), esc(l.phone || ''), esc(l.source), esc(l.capturedAt)].join(','));
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="leads-' + botId + '.csv"' });
  res.end('\uFEFF' + rows.join('\n'));
});

// ---- analytics ----
route('GET', /^\/api\/chatbots\/([^/]+)\/analytics$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  sendJson(res, 200, { analytics: computeAnalytics(botId) });
});

// ---- sample data ----
route('POST', /^\/api\/chatbots\/([^/]+)\/sample-data$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  clearSampleData(botId);
  const n = loadSampleData(botId);
  sendJson(res, 200, { created: n });
});

route('POST', /^\/api\/chatbots\/([^/]+)\/clear-sample-data$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  sendJson(res, 200, { removed: clearSampleData(botId) });
});

// ---- API keys ----
route('GET', /^\/api\/keys$/, (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  sendJson(res, 200, { keys: (user.apiKeys || []).map((k) => ({ key: maskKey(k.key), label: k.label, createdAt: k.createdAt, lastUsedAt: k.lastUsedAt || null })) });
});

route('POST', /^\/api\/keys$/, async (req, res) => {
  const user = requireUser(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const key = { key: 'coreai_' + require('crypto').randomBytes(24).toString('hex'), label: String(body.label || 'Default key'), createdAt: nowIso(), lastUsedAt: null };
  user.apiKeys = user.apiKeys || [];
  user.apiKeys.push(key);
  store.set('users', user.id, user);
  sendJson(res, 201, { key: key.key, label: key.label, createdAt: key.createdAt });
});

route('DELETE', /^\/api\/keys\/([^/]+)$/, (req, res, keyId) => {
  const user = requireUser(req, res);
  if (!user) return;
  user.apiKeys = (user.apiKeys || []).filter((k) => k.key !== keyId);
  store.set('users', user.id, user);
  sendJson(res, 200, { ok: true });
});

function maskKey(k) { return k.slice(0, 10) + '…' + k.slice(-4); }

// ---- public chat / widget ----
route('OPTIONS', /^\//, (req, res) => { sendCors(res); res.writeHead(204); res.end(); });

route('GET', /^\/api\/public\/([^/]+)\/config$/, (req, res, botId) => {
  const bot = publicBot(botId);
  if (!bot) return sendJson(res, 404, { error: 'not_found' });
  sendCors(res);
  sendJson(res, 200, {
    id: bot.id, name: bot.name, welcomeMessage: bot.welcomeMessage, placeholder: bot.placeholder,
    primaryColor: bot.primaryColor, logo: bot.logo, position: bot.position,
    quickPrompts: bot.quickPrompts || [], enabled: bot.enabled !== false, trained: (bot.training && bot.training.chunksCount > 0),
  });
});

route('POST', /^\/api\/public\/([^/]+)\/chat$/, async (req, res, botId) => {
  const bot = publicBot(botId);
  if (!bot) { sendCors(res); return sendJson(res, 404, { error: 'not_found' }); }
  sendCors(res);
  const body = await readJsonBody(req);
  const message = String(body.message || '').trim().slice(0, 1500);
  const visitorId = String(body.visitorId || '').slice(0, 80) || id('vis_');
  if (!message) return sendJson(res, 400, { error: 'empty_message' });
  let conv = getOrCreateConversation(botId, visitorId, 'web', { email: body.email || null, name: body.name || null });
  if (conv.resolved) { conv = getOrCreateConversation(botId, visitorId + '_' + Date.now(), 'web', {}); }
  conv.messages.push({ role: 'user', text: message, ts: nowIso() });
  conv.lastMessageAt = nowIso();
  if (conv.agentJoined && conv.messages.filter((m) => m.role === 'human').length > 0) {
    // a human has already joined — just relay to owner, respond with ack
    conv.messages.push({ role: 'bot', text: "I've passed that along to the team — they'll reply right here.", ts: nowIso(), mode: 'relay' });
    store.set('conversations', conv.id, conv);
    return sendJson(res, 200, { reply: "I've passed that along to the team — they'll reply right here.", mode: 'relay', conversationId: conv.id });
  }
  const ans = await answerMessage({ chatbotId: botId, message, conv });
  conv.messages.push({ role: 'bot', text: ans.text, ts: nowIso(), mode: ans.mode, sources: ans.sources || null });
  conv.lastMessageAt = nowIso();
  store.set('conversations', conv.id, conv);
  sendJson(res, 200, { reply: ans.text, mode: ans.mode, sources: ans.sources || null, conversationId: conv.id, visitorId });
});

route('POST', /^\/api\/public\/([^/]+)\/lead$/, async (req, res, botId) => {
  const bot = publicBot(botId);
  if (!bot) { sendCors(res); return sendJson(res, 404, { error: 'not_found' }); }
  sendCors(res);
  const body = await readJsonBody(req);
  const email = String(body.email || '').trim().slice(0, 120);
  const name = String(body.name || '').trim().slice(0, 80);
  const visitorId = String(body.visitorId || '').slice(0, 80) || id('vis_');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return sendJson(res, 400, { error: 'Please enter a valid email address.' });
  const conv = getOrCreateConversation(botId, visitorId, 'web', { email, name });
  conv.visitorEmail = email; conv.visitorName = name;
  conv.messages.push({ role: 'system', text: 'Visitor shared their contact details.', ts: nowIso() });
  conv.lastMessageAt = nowIso();
  store.set('conversations', conv.id, conv);
  const lead = { id: id('lead_'), chatbotId: botId, email, name, phone: body.phone || null, source: 'chat-widget', conversationId: conv.id, capturedAt: nowIso() };
  store.set('leads', lead.id, lead);
  if (bot.webhookUrl) fireWebhook(bot.webhookUrl, { event: 'lead.captured', chatbotId: botId, lead: { email, name, phone: lead.phone, capturedAt: lead.capturedAt } });
  sendJson(res, 201, { ok: true, reply: "Thanks, " + (name || 'there') + "! 🙌 Your details are saved and the team will follow up with you shortly." });
});

route('POST', /^\/api\/public\/([^/]+)\/handoff$/, async (req, res, botId) => {
  const bot = publicBot(botId);
  if (!bot) { sendCors(res); return sendJson(res, 404, { error: 'not_found' }); }
  sendCors(res);
  const body = await readJsonBody(req);
  const visitorId = String(body.visitorId || '').slice(0, 80) || id('vis_');
  const conv = getOrCreateConversation(botId, visitorId, 'web', { email: body.email || null, name: body.name || null });
  conv.escalated = true;
  conv.handoff = { requestedAt: nowIso(), note: String(body.note || '') };
  conv.messages.push({ role: 'system', text: 'Visitor requested a human.', ts: nowIso() });
  conv.lastMessageAt = nowIso();
  store.set('conversations', conv.id, conv);
  if (bot.webhookUrl) fireWebhook(bot.webhookUrl, { event: 'conversation.escalated', chatbotId: botId, conversationId: conv.id, visitorEmail: conv.visitorEmail });
  sendJson(res, 200, { ok: true, reply: "You're in the queue! 🔔 A human from our team will reply to you right here. If you'd like, leave your email below so we can also reach you directly." });
});

route('GET', /^\/api\/public\/([^/]+)\/poll$/, (req, res, botId) => {
  const bot = publicBot(botId);
  if (!bot) { sendCors(res); return sendJson(res, 404, { error: 'not_found' }); }
  sendCors(res);
  const u = new URL(req.url, 'http://x');
  const visitorId = u.searchParams.get('visitorId') || '';
  const after = u.searchParams.get('after') || '';
  let conv = null;
  for (const c of Object.values(store.all('conversations'))) {
    if (c.chatbotId === botId && c.visitorId === visitorId && c.channel === 'web') { conv = c; break; }
  }
  if (!conv) return sendJson(res, 200, { messages: [], escalated: false, agentJoined: false, resolved: false });
  const agentMessages = conv.messages.filter((m) => (m.role === 'human') && (!after || m.ts > after)).map((m) => ({ text: m.text, ts: m.ts }));
  sendJson(res, 200, { messages: agentMessages, escalated: conv.escalated, agentJoined: conv.agentJoined, resolved: conv.resolved });
});

// ---- playground (auth) ----
route('POST', /^\/api\/chatbots\/([^/]+)\/playground$/, async (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const body = await readJsonBody(req);
  const message = String(body.message || '').trim().slice(0, 1500);
  if (!message) return sendJson(res, 400, { error: 'empty_message' });
  const conv = getOrCreateConversation(botId, '__playground__', 'playground');
  conv.messages.push({ role: 'user', text: message, ts: nowIso() });
  const ans = await answerMessage({ chatbotId: botId, message, conv });
  conv.messages.push({ role: 'bot', text: ans.text, ts: nowIso(), mode: ans.mode, sources: ans.sources || null });
  conv.lastMessageAt = nowIso();
  store.set('conversations', conv.id, conv);
  sendJson(res, 200, { reply: ans.text, mode: ans.mode, sources: ans.sources || null });
});

route('GET', /^\/api\/chatbots\/([^/]+)\/playground$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  const conv = Object.values(store.all('conversations')).find((c) => c.chatbotId === botId && c.channel === 'playground');
  sendJson(res, 200, { messages: conv ? conv.messages : [] });
});

route('DELETE', /^\/api\/chatbots\/([^/]+)\/playground$/, (req, res, botId) => {
  const user = requireUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'Chatbot not found.' });
  for (const c of Object.values(store.all('conversations'))) if (c.chatbotId === botId && c.channel === 'playground') store.del('conversations', c.id);
  sendJson(res, 200, { ok: true });
});

// ---------------------------------------------------------------------------
// v1 REST API (Bearer API key)
// ---------------------------------------------------------------------------
function userFromApiKey(req) {
  const h = req.headers['authorization'] || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  if (!m) return null;
  const key = m[1];
  for (const u of Object.values(store.all('users'))) {
    if ((u.apiKeys || []).some((k) => k.key === key)) {
      const k = u.apiKeys.find((kk) => kk.key === key);
      k.lastUsedAt = nowIso();
      store.set('users', u.id, u);
      return u;
    }
  }
  return null;
}

function requireApiUser(req, res) {
  const user = userFromApiKey(req);
  if (!user) { sendJson(res, 401, { error: 'Invalid or missing API key. Pass it as: Authorization: Bearer coreai_…' }); return null; }
  return user;
}

route('GET', /^\/api\/v1\/chatbots$/, (req, res) => {
  const user = requireApiUser(req, res);
  if (!user) return;
  const bots = Object.values(store.all('chatbots')).filter((b) => b.userId === user.id);
  sendJson(res, 200, { chatbots: bots.map((b) => ({ id: b.id, name: b.name, primaryColor: b.primaryColor, enabled: b.enabled, training: b.training, createdAt: b.createdAt })) });
});

route('GET', /^\/api\/v1\/chatbots\/([^/]+)$/, (req, res, botId) => {
  const user = requireApiUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'not_found' });
  sendJson(res, 200, { chatbot: bot });
});

route('POST', /^\/api\/v1\/chatbots\/([^/]+)\/messages$/, async (req, res, botId) => {
  const user = requireApiUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'not_found' });
  const body = await readJsonBody(req);
  const message = String(body.message || '').trim().slice(0, 1500);
  if (!message) return sendJson(res, 400, { error: 'message is required' });
  const ans = await answerMessage({ chatbotId: botId, message, conv: null });
  sendJson(res, 200, { reply: ans.text, mode: ans.mode, sources: ans.sources || null });
});

route('GET', /^\/api\/v1\/chatbots\/([^/]+)\/conversations$/, (req, res, botId) => {
  const user = requireApiUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'not_found' });
  const convs = Object.values(store.all('conversations')).filter((c) => c.chatbotId === botId && c.channel !== 'playground').sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt));
  sendJson(res, 200, { conversations: convs.map(summarizeConv) });
});

route('POST', /^\/api\/v1\/chatbots\/([^/]+)\/retrain$/, (req, res, botId) => {
  const user = requireApiUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'not_found' });
  for (const s of Object.values(store.all('sources'))) if (s.chatbotId === botId) ingestSource(s.id);
  updateTrainingMeta(botId);
  sendJson(res, 200, { ok: true, training: store.get('chatbots', botId).training });
});

route('GET', /^\/api\/v1\/chatbots\/([^/]+)\/analytics$/, (req, res, botId) => {
  const user = requireApiUser(req, res);
  if (!user) return;
  const bot = botForUser(user, botId);
  if (!bot) return sendJson(res, 404, { error: 'not_found' });
  sendJson(res, 200, { analytics: computeAnalytics(botId) });
});

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------
function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, plan: u.plan, createdAt: u.createdAt, llmConfigured: !!(u.llm && u.llm.apiKey), llm: { baseUrl: u.llm ? u.llm.baseUrl : '', apiKey: '', model: u.llm ? u.llm.model : '' } };
}

function summarizeSource(s) {
  return { id: s.id, type: s.type, title: s.title, url: s.url, status: s.status, chars: s.chars, chunks: s.chunks, addedAt: s.addedAt, refreshedAt: s.refreshedAt, error: s.error };
}

function onboardUser(userId) {
  // create a starter chatbot pre-trained with the quick-start guide
  const bot = {
    id: id('bot_'), userId, name: 'My First Assistant',
    welcomeMessage: "Hi there! 👋 I'm your new AI assistant, trained to answer questions about your business. Ask me anything!",
    placeholder: 'Ask me anything…',
    primaryColor: '#6366f1', logo: '✦', position: 'bottom-right',
    personality: 'You are a helpful customer-support assistant. Answer questions using the provided knowledge only. If you do not know, say so and offer to connect the visitor with a human. Keep answers concise and friendly.',
    quickPrompts: ['How does training work?', 'How do I embed the chatbot?', 'Can it capture leads?'],
    model: 'balanced', enabled: true, webhookUrl: '', createdAt: nowIso(), updatedAt: nowIso(),
    training: { sourcesCount: 0, chunksCount: 0, lastTrainedAt: null },
  };
  store.set('chatbots', bot.id, bot);
  const guide = [
    'Getting started with Core AI. Core AI lets you build an AI support chatbot trained on your own content.',
    'Add training sources by pasting a website URL, uploading files (TXT, MD, CSV, HTML, JSON, XML or text-based PDF), or pasting raw text.',
    'Customize the bot in the Appearance tab: change its name, welcome message, colors, and logo.',
    'Test the bot in the Playground tab before publishing.',
    'Embed the bot on your website with the one-line snippet from the Embed tab.',
    'Review conversations, leads, and analytics as visitors chat with your bot.',
  ].join('\n\n');
  const source = { id: id('src_'), chatbotId: bot.id, type: 'text', title: 'Quick-start guide', url: null, content: guide, status: 'ready', chars: guide.length, chunks: 0, addedAt: nowIso(), refreshedAt: nowIso(), error: null };
  store.set('sources', source.id, source);
  ingestSource(source.id);
  onboardWorkflow(userId);
}

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------
ensureDemo();
initIndexes();

// In-process scheduler: runs active workflows that have a Schedule trigger.
setInterval(() => {
  try {
    const now = Date.now();
    for (const wf of Object.values(store.all('workflows'))) {
      if (!wf.active || !wf.schedule || !wf.schedule.nextRunAt) continue;
      if (new Date(wf.schedule.nextRunAt).getTime() > now) continue;
      const cron = wf.schedule.cron || '* * * * *';
      const owner = store.get('users', wf.userId);
      executeWorkflow(wf, {
        store, owner: owner || { llm: {} }, llmConfig: (owner && owner.llm) || {},
        index, searchKnowledge: (q, k) => (owner ? searchKnowledgeForUser(owner, q, k) : []),
        getCredential: (cid) => credentialForUser(owner, cid),
        trigger: 'cron',
      });
      const nx = nextCron(cron);
      wf.schedule.nextRunAt = nx ? nx.toISOString() : null;
      store.set('workflows', wf.id, wf);
    }
  } catch (e) { /* keep the scheduler alive */ }
}, 20000).unref();

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const pathname = decodeURIComponent(u.pathname);
  const method = req.method || 'GET';

  if (pathname.startsWith('/api/')) {
    const ai = authInfo(req);
    console.log('[' + method + '] ' + pathname + '  auth=' + !!ai.user + '  via=' + ai.via);
    try {
      const matched = matchRoute(method, pathname);
      if (matched) {
        await matched.handler(req, res, ...matched.params);
      } else {
        sendJson(res, 404, { error: 'not_found' });
      }
    } catch (e) {
      if (e && (e.message === 'invalid_json' || e.message === 'body_too_large')) {
        sendJson(res, 400, { error: e.message === 'body_too_large' ? 'Request body too large.' : 'Invalid JSON body.' });
      } else {
        sendJson(res, 500, { error: 'server_error', detail: String(e && e.message) });
      }
    }
    return;
  }

  serveStatic(req, res, pathname);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('Core AI server listening on http://0.0.0.0:' + PORT);
});
