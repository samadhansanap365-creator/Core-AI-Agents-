'use strict';
/* Core AI — Workflow Studio */
(() => {

const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------------- icons ---------------- */
const P = 'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
const ICONS = {
  bolt: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H13L13 2z"/></svg>',
  link: `<svg viewBox="0 0 24 24" ${P}><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`,
  clock: `<svg viewBox="0 0 24 24" ${P}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>`,
  branch: `<svg viewBox="0 0 24 24" ${P}><circle cx="6" cy="5" r="2.5"/><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="19" r="2.5"/><path d="M6 7.5v9"/><path d="M18 7.5A9 9 0 0 1 9 16.5"/></svg>`,
  shuffle: `<svg viewBox="0 0 24 24" ${P}><path d="M16 3h5v5"/><path d="M4 20 21 3"/><path d="M21 16v5h-5"/><path d="M15 15l6 6"/><path d="M4 4l5 5"/></svg>`,
  merge: `<svg viewBox="0 0 24 24" ${P}><path d="M6 4v7a3 3 0 0 0 3 3h7"/><path d="M18 4v7a3 3 0 0 1-3 3H8"/><path d="M12 21v-5"/></svg>`,
  hourglass: `<svg viewBox="0 0 24 24" ${P}><path d="M6 3h12"/><path d="M6 21h12"/><path d="M8 3v4l4 5-4 5v4"/><path d="M16 3v4l-4 5 4 5v4"/></svg>`,
  braces: `<svg viewBox="0 0 24 24" ${P}><path d="M8 4c-2 0-3 1.6-3 3.6S6 8 6 8s-1 2.6-1 4.4S6 19 8 19"/><path d="M16 4c2 0 3 1.6 3 3.6S18 8 18 8s1 2.6 1 4.4S18 19 16 19"/></svg>`,
  arrows: `<svg viewBox="0 0 24 24" ${P}><path d="M4 7h12l-3-3"/><path d="M20 17H8l3 3"/></svg>`,
  chart: `<svg viewBox="0 0 24 24" ${P}><path d="M3 21h18"/><path d="M7 21v-8"/><path d="M12 21V6"/><path d="M17 21v-4"/></svg>`,
  calendar: `<svg viewBox="0 0 24 24" ${P}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18"/><path d="M8 3v4"/><path d="M16 3v4"/></svg>`,
  sparkles: `<svg viewBox="0 0 24 24" ${P}><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15z"/></svg>`,
  bot: `<svg viewBox="0 0 24 24" ${P}><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V5"/><circle cx="12" cy="4" r="1"/><path d="M9 13h.01"/><path d="M15 13h.01"/><path d="M9 17h6"/></svg>`,
  book: `<svg viewBox="0 0 24 24" ${P}><path d="M4 5a2 2 0 0 1 2-2h6a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4z"/><path d="M20 5a2 2 0 0 0-2-2h-6a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h9z"/></svg>`,
  globe: `<svg viewBox="0 0 24 24" ${P}><circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a13.5 13.5 0 0 1 0 18"/><path d="M12 3a13.5 13.5 0 0 0 0 18"/></svg>`,
  code: `<svg viewBox="0 0 24 24" ${P}><path d="M8 7l-5 5 5 5"/><path d="M16 7l5 5-5 5"/></svg>`,
  reply: `<svg viewBox="0 0 24 24" ${P}><path d="M9 17l-5-5 5-5"/><path d="M4 12h10a5 5 0 0 1 5 5v3"/></svg>`,
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"/></svg>',
};

/* ---------------- node definitions ---------------- */
const NODE_DEFS = {
  'trigger.manual':  { cat: 'Triggers',  label: 'Manual Trigger',    sub: 'Start when you press Execute', icon: 'bolt',     color: '#6366f1', outputs: ['main'],
    params: [{ k: 'initialData', label: 'Initial data (JSON)', type: 'json', def: '{\n  "topic": "Core AI"\n}', hint: 'JSON passed into the first node of the workflow.' }] },
  'trigger.webhook': { cat: 'Triggers',  label: 'Webhook',           sub: 'Start from an HTTP request',    icon: 'link',     color: '#6366f1', outputs: ['main'],
    params: [] },
  'trigger.cron':    { cat: 'Triggers',  label: 'Schedule (Cron)',   sub: 'Start on a schedule',           icon: 'clock',    color: '#6366f1', outputs: ['main'],
    params: [{ k: 'cron', label: 'Cron expression', type: 'text', def: '*/5 * * * *', hint: '5 fields: minute hour day-of-month month day-of-week. Runs while the workflow is Active.' }] },

  'logic.if':        { cat: 'Logic', label: 'If',                   sub: 'Branch on a condition',          icon: 'branch',   color: '#8b5cf6', outputs: ['true', 'false'],
    params: [
      { k: 'field', label: 'Field', type: 'text', def: '', hint: 'Path into the input, e.g. plan or user.email' },
      { k: 'operation', label: 'Condition', type: 'select', def: 'equals', options: ['exists', 'notExists', 'empty', 'notEmpty', 'equals', 'notEquals', 'contains', 'notContains', 'gt', 'gte', 'lt', 'lte', 'regex'] },
      { k: 'value', label: 'Value', type: 'text', def: '' },
    ] },
  'logic.switch':    { cat: 'Logic', label: 'Switch',               sub: 'Route by value',                icon: 'shuffle',  color: '#8b5cf6', outputs: [],
    params: [
      { k: 'field', label: 'Field', type: 'text', def: '' },
      { k: 'rules', label: 'Routes', type: 'rules', def: [{ value: '', output: 'A' }, { value: '', output: 'B' }] },
      { k: 'fallback', label: 'Fallback output', type: 'text', def: 'fallback' },
    ] },
  'logic.merge':     { cat: 'Logic', label: 'Merge',                sub: 'Combine multiple inputs',       icon: 'merge',    color: '#8b5cf6', outputs: ['main'], params: [] },
  'logic.wait':      { cat: 'Logic', label: 'Wait',                 sub: 'Pause before continuing',       icon: 'hourglass', color: '#8b5cf6', outputs: ['main'],
    params: [{ k: 'seconds', label: 'Wait (seconds)', type: 'number', def: 1 }] },

  'data.set':        { cat: 'Data', label: 'Edit Fields',           sub: 'Set / change data fields',      icon: 'braces',   color: '#0ea5e9', outputs: ['main'],
    params: [
      { k: 'assignments', label: 'Assignments', type: 'assignments', def: [{ name: '', value: '', type: 'set' }] },
      { k: 'keepOnly', label: 'Keep only set fields', type: 'boolean', def: false },
    ] },
  'data.transform':  { cat: 'Data', label: 'Transform',             sub: 'Reshape data with expressions', icon: 'arrows',   color: '#0ea5e9', outputs: ['main'],
    params: [{ k: 'expression', label: 'Expression', type: 'code', def: '{{ $json }}', hint: 'e.g. {{ { name: $json.first + " " + $json.last } }} or a path like {{ $json.items }}' }] },
  'data.aggregate':  { cat: 'Data', label: 'Aggregate',             sub: 'Sum, count, average…',          icon: 'chart',    color: '#0ea5e9', outputs: ['main'],
    params: [
      { k: 'field', label: 'Field', type: 'text', def: '' },
      { k: 'operation', label: 'Operation', type: 'select', def: 'sum', options: ['sum', 'avg', 'min', 'max', 'count'] },
    ] },
  'data.datetime':   { cat: 'Data', label: 'Date & Time',           sub: 'Now, format or add time',       icon: 'calendar', color: '#0ea5e9', outputs: ['main'],
    params: [
      { k: 'operation', label: 'Operation', type: 'select', def: 'now', options: ['now', 'format', 'add'] },
      { k: 'field', label: 'Date field', type: 'text', def: '' },
      { k: 'format', label: 'Format', type: 'text', def: 'YYYY-MM-DD HH:mm:ss' },
      { k: 'amount', label: 'Add amount', type: 'number', def: 1 },
      { k: 'unit', label: 'Unit', type: 'select', def: 'days', options: ['minutes', 'hours', 'days', 'weeks', 'months'] },
    ] },

  'ai.llm':          { cat: 'AI', label: 'LLM',                    sub: 'Call a language model',         icon: 'sparkles', color: '#14b8a6', outputs: ['main'],
    params: [
      { k: 'system', label: 'System prompt', type: 'textarea', def: 'You are a helpful assistant.' },
      { k: 'prompt', label: 'User prompt', type: 'textarea', def: '{{ JSON.stringify($json) }}', hint: 'Expressions supported. Requires a model key in Settings for real answers.' },
    ] },
  'ai.agent':        { cat: 'AI', label: 'AI Agent',               sub: 'Autonomous agent step',         icon: 'bot',      color: '#14b8a6', outputs: ['main'],
    params: [
      { k: 'system', label: 'Agent instructions', type: 'textarea', def: 'You are a Core AI agent. Complete the task from the input data.' },
      { k: 'prompt', label: 'Task', type: 'textarea', def: '{{ JSON.stringify($json) }}' },
    ] },
  'ai.rag':          { cat: 'AI', label: 'Knowledge (RAG)',        sub: 'Answer from your knowledge',    icon: 'book',     color: '#14b8a6', outputs: ['main'],
    params: [
      { k: 'question', label: 'Question', type: 'textarea', def: '{{ JSON.stringify($json) }}' },
      { k: 'topK', label: 'Top results', type: 'number', def: 3 },
    ] },

  'dev.http':        { cat: 'Developer', label: 'HTTP Request',     sub: 'Call any REST API',             icon: 'globe',    color: '#64748b', outputs: ['main'],
    params: [
      { k: 'method', label: 'Method', type: 'select', def: 'GET', options: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] },
      { k: 'url', label: 'URL', type: 'text', def: 'https://' },
      { k: 'headers', label: 'Headers', type: 'kvs', def: [{ name: 'Content-Type', value: 'application/json' }] },
      { k: 'body', label: 'Body (JSON)', type: 'json', def: '' },
      { k: 'authType', label: 'Auth type', type: 'select', def: 'none', options: ['none', 'basic', 'bearer'] },
      { k: 'authUser', label: 'Basic auth user', type: 'text', def: '' },
      { k: 'authPass', label: 'Basic auth password', type: 'password', def: '' },
      { k: 'authToken', label: 'Bearer token', type: 'password', def: '' },
    ] },
  'dev.code':        { cat: 'Developer', label: 'Code (JS)',        sub: 'Run custom JavaScript',         icon: 'code',     color: '#64748b', outputs: ['main'],
    params: [{ k: 'code', label: 'JavaScript', type: 'code', def: '// $json is the input item. Return items:\nreturn [{ json: { ...$json, processed: true, at: $now() } }];', hint: 'Return an array of { json: … } items. Available: $json, $prev, $workflow, $env, $now(), $random(), $(“Node name”).' }] },
  'dev.webhookResponse': { cat: 'Developer', label: 'Webhook Response', sub: 'Reply to the webhook caller', icon: 'reply', color: '#64748b', outputs: ['main'],
    params: [
      { k: 'statusCode', label: 'Status code', type: 'number', def: 200 },
      { k: 'body', label: 'Response body', type: 'json', def: '{{ JSON.stringify($json) }}' },
    ] },
};

const COMING_SOON = ['Gmail', 'Google Sheets', 'Google Drive', 'Slack', 'Discord', 'Notion', 'HubSpot', 'Salesforce', 'Shopify', 'Stripe', 'GitHub', 'Jira', 'Trello', 'PostgreSQL', 'MySQL', 'MongoDB', 'Supabase', 'SendGrid', 'Mailchimp', 'Zendesk', 'Twilio', 'Calendly', 'OpenAI', 'Anthropic', 'Gemini'];

const AGENT_TEMPLATES = [
  { id: 'research', label: 'Research Agent', sub: 'Finds & summarizes information', color: '#0ea5e9', icon: 'book', system: 'You are a research agent. Analyze the provided data, find relevant facts, and summarize them clearly with references where possible.' },
  { id: 'support', label: 'Support Agent', sub: 'Answers customer questions', color: '#14b8a6', icon: 'bot', system: 'You are a customer-support agent. Answer the customer using the provided knowledge, be concise and friendly, and escalate when unsure.' },
  { id: 'sales', label: 'Sales Agent', sub: 'Qualifies & follows up leads', color: '#8b5cf6', icon: 'sparkles', system: 'You are a sales agent. Qualify the lead, address objections, and recommend next steps for the sales team.' },
  { id: 'data', label: 'Data Agent', sub: 'Cleans & transforms data', color: '#6366f1', icon: 'chart', system: 'You are a data agent. Clean, structure and summarize the input data, and flag any anomalies.' },
  { id: 'coding', label: 'Coding Agent', sub: 'Writes & reviews code', color: '#64748b', icon: 'code', system: 'You are a coding agent. Produce correct, readable code for the requested task and explain it briefly.' },
  { id: 'document', label: 'Document Agent', sub: 'Extracts info from documents', color: '#f59e0b', icon: 'braces', system: 'You are a document agent. Extract the key information, entities and structure from the provided document text.' },
  { id: 'orchestrator', label: 'Orchestrator', sub: 'Routes work between agents', color: '#ec4899', icon: 'shuffle', system: 'You are an orchestrator agent. Decide which specialist should handle the task, then hand it off with clear instructions.' },
];

const CAT_ORDER = ['AI Agents', 'Triggers', 'Logic', 'Data', 'AI', 'Developer', 'Connectors'];

/* ---------------- state ---------------- */
const state = {
  token: (function () {
    let t = '';
    try { t = localStorage.getItem('coreai_token') || ''; } catch (e) {}
    if (!t) {
      try {
        const m = document.cookie.match(/(?:^|;\s*)coreai_token=([^;]+)/);
        if (m) t = decodeURIComponent(m[1]);
      } catch (e) {}
    }
    return t;
  })(),
  user: null,
  workflow: null,
  selected: new Set(),       // node ids
  selectedEdge: null,        // connection object (by reference)
  pan: { x: 40, y: 40 },
  zoom: 1,
  history: [], hIndex: -1,
  dirty: false,
  running: null,             // { id, status, done, total }
  lastExec: null,
  testResults: {},
  webhookPort: '',
  // ——— registry / library ———
  registry: null,            // { providers, integrations, agents, categories, filters }
  credentials: [],           // masked credential list
  favorites: [],             // [{ kind, ref, label }]
  recent: [],                // [{ kind, ref, label }]
  libSearch: '',
  libFilter: 'ALL',
};

const world = $('#world');
const canvasWrap = $('#canvasWrap');
const nodeEls = new Map();

/* ---------------- registry lookups + brand icons ---------------- */
const brandIcon = (key) => (typeof BRAND_ICONS !== 'undefined' && BRAND_ICONS[key]) ? BRAND_ICONS[key] : null;
function providerOf(id) { const r = state.registry; return r && r.providers ? r.providers.find((p) => p.id === id) : null; }
function integrationOf(id) { const r = state.registry; return r && r.integrations ? r.integrations.find((i) => i.id === id) : null; }
function agentOf(id) { const r = state.registry; return r && r.agents ? r.agents.find((a) => a.id === id) : null; }
function credCountFor(provider) { return state.credentials.filter((c) => c.provider === provider).length; }
function defaultCredFor(provider) { const c = state.credentials.find((x) => x.provider === provider); return c ? c.id : ''; }

/* ---------------- api ---------------- */
// In sandboxed preview iframes, localStorage/cookies can be blocked AND the
// proxy can strip Authorization/x-session headers. Detect that and fall back
// to carrying the session token as a ?tok= query parameter instead.
let useQueryAuth = false;
(function () {
  try {
    localStorage.setItem('__coreai_probe', '1');
    if (localStorage.getItem('__coreai_probe') !== '1') useQueryAuth = true;
    localStorage.removeItem('__coreai_probe');
  } catch (e) { useQueryAuth = true; }
})();

let authBounced = false;
async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.token) { headers.Authorization = 'Bearer ' + state.token; headers['x-session'] = state.token; }
  let url = '/api' + path;
  if (state.token && useQueryAuth) url += (url.includes('?') ? '&' : '?') + 'tok=' + encodeURIComponent(state.token);
  let res;
  try {
    res = await fetch(url, { method: opts.method || 'GET', headers, body: opts.body ? JSON.stringify(opts.body) : undefined });
  } catch (e) {
    return { status: 0, data: { error: 'Network error — is the server running?' } };
  }
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (res.status === 401 && state.token && !useQueryAuth) {
    // We hold a token but the server rejected the headers — the proxy is
    // likely stripping them. Switch to query-param auth and retry once.
    useQueryAuth = true;
    const q = '/api' + path + (path.includes('?') ? '&' : '?') + 'tok=' + encodeURIComponent(state.token);
    try { res = await fetch(q, { method: opts.method || 'GET', headers, body: opts.body ? JSON.stringify(opts.body) : undefined }); } catch (e) { return { status: 0, data: { error: 'Network error — is the server running?' } }; }
    try { data = await res.json(); } catch (e) { data = {}; }
  }
  if (res.status === 401 && !authBounced) {
    // Session expired → clear and re-provision a fresh guest session once.
    authBounced = true;
    state.token = '';
    try { localStorage.removeItem('coreai_token'); } catch (e) {}
    try { sessionStorage.removeItem('coreai_token'); } catch (e) {}
    try { document.cookie = 'coreai_token=;path=/;max-age=0'; } catch (e) {}
    location.replace('/studio.html');
    return { status: 401, data: { error: 'unauthorized' } };
  }
  return { status: res.status, data };
}

/* ---------------- toasts ---------------- */
function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 320); }, 2600);
}

/* ---------------- boot ---------------- */
function showBootLoading() {
  const o = $('#bootOverlay');
  o.className = 'boot-overlay';
  o.innerHTML = '<div class="boot-card"><div class="spinner"></div><p>Loading workflow…</p></div>';
}
function showBootError(msg) {
  const o = $('#bootOverlay');
  o.className = 'boot-overlay';
  o.innerHTML = '<div class="boot-card"><div class="err-icon">!</div><h3>Unable to load workflow</h3><p>' + esc(msg || 'Something went wrong. Please try again.') + '</p><button class="btn btn-primary" id="bootRetry">Retry</button></div>';
  const b = $('#bootRetry');
  if (b) b.addEventListener('click', () => boot());
}
function hideBootOverlay() {
  const o = $('#bootOverlay');
  if (o) o.classList.add('hidden');
}

// Fetch with a few retries for transient network failures (status 0). A real
// HTTP response (2xx/4xx/5xx) is returned as-is — only genuine offline blips retry.
async function apiWithRetry(path, opts, tries = 3) {
  let r;
  for (let i = 0; i < tries; i++) {
    r = await api(path, opts);
    if (r.status !== 0) return r;
    await new Promise((s) => setTimeout(s, 500));
  }
  return r;
}

function guestId() {
  try {
    let g = localStorage.getItem('coreai_guest_id');
    if (!g) {
      g = 'g_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
      localStorage.setItem('coreai_guest_id', g);
    }
    return g;
  } catch (e) { return 'g_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }
}

// Auto-provision (or resume) a guest workspace — no sign-in required.
async function ensureSession() {
  if (state.token) return true;
  let r = await api('/auth/guest', { method: 'POST', body: { guestId: guestId() } });
  if (r.status !== 200) r = await api('/auth/guest', { method: 'POST', body: { guestId: guestId() } });
  if (r.status !== 200 || !r.data.token) return false;
  state.token = r.data.token;
  try { localStorage.setItem('coreai_token', r.data.token); } catch (e) {}
  try { sessionStorage.setItem('coreai_token', r.data.token); } catch (e) {}
  try { document.cookie = 'coreai_token=' + encodeURIComponent(r.data.token) + ';path=/;max-age=86400;SameSite=Lax'; } catch (e) {}
  return true;
}

async function boot() {
  showBootLoading();
  authBounced = false;
  try {
    if (!(await ensureSession())) throw new Error('Could not start a session. Check that the preview is still running.');
    let r = await apiWithRetry('/me');
    if (r.status === 401) return;              // api() already bounced to a fresh session
    if (r.status === 0) throw new Error('No connection to the server. Check that the preview is still running.');
    if (r.status !== 200) throw new Error('Session check failed (HTTP ' + r.status + ').');
    state.user = r.data.user;
    $('#amName').textContent = state.user.name || state.user.email;
    $('#amEmail').textContent = state.user.email;
    $('#avatarBtn').textContent = (state.user.name || state.user.email).slice(0, 1).toUpperCase();

    // Load the studio registry (providers/models/integrations/agents) plus
    // credentials/favorites/recent. Non-fatal: the library simply renders
    // without these if they fail, and Retry re-runs boot().
    const [rg, cr, fav, rec] = await Promise.all([
      api('/registry'), api('/credentials'), api('/favorites'), api('/recent'),
    ]);
    if (rg.status === 200) state.registry = rg.data;
    if (cr.status === 200) state.credentials = cr.data.credentials || [];
    if (fav.status === 200) state.favorites = fav.data.items || [];
    if (rec.status === 200) state.recent = rec.data.items || [];
    renderPalette();

    const qs = new URLSearchParams(location.search);
    const wfId = qs.get('id');
    const ok = wfId ? await openWorkflow(wfId) : await loadFirstOrNew();
    if (!ok) throw new Error('The workflow could not be loaded.');
    hideBootOverlay();
  } catch (e) {
    showBootError(e && e.message ? e.message : 'An unexpected error occurred.');
  }
}

async function loadFirstOrNew() {
  const r = await apiWithRetry('/workflows');
  if (r.status === 0) throw new Error('No connection to the server.');
  if (r.status !== 200) throw new Error('Failed to list workflows (HTTP ' + r.status + ').');
  const wfs = r.data.workflows || [];
  if (wfs.length) return await openWorkflow(wfs[0].id);
  return await createWorkflow('My First Workflow');
}

async function createWorkflow(name) {
  const r = await apiWithRetry('/workflows', { method: 'POST', body: { name: name || 'Untitled workflow' } });
  if (r.status === 0) throw new Error('No connection to the server.');
  if (r.status !== 201) throw new Error('Could not create a workflow (HTTP ' + r.status + ').');
  state.workflow = r.data.workflow;
  state.selected.clear(); state.selectedEdge = null;
  state.history = []; state.hIndex = -1;
  renderAll(); centerView(); updateNameField(); setSaved(true);
  return true;
}

async function openWorkflow(id) {
  const r = await apiWithRetry('/workflows/' + id);
  if (r.status === 0) throw new Error('No connection to the server.');
  if (r.status === 404) throw new Error('This workflow no longer exists.');
  if (r.status !== 200) throw new Error('Failed to load the workflow (HTTP ' + r.status + ').');
  state.workflow = r.data.workflow;
  state.selected.clear(); state.selectedEdge = null;
  state.history = []; state.hIndex = -1;
  state.running = null;
  state.lastExec = null;
  renderAll(); updateNameField(); setSaved(true);
  closeExecDrawer();
  return true;
}

/* ---------------- palette ---------------- */
/* ---------------- node library ---------------- */
function favoriteRef(kind, ref) { return state.favorites.some((f) => f.kind === kind && f.ref === ref); }
async function toggleFavorite(kind, ref, label) {
  if (favoriteRef(kind, ref)) {
    state.favorites = state.favorites.filter((f) => !(f.kind === kind && f.ref === ref));
    await api('/favorites?kind=' + encodeURIComponent(kind) + '&ref=' + encodeURIComponent(ref), { method: 'DELETE' });
  } else {
    state.favorites.unshift({ kind, ref, label });
    await api('/favorites', { method: 'POST', body: { kind, ref, label } });
  }
  renderPalette();
}
async function recordRecent(kind, ref, label) {
  state.recent = state.recent.filter((i) => !(i.kind === kind && i.ref === ref));
  state.recent.unshift({ kind, ref, label });
  state.recent = state.recent.slice(0, 20);
  api('/recent', { method: 'POST', body: { kind, ref, label } });
}

function starBtn(kind, ref, label) {
  const on = favoriteRef(kind, ref);
  const b = document.createElement('button');
  b.className = 'star-btn' + (on ? ' on' : '');
  b.title = on ? 'Remove from favorites' : 'Add to favorites';
  b.textContent = on ? '★' : '☆';
  b.addEventListener('click', async (e) => { e.stopPropagation(); await toggleFavorite(kind, ref, label); });
  return b;
}

function libSection(title, count) {
  const sec = document.createElement('div');
  sec.className = 'pal-cat';
  sec.innerHTML = `<div class="pal-cat-title">${title}${count != null ? '<span class="pal-count">' + count + '</span>' : ''}</div>`;
  return sec;
}

function matchesSearch() {
  const f = state.libSearch.toLowerCase().trim();
  const hay = (...xs) => { const s = xs.join(' ').toLowerCase(); return !f || s.includes(f); };
  return { f, hay };
}
function filterAllows(group) {
  const F = state.libFilter;
  if (F === 'ALL') return true;
  if (F === 'AI') return group === 'models' || group === 'agents';
  if (F === 'APPS') return group === 'apps';
  if (F === 'TOOLS') return group === 'tools';
  if (F === 'DATA') return group === 'data';
  if (F === 'DEVELOPER') return group === 'developer';
  if (F === 'TRIGGERS') return group === 'triggers';
  if (F === 'LOGIC') return group === 'logic';
  return true;
}

function renderPalette() {
  const host = $('#palScroll');
  host.innerHTML = '';
  const { f, hay } = matchesSearch();
  let any = false;

  /* ---- filter chips ---- */
  const fc = $('#libFilters');
  if (fc) {
    const filters = (state.registry && state.registry.filters) || [{ id: 'ALL', label: 'All' }];
    fc.innerHTML = filters.map((fl) => `<button class="lib-chip${state.libFilter === fl.id ? ' active' : ''}" data-f="${fl.id}">${esc(fl.label)}</button>`).join('');
    fc.querySelectorAll('.lib-chip').forEach((c) => c.addEventListener('click', () => {
      state.libFilter = c.dataset.f;
      renderPalette();
    }));
  }

  const reg = state.registry;
  const providers = reg ? reg.providers : [];
  const integrations = reg ? reg.integrations : [];
  const agents = reg ? reg.agents : [];

  /* ---- recently used ---- */
  if (state.recent.length && state.libFilter === 'ALL' && !f) {
    const sec = libSection('Recently used');
    for (const r of state.recent.slice(0, 6)) {
      const item = recentItem(r);
      if (item) sec.appendChild(item);
    }
    if (sec.children.length > 1) { host.appendChild(sec); any = true; }
  }

  /* ---- favorites ---- */
  if (state.favorites.length && (state.libFilter === 'ALL' || state.libFilter === 'AI' || state.libFilter === 'APPS') && !f) {
    const sec = libSection('Favorites', state.favorites.length);
    for (const fav of state.favorites) {
      const item = recentItem(fav);
      if (item) sec.appendChild(item);
    }
    if (sec.children.length > 1) { host.appendChild(sec); any = true; }
  }

  /* ---- AI models (providers → models) ---- */
  if (filterAllows('models')) {
    const list = providers.filter((p) => hay(p.name, p.short) || (p.models || []).some((m) => hay(m.id)));
    if (list.length) {
      const sec = libSection('AI Models', list.length);
      for (const p of list) {
        const card = providerCard(p);
        sec.appendChild(card);
      }
      host.appendChild(sec); any = true;
    }
  }

  /* ---- AI agents ---- */
  if (filterAllows('agents')) {
    const list = agents.filter((a) => hay(a.name, a.sub));
    if (list.length) {
      const sec = libSection('AI Agents', list.length);
      for (const a of list) {
        const card = document.createElement('div');
        card.className = 'agent-card';
        card.innerHTML = `<span class="p-ico" style="background:${a.color}">${ICONS[a.icon] || ICONS.bot}</span>
          <span style="flex:1"><span class="ac-label">${esc(a.name)}</span><br><span class="ac-sub">${esc(a.sub)}</span></span>`;
        card.appendChild(starBtn('agent', a.id, a.name));
        card.addEventListener('click', () => addAgentNode(a));
        sec.appendChild(card);
      }
      host.appendChild(sec); any = true;
    }
  }

  /* ---- apps / integrations ---- */
  if (filterAllows('apps')) {
    const list = integrations.filter((i) => hay(i.name) || i.actions.some((a) => hay(a.name)));
    if (list.length) {
      const sec = libSection('Apps', list.length);
      for (const i of list) {
        const card = providerCard(i, true);
        sec.appendChild(card);
      }
      host.appendChild(sec); any = true;
    }
  }

  /* ---- native node categories ---- */
  for (const cat of CAT_ORDER) {
    if (cat === 'AI Agents') continue;
    const group = cat === 'Triggers' ? 'triggers' : cat === 'Logic' ? 'logic' : cat === 'Data' ? 'data' : cat === 'Developer' ? 'developer' : cat === 'Tools' ? 'tools' : 'other';
    if (!filterAllows(group)) continue;
    const defs = Object.entries(NODE_DEFS).filter(([t, d]) => d.cat === cat && (hay(d.label, t)));
    if (!defs.length) continue;
    const sec = libSection(cat, defs.length);
    for (const [type, d] of defs) {
      const item = document.createElement('div');
      item.className = 'pal-item';
      item.dataset.type = type;
      item.innerHTML = `<span class="p-ico" style="background:${d.color}">${ICONS[d.icon]}</span>
        <span style="flex:1"><span class="p-label">${esc(d.label)}</span><br><span class="p-sub">${esc(d.sub)}</span></span>`;
      item.appendChild(starBtn('node', type, d.label));
      item.addEventListener('mousedown', (e) => paletteGrab(e, type));
      sec.appendChild(item);
    }
    host.appendChild(sec); any = true;
  }

  if (!any) {
    host.innerHTML = `<div class="lib-empty">No matches for “${esc(state.libSearch)}”.<br><br>Try “GPT”, “Claude”, “Google”, “Drive”, “Telegram”, or an agent name.</div>`;
  }
}

function scrollToPalCat(title) {
  const sec = Array.from($('#palScroll').querySelectorAll('.pal-cat')).find((s) => (s.querySelector('.pal-cat-title') || {}).textContent.startsWith(title));
  if (sec) sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* recent/favorite item — resolves a {kind, ref} into a clickable row */
function recentItem(r) {
  if (!state.registry) return null;
  if (r.kind === 'model') {
    const [pid, mid] = String(r.ref || '').split('::');
    const p = providerOf(pid);
    const m = p && (p.models || []).find((x) => x.id === mid);
    if (!p || !m) return null;
    const el = document.createElement('div');
    el.className = 'lib-item';
    const ico = brandIcon(p.icon);
    el.innerHTML = `<span class="p-ico" style="background:#fff;color:#111;width:26px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:6px">${ico || esc(p.short[0])}</span>
      <span style="flex:1;min-width:0"><span class="p-label" style="display:block">${esc(p.short + ' · ' + m.id)}</span></span>`;
    el.appendChild(starBtn('model', r.ref, r.label || m.id));
    el.addEventListener('click', () => addModelNode(pid, mid));
    return el;
  }
  if (r.kind === 'app') {
    const i = integrationOf(r.ref);
    if (!i) return null;
    const el = document.createElement('div');
    el.className = 'lib-item';
    const ico = brandIcon(i.icon);
    el.innerHTML = `<span class="p-ico" style="background:#fff;color:#111;width:26px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:6px">${ico || esc(i.name[0])}</span>
      <span style="flex:1;min-width:0"><span class="p-label" style="display:block">${esc(i.name)}</span></span>`;
    el.addEventListener('click', () => { state.libFilter = 'APPS'; state.libSearch = ''; renderPalette(); });
    return el;
  }
  if (r.kind === 'provider') {
    const p = providerOf(r.ref);
    if (!p) return null;
    const el = document.createElement('div');
    el.className = 'lib-item';
    const ico = brandIcon(p.icon);
    el.innerHTML = `<span class="p-ico" style="background:#fff;color:#111;width:26px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:6px">${ico || esc(p.short[0])}</span>
      <span style="flex:1;min-width:0"><span class="p-label" style="display:block">${esc(p.name)}</span></span>`;
    el.addEventListener('click', () => { state.libFilter = 'AI'; state.libSearch = ''; renderPalette(); });
    return el;
  }
  if (r.kind === 'agent') {
    const a = agentOf(r.ref);
    if (!a) return null;
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.innerHTML = `<span class="p-ico" style="background:${a.color}">${ICONS[a.icon] || ICONS.bot}</span>
      <span style="flex:1;min-width:0"><span class="p-label" style="display:block">${esc(a.name)}</span></span>`;
    el.addEventListener('click', () => addAgentNode(a));
    return el;
  }
  if (r.kind === 'node') {
    const d = NODE_DEFS[r.ref];
    if (!d) return null;
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.innerHTML = `<span class="p-ico" style="background:${d.color}">${ICONS[d.icon]}</span>
      <span style="flex:1;min-width:0"><span class="p-label" style="display:block">${esc(d.label)}</span></span>`;
    el.addEventListener('click', () => { const pos = viewCenter(); addNode(r.ref, pos.x, pos.y); });
    return el;
  }
  return null;
}

/* provider card (isApp=false) or integration card (isApp=true) */
function providerCard(p, isApp) {
  const card = document.createElement('div');
  card.className = 'prov-card';
  const ico = brandIcon(p.icon);
  const count = isApp ? (p.actions || []).length : (p.models || []).length;
  const connected = credCountFor(p.id) > 0;
  const head = document.createElement('div');
  head.className = 'prov-head';
  head.innerHTML = `<span class="prov-ico${ico ? '' : ' alt'}">${ico || esc((p.short || p.name)[0])}</span>
    <span class="prov-name">${esc(p.name)}</span>
    <span class="prov-dot ${connected ? 'on' : 'off'}" title="${connected ? 'Credential connected' : 'No credential yet'}"></span>
    <span class="prov-caret">▶</span>`;
  head.appendChild(starBtn(isApp ? 'app' : 'provider', p.id, p.name));
  head.addEventListener('click', () => card.classList.toggle('open'));
  card.appendChild(head);

  const body = document.createElement('div');
  body.className = 'prov-body';
  if (!isApp && (p.auth && (p.auth.type !== 'none'))) {
    body.innerHTML = `<div class="auth-note">${esc(p.auth.label)} — ${connected ? 'credential connected ✓' : 'no credential yet. Add one in Credentials.'}</div>`;
  }
  if (isApp) {
    for (const a of (p.actions || [])) {
      const row = document.createElement('div');
      row.className = 'action-row';
      row.innerHTML = `<span class="ar-name">${esc(a.name)}${a.restricted ? ' <span class="mr-cap" style="color:#f59e0b">restricted</span>' : ''}</span><button class="add-btn">Add</button>`;
      row.querySelector('.add-btn').addEventListener('click', (e) => { e.stopPropagation(); addActionNode(p, a); });
      body.appendChild(row);
    }
  } else {
    for (const m of (p.models || [])) {
      const row = document.createElement('div');
      row.className = 'model-row';
      const caps = [];
      if (m.vision) caps.push('<span class="mr-cap">vision</span>');
      if (m.tools) caps.push('<span class="mr-cap">tools</span>');
      if (m.structured) caps.push('<span class="mr-cap">structured</span>');
      if (m.streaming) caps.push('<span class="mr-cap">streaming</span>');
      row.innerHTML = `<span class="mr-name" title="${esc(m.id)}">${esc(m.id)}</span><span class="mr-caps">${caps.join('')}</span><button class="add-btn">Add</button>`;
      row.querySelector('.add-btn').addEventListener('click', (e) => { e.stopPropagation(); addModelNode(p.id, m.id); });
      body.appendChild(row);
    }
  }
  card.appendChild(body);
  return card;
}

/* ---- add nodes to the canvas ---- */
function placeNode(node) {
  pushHistory();
  const pos = viewCenter();
  node.position = { x: Math.round(pos.x - 104), y: Math.round(pos.y - 20) };
  state.workflow.nodes.push(node);
  state.workflow.updatedAt = new Date().toISOString();
  renderAll();
  selectNode(node.id);
  openInspector(node.id);
  markDirty();
}

function addModelNode(providerId, modelId) {
  const p = providerOf(providerId);
  if (!p) return;
  const node = {
    id: 'nd_' + Math.random().toString(36).slice(2, 10),
    type: 'ai.model', name: p.short + ' · ' + modelId,
    parameters: {
      provider: providerId, model: modelId,
      system: 'You are a helpful assistant.',
      prompt: '{{ JSON.stringify($json) }}',
      temperature: null, maxTokens: 0, responseFormat: 'text',
      credentialId: defaultCredFor(providerId),
    },
  };
  placeNode(node);
  recordRecent('model', providerId + '::' + modelId, p.short + ' · ' + modelId);
}

function addActionNode(integration, action) {
  const node = {
    id: 'nd_' + Math.random().toString(36).slice(2, 10),
    type: 'app.action', name: integration.name + ' · ' + action.name,
    parameters: {
      integration: integration.id, action: action.id,
      params: {}, credentialId: defaultCredFor(integration.id),
    },
  };
  for (const prm of (action.params || [])) if (prm.def !== undefined) node.parameters.params[prm.key] = prm.def;
  placeNode(node);
  recordRecent('app', integration.id, integration.name);
}

function addAgentNode(a) {
  const node = {
    id: 'nd_' + Math.random().toString(36).slice(2, 10),
    type: 'ai.agent', name: a.name,
    parameters: { agentType: a.id, system: a.system, prompt: '{{ JSON.stringify($json) }}', provider: '', model: '', credentialId: '' },
  };
  placeNode(node);
  recordRecent('agent', a.id, a.name);
}

let pendingType = null, ghost = null, grabMoved = false;
function paletteGrab(e, type) {
  e.preventDefault();
  pendingType = type; grabMoved = false;
  const sx = e.clientX, sy = e.clientY;
  const move = (ev) => {
    if (Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) > 4) grabMoved = true;
    if (grabMoved && !ghost) {
      ghost = document.createElement('div');
      ghost.style.cssText = 'position:fixed;z-index:999;pointer-events:none;background:#fff;border:1.5px solid var(--accent);border-radius:12px;padding:10px 14px;font-weight:600;font-size:13px;box-shadow:var(--shadow-lg);';
      ghost.textContent = NODE_DEFS[type].label;
      document.body.appendChild(ghost);
    }
    if (ghost) { ghost.style.left = (ev.clientX + 10) + 'px'; ghost.style.top = (ev.clientY + 10) + 'px'; }
  };
  const up = (ev) => {
    document.removeEventListener('mousemove', move);
    document.removeEventListener('mouseup', up);
    if (ghost) ghost.remove(); ghost = null;
    const overCanvas = canvasWrap.contains(ev.target);
    if (overCanvas) {
      const pos = grabMoved ? worldFromEvent(ev) : viewCenter();
      addNode(type, pos.x, pos.y);
    } else if (!grabMoved) {
      const pos = viewCenter();
      addNode(type, pos.x, pos.y);
    }
    pendingType = null;
  };
  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
}

function addAgentTemplate(t) {
  pushHistory();
  const node = {
    id: 'nd_' + Math.random().toString(36).slice(2, 10),
    type: 'ai.agent', name: t.label, position: { x: 0, y: 0 }, parameters: { system: t.system, prompt: '{{ JSON.stringify($json) }}' },
  };
  state.workflow.nodes.push(node);
  state.workflow.updatedAt = new Date().toISOString();
  renderAll();
  selectNode(node.id);
  openInspector(node.id);
  markDirty();
}

function agentGrab(e, t) {
  e.preventDefault();
  const sx = e.clientX, sy = e.clientY;
  let moved = false, g = null;
  const move = (ev) => {
    if (Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) > 4) moved = true;
    if (moved && !g) {
      g = document.createElement('div');
      g.style.cssText = 'position:fixed;z-index:999;pointer-events:none;background:var(--panel-2);border:1.5px solid var(--accent);border-radius:12px;padding:10px 14px;font-weight:600;font-size:13px;color:#fff;box-shadow:var(--shadow-lg);';
      g.textContent = t.label;
      document.body.appendChild(g);
    }
    if (g) { g.style.left = (ev.clientX + 10) + 'px'; g.style.top = (ev.clientY + 10) + 'px'; }
  };
  const up = (ev) => {
    document.removeEventListener('mousemove', move);
    document.removeEventListener('mouseup', up);
    if (g) g.remove();
    const pos = moved && canvasWrap.contains(ev.target) ? worldFromEvent(ev) : viewCenter();
    const node = { id: 'nd_' + Math.random().toString(36).slice(2, 10), type: 'ai.agent', name: t.label, position: { x: Math.round(pos.x - 104), y: Math.round(pos.y - 20) }, parameters: { system: t.system, prompt: '{{ JSON.stringify($json) }}' } };
    pushHistory();
    state.workflow.nodes.push(node);
    state.workflow.updatedAt = new Date().toISOString();
    renderAll();
    selectNode(node.id);
    openInspector(node.id);
    markDirty();
  };
  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
}
function outputPorts(node) {
  const d = NODE_DEFS[node.type];
  if (!d) return ['main'];
  if (node.type === 'logic.switch') {
    const rules = (node.parameters && node.parameters.rules) || [];
    const fallback = (node.parameters && node.parameters.fallback) || 'fallback';
    return [...rules.map((r) => r.output || 'rule'), fallback];
  }
  return d.outputs || ['main'];
}

function addNode(type, x, y) {
  const d = NODE_DEFS[type];
  if (!d) return;
  pushHistory();
  const params = {};
  (d.params || []).forEach((p) => { if (p.def !== undefined) params[p.k] = JSON.parse(JSON.stringify(p.def)); });
  const node = {
    id: 'nd_' + Math.random().toString(36).slice(2, 10),
    type, name: d.label, position: { x: Math.round(x - 104), y: Math.round(y - 20) }, parameters: params,
  };
  state.workflow.nodes.push(node);
  state.workflow.updatedAt = new Date().toISOString();
  renderAll();
  selectNode(node.id);
  openInspector(node.id);
  markDirty();
}

function duplicateNodes(ids) {
  if (!ids.length) return;
  pushHistory();
  const offset = 30;
  const newIds = [];
  for (const id of ids) {
    const src = state.workflow.nodes.find((n) => n.id === id);
    if (!src) continue;
    const node = JSON.parse(JSON.stringify(src));
    node.id = 'nd_' + Math.random().toString(36).slice(2, 10);
    node.position = { x: src.position.x + offset, y: src.position.y + offset };
    newIds.push(node.id);
    state.workflow.nodes.push(node);
  }
  state.selected = new Set(newIds);
  renderAll();
  markDirty();
}

function deleteNodes(ids) {
  if (!ids.length) return;
  pushHistory();
  const set = new Set(ids);
  state.workflow.nodes = state.workflow.nodes.filter((n) => !set.has(n.id));
  state.workflow.connections = state.workflow.connections.filter((c) => !set.has(c.from) && !set.has(c.to));
  state.selected.clear(); state.selectedEdge = null;
  renderAll();
  closeInspector();
  markDirty();
}

function renderAll() {
  if (!state.workflow) return;
  renderNodes();
  renderEdges();
  updateHint();
}

function renderNodes() {
  if (!state.workflow) return;
  nodeEls.clear();
  world.querySelectorAll('.node').forEach((n) => n.remove());
  for (const node of state.workflow.nodes) {
    const el = document.createElement('div');
    el.className = 'node';
    el.dataset.id = node.id;
    el.style.left = node.position.x + 'px';
    el.style.top = node.position.y + 'px';
    el.innerHTML = nodeInner(node);
    world.appendChild(el);
    nodeEls.set(node.id, el);
    bindNode(el, node);
  }
}

function nodeVisual(node) {
  if (node.type === 'ai.model') {
    const p = providerOf((node.parameters || {}).provider);
    const ico = p && brandIcon(p.icon);
    return { color: 'transparent', html: ico || ICONS.sparkles, isBrand: !!ico, label: (p ? p.short + ' Model' : 'Model') };
  }
  if (node.type === 'app.action') {
    const i = integrationOf((node.parameters || {}).integration);
    const ico = i && brandIcon(i.icon);
    return { color: 'transparent', html: ico || ICONS.globe, isBrand: !!ico, label: i ? i.name : 'Action' };
  }
  const d = NODE_DEFS[node.type] || { color: '#64748b', icon: 'bolt', label: node.type, sub: '' };
  return { color: d.color, html: ICONS[d.icon], isBrand: false, label: d.label };
}

function nodeInner(node) {
  const v = nodeVisual(node);
  const ports = outputPorts(node);
  const portsHtml = ports.map((p) => `<div class="node-out" data-port="${esc(p)}"><span class="o-dot"></span><span class="o-label">${esc(p)}</span></div>`).join('');
  const icoSpan = v.isBrand
    ? `<span class="node-ico brand" style="background:#fff;color:#111">${v.html}</span>`
    : `<span class="node-ico" style="background:${v.color}">${v.html}</span>`;
  return `<div class="node-in" title="Input"></div>
    <div class="node-head">${icoSpan}<span class="node-name">${esc(node.name)}</span><span class="node-badge"></span></div>
    <div class="node-body">${esc(nodeSub(node))}</div>
    <div class="node-outs">${portsHtml}</div>`;
}

function nodeSub(node) {
  const p = node.parameters || {};
  switch (node.type) {
    case 'trigger.cron': return 'cron: ' + (p.cron || '* * * * *');
    case 'trigger.webhook': return 'POST /api/hooks/' + (state.workflow ? state.workflow.id : '…');
    case 'logic.if': return (p.field || 'field') + ' ' + (p.operation || 'equals') + (p.value ? ' ' + JSON.stringify(p.value) : '');
    case 'logic.wait': return 'wait ' + (p.seconds || 1) + 's';
    case 'data.set': return ((p.assignments || []).map((a) => a.name).filter(Boolean).join(', ') || 'set fields');
    case 'dev.http': return (p.method || 'GET') + ' ' + (p.url || 'https://…');
    case 'dev.code': return 'JavaScript';
    case 'dev.webhookResponse': return 'status ' + (p.statusCode || 200);
    case 'ai.rag': return 'retrieve top ' + (p.topK || 3);
    case 'ai.llm': case 'ai.agent': {
      if (p.provider && p.model) return (p.agentType ? (agentOf(p.agentType) ? agentOf(p.agentType).name : p.agentType) + ' · ' : '') + p.model;
      return 'model: ' + (state.user && state.user.llm && state.user.llm.model ? state.user.llm.model : 'fallback');
    }
    case 'ai.model': return 'model: ' + (p.model || '—');
    case 'app.action': {
      const i = integrationOf(p.integration);
      const a = i && (i.actions || []).find((x) => x.id === p.action);
      return (i ? i.name : p.integration || 'app') + (a ? ' · ' + a.name : '');
    }
    default: return '';
  }
}

function updateNodeEl(node) {
  const el = nodeEls.get(node.id);
  if (!el) return;
  el.querySelector('.node-name').textContent = node.name;
  el.querySelector('.node-body').textContent = nodeSub(node);
  const outs = el.querySelector('.node-outs');
  outs.innerHTML = outputPorts(node).map((p) => `<div class="node-out" data-port="${esc(p)}"><span class="o-dot"></span><span class="o-label">${esc(p)}</span></div>`).join('');
  outs.querySelectorAll('.node-out .o-dot').forEach((dot) => bindOutPort(dot, node));
}

function bindNode(el, node) {
  el.querySelector('.node-in').addEventListener('mousedown', (e) => { e.stopPropagation(); e.preventDefault(); });
  el.querySelectorAll('.node-out .o-dot').forEach((dot) => bindOutPort(dot, node));
  el.addEventListener('mousedown', (e) => {
    if (e.target.closest('.node-in') || e.target.closest('.node-out')) return;
    e.stopPropagation();
    nodeMouseDown(e, node);
  });
}

function bindOutPort(dot, node) {
  dot.addEventListener('mousedown', (e) => {
    e.stopPropagation(); e.preventDefault();
    startConnect(node, e);
  });
}

/* ---------------- edges ---------------- */
function bezier(a, b) {
  const dx = Math.max(46, Math.min(200, Math.abs(b.x - a.x) * 0.5));
  return `M ${a.x} ${a.y} C ${a.x + dx} ${a.y}, ${b.x - dx} ${b.y}, ${b.x} ${b.y}`;
}

function renderEdges() {
  const svg = $('#connSvg');
  svg.innerHTML = '';
  if (!state.workflow) return;
  const ns = 'http://www.w3.org/2000/svg';
  for (const c of state.workflow.connections) {
    const fromEl = nodeEls.get(c.from), toEl = nodeEls.get(c.to);
    if (!fromEl || !toEl) continue;
    const fromPort = findOutDot(fromEl, c.out);
    const toPort = toEl.querySelector('.node-in');
    if (!fromPort || !toPort) continue;
    const a = portPos(fromPort), b = portPos(toPort);
    const d = bezier(a, b);
    const path = document.createElementNS(ns, 'path');
    path.setAttribute('d', d);
    path.setAttribute('class', 'edge' + (state.selectedEdge === c ? ' selected' : ''));
    svg.appendChild(path);
    const hit = document.createElementNS(ns, 'path');
    hit.setAttribute('d', d);
    hit.setAttribute('class', 'edge-hit');
    hit.addEventListener('mousedown', (e) => { e.stopPropagation(); selectEdge(c); });
    svg.appendChild(hit);
    const dot = document.createElementNS(ns, 'circle');
    const mid = curveMid(a, b);
    dot.setAttribute('cx', mid.x); dot.setAttribute('cy', mid.y); dot.setAttribute('r', 3.4);
    dot.setAttribute('class', 'flow-dot');
    dot.style.opacity = state.selectedEdge === c ? 1 : 0.55;
    svg.appendChild(dot);
  }
}

function findOutDot(nodeEl, port) {
  let found = null;
  nodeEl.querySelectorAll('.node-out').forEach((o) => { if (o.dataset.port === port) found = o.querySelector('.o-dot'); });
  return found;
}

function curveMid(a, b) {
  const dx = Math.max(46, Math.min(200, Math.abs(b.x - a.x) * 0.5));
  const t = 0.5;
  const x = Math.pow(1 - t, 3) * a.x + 3 * Math.pow(1 - t, 2) * t * (a.x + dx) + 3 * (1 - t) * t * t * (b.x - dx) + Math.pow(t, 3) * b.x;
  const y = Math.pow(1 - t, 3) * a.y + 3 * Math.pow(1 - t, 2) * t * a.y + 3 * (1 - t) * t * t * b.y + Math.pow(t, 3) * b.y;
  return { x, y };
}

function portPos(el) {
  const wr = world.getBoundingClientRect();
  const r = el.getBoundingClientRect();
  return { x: (r.left - wr.left + r.width / 2) / state.zoom, y: (r.top - wr.top + r.height / 2) / state.zoom };
}

function worldFromEvent(e) {
  const wr = world.getBoundingClientRect();
  return { x: (e.clientX - wr.left) / state.zoom, y: (e.clientY - wr.top) / state.zoom };
}

function viewCenter() {
  const wr = world.getBoundingClientRect();
  const cr = canvasWrap.getBoundingClientRect();
  const cx = cr.left + cr.width / 2, cy = cr.top + cr.height / 2;
  return { x: (cx - wr.left) / state.zoom, y: (cy - wr.top) / state.zoom };
}

function updateHint() {
  const h = $('#canvasHint');
  h.style.display = (state.workflow && state.workflow.nodes.length) ? 'none' : 'block';
}

/* ---------------- transform ---------------- */
function applyTransform() {
  world.style.transform = `translate(${state.pan.x}px, ${state.pan.y}px) scale(${state.zoom})`;
  $('#zoomVal').textContent = Math.round(state.zoom * 100) + '%';
}

function zoomAt(factor, cx, cy) {
  const z2 = Math.max(0.2, Math.min(3, state.zoom * factor));
  const wr = world.getBoundingClientRect();
  const wx = (cx - wr.left) / state.zoom, wy = (cy - wr.top) / state.zoom;
  state.zoom = z2;
  state.pan.x = cx - wx * z2 - canvasWrap.getBoundingClientRect().left;
  state.pan.y = cy - wy * z2 - canvasWrap.getBoundingClientRect().top;
  applyTransform();
  renderEdges();
}

function centerView() {
  if (!state.workflow.nodes.length) { state.pan = { x: 40, y: 40 }; state.zoom = 1; applyTransform(); return; }
  let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
  for (const n of state.workflow.nodes) {
    minX = Math.min(minX, n.position.x); minY = Math.min(minY, n.position.y);
    maxX = Math.max(maxX, n.position.x + 208); maxY = Math.max(maxY, n.position.y + 80);
  }
  const cr = canvasWrap.getBoundingClientRect();
  const pad = 80;
  const z = Math.max(0.2, Math.min(1.4, Math.min((cr.width - pad * 2) / (maxX - minX || 1), (cr.height - pad * 2) / (maxY - minY || 1))));
  state.zoom = z;
  state.pan.x = cr.width / 2 - (minX + (maxX - minX) / 2) * z;
  state.pan.y = cr.height / 2 - (minY + (maxY - minY) / 2) * z;
  applyTransform();
  renderEdges();
}

/* ---------------- selection ---------------- */
function selectNode(id, additive = false) {
  if (!additive) state.selected.clear();
  state.selected.add(id);
  state.selectedEdge = null;
  refreshSelection();
}

function clearSelection() {
  state.selected.clear();
  state.selectedEdge = null;
  refreshSelection();
  closeInspector();
}

function selectEdge(c) {
  state.selectedEdge = c;
  state.selected.clear();
  refreshSelection();
  openEdgeInspector(c);
}

function refreshSelection() {
  nodeEls.forEach((el, id) => {
    el.classList.toggle('selected', state.selected.has(id));
  });
  renderEdges();
}

/* ---------------- inspector ---------------- */
function openInspector(nodeId) {
  const node = state.workflow.nodes.find((n) => n.id === nodeId);
  if (!node) return;
  state.insNodeId = nodeId;
  $('#emptyIns').style.display = 'none';
  const panel = $('#insPanel');
  panel.style.display = 'flex';
  $('#insTitle').textContent = node.name;
  switchTab('params');
  $('#inspector').classList.remove('collapsed');
}

function closeInspector() {
  $('#insPanel').style.display = 'none';
  $('#emptyIns').style.display = 'block';
  state.insNodeId = null;
}

function openEdgeInspector(c) {
  const from = state.workflow.nodes.find((n) => n.id === c.from);
  const to = state.workflow.nodes.find((n) => n.id === c.to);
  state.insNodeId = null;
  $('#emptyIns').style.display = 'none';
  const panel = $('#insPanel');
  panel.style.display = 'flex';
  $('#insTitle').textContent = 'Connection';
  $('#insScroll').innerHTML = `<div class="empty-ins" style="padding:20px 10px">
    <p><b>${esc(from ? from.name : '?')}</b> → <b>${esc(to ? to.name : '?')}</b></p>
    <p style="font-size:12px">Output port “${esc(c.out)}”. Select and press Delete to remove this connection.</p>
  </div>`;
  $('#inspector').classList.remove('collapsed');
}

let currentTab = 'params';
function switchTab(tab) {
  currentTab = tab;
  $$('.ins-tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
  if (!state.insNodeId) return;
  const node = state.workflow.nodes.find((n) => n.id === state.insNodeId);
  if (!node) return;
  $('#insScroll').innerHTML = tab === 'params' ? paramsHtml(node) : ioHtml(node);
  if (tab === 'params') bindParams(node);
  else bindIo(node);
}

/* ---------------- model / app / agent config ---------------- */
function credSelectHtml(node, providerId) {
  const creds = state.credentials.filter((c) => !providerId || c.provider === providerId);
  const cur = (node.parameters || {}).credentialId || '';
  return `<div class="field"><label>Credentials</label>
    <select class="select" id="pCredential">
      <option value="">— None —</option>
      ${creds.map((c) => `<option value="${esc(c.id)}"${c.id === cur ? ' selected' : ''}>${esc(c.name)} (${esc(c.type)})</option>`).join('')}
    </select>
    <div class="hint">Secrets are stored encrypted and never embedded in the workflow. <a href="#" id="lnkCreds">Manage credentials →</a></div></div>`;
}

function paramsHtmlModel(node) {
  const p = node.parameters || {};
  const provs = state.registry ? state.registry.providers : [];
  const prov = providerOf(p.provider);
  const models = prov ? prov.models : [];
  const temp = p.temperature == null ? '' : Number(p.temperature);
  let html = `<div class="field"><label>Name</label><input class="input" id="pName" value="${esc(node.name)}"></div>`;
  html += `<div class="field"><label>Provider</label><select class="select" id="pProvider">
    ${provs.map((x) => `<option value="${esc(x.id)}"${x.id === p.provider ? ' selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div>`;
  html += `<div class="field"><label>Model</label><select class="select" id="pModel">
    ${models.map((m) => `<option value="${esc(m.id)}"${m.id === p.model ? ' selected' : ''}>${esc(m.id)}</option>`).join('')}</select></div>`;
  html += credSelectHtml(node, p.provider);
  html += `<div class="field"><label>System instructions</label><textarea class="textarea" data-k="system" rows="3">${esc(p.system == null ? '' : p.system)}</textarea></div>`;
  html += `<div class="field"><label>Prompt</label><textarea class="textarea" data-k="prompt" rows="3" spellcheck="false">${esc(p.prompt == null ? '' : p.prompt)}</textarea><div class="hint">Expressions supported, e.g. {{ JSON.stringify($json) }}.</div></div>`;
  html += `<div class="field"><label>Temperature <span id="tempVal">${temp === '' ? 'provider default' : temp}</span></label>
    <input type="range" min="0" max="2" step="0.1" id="pTemperature" value="${temp === '' ? '0.7' : temp}">
    <div class="hint">Lower = deterministic, higher = creative.</div></div>`;
  html += `<div class="field"><label>Max output tokens</label><input class="input" type="number" data-k="maxTokens" value="${esc(p.maxTokens == null ? '' : p.maxTokens)}" placeholder="Provider default"><div class="hint">Leave 0/empty for the provider default.</div></div>`;
  html += `<div class="field"><label>Output format</label><select class="select" data-k="responseFormat">
    <option value="text"${p.responseFormat !== 'json' && p.responseFormat !== 'structured' ? ' selected' : ''}>Text</option>
    <option value="json"${p.responseFormat === 'json' ? ' selected' : ''}>JSON</option>
    <option value="structured"${p.responseFormat === 'structured' ? ' selected' : ''}>Structured output</option></select></div>`;
  if (!credCountFor(p.provider)) {
    html += `<div class="auth-note" style="margin-top:4px">This provider has no credential yet — the node will fail on execution with a clear “requires API key” message until you add one in Credentials.</div>`;
  }
  return html;
}

function bindParamsModel(node) {
  const p = node.parameters || {};
  const name = $('#pName');
  if (name) name.addEventListener('input', () => { node.name = name.value; $('#insTitle').textContent = node.name; updateNodeEl(node); markDirty(); });
  const prov = $('#pProvider');
  if (prov) prov.addEventListener('change', () => { setParam(node, 'provider', prov.value); setParam(node, 'model', (providerOf(prov.value).models[0] || {}).id || ''); renderInspector(); });
  const model = $('#pModel');
  if (model) model.addEventListener('change', () => { setParam(node, 'model', model.value); });
  const cred = $('#pCredential');
  if (cred) cred.addEventListener('change', () => { setParam(node, 'credentialId', cred.value); });
  const t = $('#pTemperature');
  if (t) t.addEventListener('input', () => { setParam(node, 'temperature', Number(t.value)); const v = $('#tempVal'); if (v) v.textContent = t.value; });
  $$('#insScroll [data-k]').forEach((el) => {
    const k = el.dataset.k;
    if (el.tagName === 'SELECT') el.addEventListener('change', () => setParam(node, k, el.value));
    else if (el.type === 'number') el.addEventListener('input', () => setParam(node, k, el.value === '' ? '' : Number(el.value)));
    else el.addEventListener('input', () => setParam(node, k, el.value));
  });
  const lnk = $('#lnkCreds');
  if (lnk) lnk.addEventListener('click', (e) => { e.preventDefault(); renderCredentialsModal(); });
}

function paramsHtmlApp(node) {
  const p = node.parameters || {};
  const ints = state.registry ? state.registry.integrations : [];
  const integ = integrationOf(p.integration);
  const actions = integ ? integ.actions : [];
  const action = actions.find((a) => a.id === p.action);
  const params = p.params || {};
  let html = `<div class="field"><label>Name</label><input class="input" id="pName" value="${esc(node.name)}"></div>`;
  html += `<div class="field"><label>App</label><select class="select" id="pIntegration">
    ${ints.map((x) => `<option value="${esc(x.id)}"${x.id === p.integration ? ' selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div>`;
  html += `<div class="field"><label>Action</label><select class="select" id="pAction">
    ${actions.map((a) => `<option value="${esc(a.id)}"${a.id === p.action ? ' selected' : ''}>${esc(a.name)}</option>`).join('')}</select></div>`;
  if (integ && integ.auth && integ.auth.type !== 'none') html += credSelectHtml(node, p.integration);
  if (integ && integ.auth) html += `<div class="auth-note">${esc(integ.auth.notes || integ.auth.label)}</div>`;
  if (action && action.restricted) html += `<div class="auth-note" style="border-color:rgba(245,158,11,.4)">⚠ ${esc(action.name)} is restricted and requires permissions review. Configure the credential to see exact requirements.</div>`;
  for (const prm of (action ? action.params : [])) {
    const v = params[prm.key];
    html += `<div class="field"><label>${esc(prm.label)}</label>`;
    if (prm.type === 'textarea') html += `<textarea class="textarea" data-ak="${esc(prm.key)}" rows="3" spellcheck="false">${esc(v == null ? '' : v)}</textarea>`;
    else if (prm.type === 'number') html += `<input class="input" type="number" data-ak="${esc(prm.key)}" value="${esc(v == null ? '' : v)}">`;
    else if (prm.type === 'select') html += `<select class="select" data-ak="${esc(prm.key)}">${prm.options.map((o) => `<option value="${esc(o)}"${String(v) === o ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
    else html += `<input class="input" data-ak="${esc(prm.key)}" value="${esc(v == null ? '' : v)}" spellcheck="false">`;
    html += `</div>`;
  }
  return html;
}

function bindParamsApp(node) {
  const p = node.parameters || {};
  const name = $('#pName');
  if (name) name.addEventListener('input', () => { node.name = name.value; $('#insTitle').textContent = node.name; updateNodeEl(node); markDirty(); });
  const integ = $('#pIntegration');
  if (integ) integ.addEventListener('change', () => {
    const i = integrationOf(integ.value);
    const first = i.actions[0] || {};
    const defs = {};
    for (const prm of (first.params || [])) if (prm.def !== undefined) defs[prm.key] = prm.def;
    setParam(node, 'integration', integ.value);
    setParam(node, 'action', first.id || '');
    setParam(node, 'params', defs);
    renderInspector();
  });
  const act = $('#pAction');
  if (act) act.addEventListener('change', () => {
    const i = integrationOf(node.parameters.integration);
    const a = i && (i.actions || []).find((x) => x.id === act.value);
    const defs = {};
    for (const prm of (a ? a.params : [])) if (prm.def !== undefined) defs[prm.key] = prm.def;
    setParam(node, 'action', act.value);
    setParam(node, 'params', defs);
    renderInspector();
  });
  const cred = $('#pCredential');
  if (cred) cred.addEventListener('change', () => setParam(node, 'credentialId', cred.value));
  $$('#insScroll [data-ak]').forEach((el) => {
    const k = el.dataset.ak;
    const apply = () => { p.params = p.params || {}; p.params[k] = el.type === 'number' ? (el.value === '' ? '' : Number(el.value)) : el.value; markDirty(); };
    el.addEventListener('input', apply);
    el.addEventListener('change', apply);
  });
  const lnk = $('#lnkCreds');
  if (lnk) lnk.addEventListener('click', (e) => { e.preventDefault(); renderCredentialsModal(); });
}

function agentExtraHtml(node) {
  const p = node.parameters || {};
  const agents = state.registry ? state.registry.agents : [];
  const provs = state.registry ? state.registry.providers : [];
  const prov = providerOf(p.provider);
  const models = prov ? prov.models : [];
  let html = `<div class="field"><label>Agent type</label><select class="select" id="pAgentType">
    ${agents.map((a) => `<option value="${esc(a.id)}"${a.id === p.agentType ? ' selected' : ''}>${esc(a.name)}</option>`).join('')}</select></div>`;
  html += `<div class="field"><label>Model provider</label><select class="select" id="pAgentProvider">
    <option value="">— Workspace default —</option>
    ${provs.map((x) => `<option value="${esc(x.id)}"${x.id === p.provider ? ' selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div>`;
  html += `<div class="field"><label>Model</label><select class="select" id="pAgentModel">
    ${models.map((m) => `<option value="${esc(m.id)}"${m.id === p.model ? ' selected' : ''}>${esc(m.id)}</option>`).join('')}</select></div>`;
  html += credSelectHtml(node, p.provider);
  return html;
}

function bindAgentExtras(node) {
  const p = node.parameters || {};
  const at = $('#pAgentType');
  if (at) at.addEventListener('change', () => {
    const a = agentOf(at.value);
    setParam(node, 'agentType', at.value);
    if (a) setParam(node, 'system', a.system);
    renderInspector();
  });
  const ap = $('#pAgentProvider');
  if (ap) ap.addEventListener('change', () => {
    setParam(node, 'provider', ap.value);
    setParam(node, 'model', ap.value ? (providerOf(ap.value).models[0] || {}).id || '' : '');
    renderInspector();
  });
  const am = $('#pAgentModel');
  if (am) am.addEventListener('change', () => setParam(node, 'model', am.value));
  const cred = $('#pCredential');
  if (cred) cred.addEventListener('change', () => setParam(node, 'credentialId', cred.value));
  const lnk = $('#lnkCreds');
  if (lnk) lnk.addEventListener('click', (e) => { e.preventDefault(); renderCredentialsModal(); });
}

function renderInspector() {
  const node = state.workflow.nodes.find((n) => n.id === state.insNodeId);
  if (!node) return;
  $('#insScroll').innerHTML = currentTab === 'params' ? paramsHtml(node) : ioHtml(node);
  if (currentTab === 'params') bindParams(node);
  else bindIo(node);
}

function paramsHtml(node) {
  if (node.type === 'ai.model') return paramsHtmlModel(node);
  if (node.type === 'app.action') return paramsHtmlApp(node);
  const d = NODE_DEFS[node.type];
  if (!d) return '';
  let html = `<div class="field"><label>Name</label><input class="input" id="pName" value="${esc(node.name)}"></div>`;
  if (node.type === 'ai.agent') html += agentExtraHtml(node);
  if (node.type === 'trigger.webhook') {
    html += `<div class="field"><label>Webhook URL</label><input class="input mono" value="${location.origin}/api/hooks/${state.workflow.id}" readonly><div class="hint">POST or GET to this URL to trigger the workflow. Activate the workflow (top bar → Workflows → Active) first.</div></div>`;
  }
  for (const p of (d.params || [])) {
    const v = node.parameters[p.k];
    html += `<div class="field" data-pk="${p.k}">`;
    html += `<label>${esc(p.label)}</label>`;
    if (p.type === 'select') {
      html += `<select class="select" data-k="${p.k}">${p.options.map((o) => `<option value="${esc(o)}"${String(v) === o ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
    } else if (p.type === 'textarea') {
      html += `<textarea class="textarea" data-k="${p.k}" rows="3">${esc(v == null ? '' : v)}</textarea>`;
    } else if (p.type === 'code') {
      html += `<textarea class="textarea" data-k="${p.k}" rows="6" spellcheck="false">${esc(v == null ? '' : v)}</textarea>`;
    } else if (p.type === 'json') {
      html += `<textarea class="textarea" data-k="${p.k}" rows="3" spellcheck="false">${esc(v == null ? '' : v)}</textarea>`;
    } else if (p.type === 'number') {
      html += `<input class="input" data-k="${p.k}" type="number" value="${esc(v == null ? '' : v)}">`;
    } else if (p.type === 'password') {
      html += `<input class="input" data-k="${p.k}" type="password" value="${esc(v == null ? '' : v)}" autocomplete="off">`;
    } else if (p.type === 'boolean') {
      html += `<label class="check"><input type="checkbox" data-k="${p.k}"${v ? ' checked' : ''}> ${esc(p.label)}</label>`;
    } else if (p.type === 'kvs') {
      html += `<div class="kv-list" data-k="${p.k}">${(v || []).map((kv) => `<div class="kv-row"><input class="input" data-role="name" placeholder="Header" value="${esc(kv.name)}"><input class="input" data-role="value" placeholder="Value" value="${esc(kv.value)}"><button class="kv-del" type="button">✕</button></div>`).join('')}</div><button class="add-btn" data-add="${p.k}">+ Add header</button>`;
    } else if (p.type === 'assignments') {
      html += `<div class="kv-list" data-k="${p.k}">${(v || []).map((a) => `<div class="kv-row"><select class="select" data-role="type" style="flex:0 0 74px"><option value="set"${a.type !== 'remove' ? ' selected' : ''}>Set</option><option value="remove"${a.type === 'remove' ? ' selected' : ''}>Remove</option></select><input class="input" data-role="name" placeholder="Field" value="${esc(a.name)}"><input class="input" data-role="value" placeholder="Value / expression" value="${esc(a.value)}"><button class="kv-del" type="button">✕</button></div>`).join('')}</div><button class="add-btn" data-add="${p.k}">+ Add field</button>`;
    } else if (p.type === 'rules') {
      html += `<div class="kv-list" data-k="${p.k}">${(v || []).map((r) => `<div class="kv-row"><input class="input" data-role="value" placeholder="If value equals" value="${esc(r.value)}"><input class="input" data-role="output" placeholder="Output port" value="${esc(r.output)}"><button class="kv-del" type="button">✕</button></div>`).join('')}</div><button class="add-btn" data-add="${p.k}">+ Add route</button>`;
    } else {
      html += `<input class="input" data-k="${p.k}" value="${esc(v == null ? '' : v)}" spellcheck="false">`;
    }
    if (p.hint) html += `<div class="hint">${esc(p.hint)}</div>`;
    html += `</div>`;
  }
  return html;
}

function bindParams(node) {
  if (node.type === 'ai.model') { bindParamsModel(node); return; }
  if (node.type === 'app.action') { bindParamsApp(node); return; }
  const nameInput = $('#pName');
  if (nameInput) {
    nameInput.addEventListener('input', () => { node.name = nameInput.value; $('#insTitle').textContent = node.name; updateNodeEl(node); markDirty(); });
  }
  if (node.type === 'ai.agent') bindAgentExtras(node);
  $$('#insScroll [data-k]').forEach((el) => {
    const k = el.dataset.k;
    const isList = el.classList.contains('kv-list');
    if (isList) { bindListEditor(el, node, k); return; }
    if (el.tagName === 'SELECT') {
      el.addEventListener('change', () => { setParam(node, k, el.value); });
    } else if (el.type === 'checkbox') {
      el.addEventListener('change', () => { setParam(node, k, el.checked); });
    } else if (el.type === 'number') {
      el.addEventListener('input', () => { setParam(node, k, el.value === '' ? '' : Number(el.value)); });
    } else {
      el.addEventListener('input', () => { setParam(node, k, el.value); });
    }
  });
  $$('#insScroll [data-add]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const k = btn.dataset.add;
      const arr = node.parameters[k] || [];
      if (k === 'rules') arr.push({ value: '', output: '' });
      else if (k === 'assignments') arr.push({ name: '', value: '', type: 'set' });
      else arr.push({ name: '', value: '' });
      node.parameters[k] = arr;
      markDirty();
      const host = btn.parentElement;
      const scroll = $('#insScroll');
      const top = host.getBoundingClientRect().top - scroll.getBoundingClientRect().top + scroll.scrollTop;
      $('#insScroll').innerHTML = paramsHtml(node);
      bindParams(node);
      scroll.scrollTop = top + 60;
    });
  });
}

function bindListEditor(listEl, node, k) {
  const sync = () => {
    const rows = [];
    listEl.querySelectorAll('.kv-row').forEach((row) => {
      const t = row.querySelector('[data-role="type"]');
      const n = row.querySelector('[data-role="name"]');
      const v = row.querySelector('[data-role="value"]');
      const o = row.querySelector('[data-role="output"]');
      const entry = {};
      if (t) entry.type = t.value;
      if (n) entry.name = n.value;
      if (v) entry.value = v.value;
      if (o) entry.output = o.value;
      rows.push(entry);
    });
    setParam(node, k, rows);
  };
  listEl.addEventListener('input', sync);
  listEl.addEventListener('change', sync);
  listEl.querySelectorAll('.kv-del').forEach((b) => b.addEventListener('click', () => {
    sync();
    const list = node.parameters[k] || [];
    const idx = Array.from(listEl.querySelectorAll('.kv-row')).indexOf(b.closest('.kv-row'));
    if (idx >= 0) list.splice(idx, 1);
    setParam(node, k, list);
    $('#insScroll').innerHTML = paramsHtml(node);
    bindParams(node);
  }));
}

function setParam(node, k, v) {
  node.parameters = node.parameters || {};
  node.parameters[k] = v;
  updateNodeEl(node);
  renderEdges();
  markDirty();
}

/* ---- IO / test ---- */
function ioHtml(node) {
  const step = latestStep(node.id);
  let html = `<div class="field"><label>Test input (JSON)</label><textarea class="textarea mono" id="testInput" rows="3" spellcheck="false">${esc(state.testInput && state.testInput[node.id] ? state.testInput[node.id] : '{}')}</textarea><div class="hint">Input item fed to this node when you press “Test step”.</div></div>`;
  html += `<button class="btn" id="btnRunTest" style="width:100%;justify-content:center">▶ Run test step</button>`;
  if (state.testResults[node.id]) {
    html += `<div class="io-block" style="margin-top:14px"><div class="io-title">Test output</div>${esc(JSON.stringify(state.testResults[node.id], null, 2))}</div>`;
  }
  if (step) {
    html += `<div class="io-block" style="margin-top:6px"><div class="io-title">Last execution — input</div>${esc(JSON.stringify(step.input, null, 2))}</div>`;
    html += `<div class="io-block"><div class="io-title">Last execution — output</div>${esc(JSON.stringify(step.output, null, 2))}</div>`;
    if (step.error) html += `<div class="step-err">${esc(step.error)}</div>`;
  } else if (!state.testResults[node.id]) {
    html += `<p class="hint" style="margin-top:12px">No execution data yet. Run the workflow or test this step to inspect input/output.</p>`;
  }
  return html;
}

function latestStep(nodeId) {
  if (!state.lastExec) return null;
  return state.lastExec.steps.filter((s) => s.nodeId === nodeId).pop() || null;
}

function bindIo(node) {
  const ti = $('#testInput');
  if (ti) ti.addEventListener('input', () => { state.testInput = state.testInput || {}; state.testInput[node.id] = ti.value; });
  const btn = $('#btnRunTest');
  if (btn) btn.addEventListener('click', () => testNode(node));
}

async function testNode(node) {
  let input = {};
  const raw = (state.testInput && state.testInput[node.id]) || '{}';
  try { input = JSON.parse(raw || '{}'); } catch (e) { return toast('Test input is not valid JSON', 'err'); }
  const r = await api('/workflows/' + state.workflow.id + '/test-node', { method: 'POST', body: { nodeId: node.id, input: [{ json: input }] } });
  if (r.status !== 200) return toast('Test failed', 'err');
  if (r.data.error) toast('Node error: ' + r.data.error, 'err');
  else toast('Step executed', 'ok');
  state.testResults[node.id] = r.data.output || r.data.error || {};
  if (currentTab === 'io') { $('#insScroll').innerHTML = ioHtml(node); bindIo(node); }
}

/* ---------------- save ---------------- */
let saveTimer = null;
function markDirty() {
  state.dirty = true;
  setSaved(false);
  clearTimeout(saveTimer);
  saveTimer = setTimeout(save, 1400);
}

function setSaved(ok) {
  const ind = $('#savedInd');
  if (ok) {
    ind.classList.add('ok'); ind.classList.remove('err');
    $('#savedText').textContent = 'Saved · ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } else {
    ind.classList.remove('ok');
    $('#savedText').textContent = 'Unsaved changes…';
  }
}

async function save() {
  clearTimeout(saveTimer);
  if (!state.workflow) return;
  const body = { name: state.workflow.name, description: state.workflow.description || '', specification: state.workflow.specification || '', nodes: state.workflow.nodes, connections: state.workflow.connections, settings: state.workflow.settings || { env: {}, webhookSecret: '' }, active: state.workflow.active };
  const r = await api('/workflows/' + state.workflow.id, { method: 'PUT', body });
  if (r.status === 200) {
    state.workflow = r.data.workflow;
    state.dirty = false;
    setSaved(true);
  } else {
    $('#savedInd').classList.add('err');
    $('#savedText').textContent = 'Save failed';
  }
}

/* ---------------- execute ---------------- */
async function runWorkflow() {
  if (!state.workflow) return;
  if (state.running && state.running.status === 'running') return toast('A run is already in progress', 'err');
  await save();
  const r = await api('/workflows/' + state.workflow.id + '/execute', { method: 'POST', body: { trigger: 'manual' } });
  if (r.status !== 202) return toast('Execution failed to start', 'err');
  const exec = r.data.execution;
  state.running = { id: exec.id, status: 'running', done: 0, total: state.workflow.nodes.length };
  state.testResults = {};
  resetNodeStates();
  showChip();
  poll(exec.id);
}

function poll(id) {
  api('/executions/' + id).then((r) => {
    if (r.status !== 200 || state.running.id !== id) return;
    const e = r.data.execution;
    state.lastExec = e;
    applyExec(e);
    if (e.status === 'running') {
      setTimeout(() => poll(id), 350);
    } else {
      finishRun(e);
    }
  });
}

function resetNodeStates() {
  nodeEls.forEach((el) => {
    el.classList.remove('exec-running', 'exec-success', 'exec-error', 'exec-waiting');
    el.querySelector('.node-badge').className = 'node-badge';
  });
}

function applyExec(e) {
  const byNode = {};
  e.steps.forEach((s) => { byNode[s.nodeId] = s; });
  nodeEls.forEach((el, id) => {
    const s = byNode[id];
    el.classList.remove('exec-running', 'exec-success', 'exec-error', 'exec-waiting');
    const badge = el.querySelector('.node-badge');
    if (s) {
      if (s.status === 'running') { el.classList.add('exec-running'); badge.className = 'node-badge running'; }
      else if (s.status === 'success') { el.classList.add('exec-success'); badge.className = 'node-badge success'; }
      else { el.classList.add('exec-error'); badge.className = 'node-badge error'; }
    } else {
      el.classList.add('exec-waiting');
      badge.className = 'node-badge';
    }
  });
  state.running.done = e.steps.filter((s) => s.status !== 'running').length;
  $('#execProgress').style.width = Math.round((state.running.done / Math.max(1, state.running.total)) * 100) + '%';
  const runningStep = e.steps.find((s) => s.status === 'running');
  $('#ecText').textContent = e.status === 'running' ? (runningStep ? 'Running: ' + runningStep.nodeName : 'Running…') : e.status;
  $('#ecStatus').className = 'ec-status ' + e.status;
  const s = $('#ecStatus').querySelector('.sp'); if (s) s.className = 'sp';
  $('#ecMeta').textContent = state.running.done + '/' + state.running.total + ' nodes · ' + fmtDur(e.durationMs);
}

function finishRun(e) {
  const chip = $('#execChip');
  state.running = { id: e.id, status: e.status, done: state.running.total, total: state.running.total };
  $('#execProgress').style.width = '100%';
  $('#ecMeta').textContent = 'done in ' + fmtDur(e.durationMs);
  if (e.status === 'error') {
    $('#ecStatus').className = 'ec-status error';
    $('#ecText').textContent = 'Failed';
    toast('Workflow failed: ' + (e.error || 'unknown error'), 'err');
  } else {
    $('#ecStatus').className = 'ec-status success';
    $('#ecText').textContent = 'Succeeded';
    toast('Workflow completed in ' + fmtDur(e.durationMs), 'ok');
  }
  renderEdges();
  setTimeout(() => { if (state.running && state.running.status !== 'running') chip.classList.add('hidden'); }, 4000);
}

function showChip() {
  const chip = $('#execChip');
  chip.classList.remove('hidden');
  $('#execProgress').style.width = '0%';
  $('#ecStatus').className = 'ec-status running';
  $('#ecText').textContent = 'Running…';
  $('#ecMeta').textContent = '0/' + state.running.total + ' nodes';
}

function fmtDur(ms) {
  if (ms == null) return '—';
  if (ms < 1000) return ms + 'ms';
  return (ms / 1000).toFixed(1) + 's';
}

/* ---------------- executions drawer ---------------- */
let drawerOpen = false;
async function openExecDrawer() {
  drawerOpen = true;
  $('#execDrawer').classList.add('open');
  await refreshExecList();
}

function closeExecDrawer() {
  drawerOpen = false;
  $('#execDrawer').classList.remove('open');
}

async function refreshExecList() {
  if (!state.workflow) return;
  const r = await api('/workflows/' + state.workflow.id + '/executions');
  const execs = r.status === 200 ? (r.data.executions || []) : [];
  $('#execCount').textContent = execs.length ? execs.length + ' runs' : 'No runs yet';
  const host = $('#execList');
  host.innerHTML = '';
  if (!execs.length) {
    host.innerHTML = `<p class="hint" style="padding:14px 6px">No executions yet. Press “Execute workflow” to run it — nodes light up live as they run.</p>`;
    return;
  }
  for (const e of execs) {
    const row = document.createElement('div');
    row.className = 'exec-row';
    row.innerHTML = `<div class="exec-row-main">
      <span class="exec-st ${e.status}">${e.status}</span>
      <span class="exec-id">${esc(e.id)}</span>
      <span class="exec-dur">${fmtDur(e.durationMs)}</span>
      <span class="exec-time">${esc(new Date(e.startedAt).toLocaleString())}</span>
    </div><div class="exec-steps" style="display:none"></div>`;
    const stepsHost = row.querySelector('.exec-steps');
    row.querySelector('.exec-row-main').addEventListener('click', async () => {
      const vis = stepsHost.style.display !== 'none';
      stepsHost.style.display = vis ? 'none' : 'block';
      if (!vis && !stepsHost.dataset.loaded) {
        stepsHost.dataset.loaded = '1';
        const det = await api('/executions/' + e.id);
        stepsHost.innerHTML = renderSteps(det.data.execution);
      }
    });
    host.appendChild(row);
  }
}

function renderSteps(exec) {
  if (!exec || !exec.steps) return '';
  return exec.steps.map((s) => `
    <div class="step-row ${s.status}"><span class="sp"></span><span class="s-name">${esc(s.nodeName)}</span><span class="s-type">${esc(s.type)}</span><span class="s-dur">${fmtDur(s.durationMs)}</span></div>
    ${s.error ? `<div class="step-err">${esc(s.error)}</div>` : ''}
  `).join('');
}

/* ---------------- workflows modal ---------------- */
async function openWfModal() {
  const r = await api('/workflows');
  const wfs = r.status === 200 ? (r.data.workflows || []) : [];
  $('#modalTitle').textContent = 'Workflows';
  const body = $('#modalBody');
  body.innerHTML = '';
  if (!wfs.length) body.innerHTML = '<p class="hint">No workflows yet.</p>';
  for (const w of wfs) {
    const item = document.createElement('div');
    item.className = 'wf-list-item';
    item.innerHTML = `<span class="w-ico">${ICONS.bolt}</span>
      <span><span class="w-name">${esc(w.name)}</span><br><span class="w-meta">${w.nodeCount} nodes · last: ${esc(w.lastStatus || 'never run')} · ${esc(w.lastRunAt ? new Date(w.lastRunAt).toLocaleString() : '')}</span></span>
      <span class="w-actions">
        <button data-act="open">Open</button>
        <button data-act="dup">Duplicate</button>
        <button data-act="del">Delete</button>
      </span>
      <label class="switch" title="Active"><input type="checkbox" data-act="active"${w.active ? ' checked' : ''}><span class="track"></span></label>`;
    item.querySelector('[data-act="open"]').addEventListener('click', async () => {
      closeModal();
      try { await openWorkflow(w.id); } catch (e) { toast('Unable to load workflow', 'err'); }
    });
    item.querySelector('[data-act="dup"]').addEventListener('click', async () => {
      const full = await api('/workflows/' + w.id);
      if (full.status !== 200) return;
      const copy = JSON.parse(JSON.stringify(full.data.workflow));
      copy.name = copy.name + ' (copy)';
      copy.id = undefined;
      const cr = await api('/workflows', { method: 'POST', body: { name: copy.name } });
      if (cr.status !== 201) return;
      copy.id = cr.data.workflow.id;
      await api('/workflows/' + copy.id, { method: 'PUT', body: { name: copy.name, nodes: copy.nodes, connections: copy.connections, settings: copy.settings, active: false } });
      toast('Duplicated', 'ok');
      openWfModal();
    });
    item.querySelector('[data-act="del"]').addEventListener('click', async () => {
      if (!confirm('Delete "' + w.name + '" and its executions?')) return;
      await api('/workflows/' + w.id, { method: 'DELETE' });
      toast('Deleted', 'ok');
      if (state.workflow && state.workflow.id === w.id) { try { await loadFirstOrNew(); } catch (e) { toast('Unable to load workflow', 'err'); } }
      openWfModal();
    });
    item.querySelector('[data-act="active"]').addEventListener('change', async (e) => {
      await api('/workflows/' + w.id, { method: 'PUT', body: { active: e.target.checked, nodes: undefined, connections: undefined } });
      toast(e.target.checked ? 'Workflow activated' : 'Workflow deactivated', 'ok');
    });
    body.appendChild(item);
  }
  $('#modalPrimary').style.display = '';
  $('#modalPrimary').textContent = '+ New workflow';
  $('#modalPrimary').onclick = async () => { closeModal(); await save(); try { await createWorkflow('Untitled workflow'); } catch (e) { toast('Could not create workflow', 'err'); } };
  $('#modalBack').classList.add('open');
}

function closeModal() { $('#modalBack').classList.remove('open'); }

function openModal(title, primaryLabel) {
  $('#modalTitle').textContent = title;
  const p = $('#modalPrimary');
  p.style.display = primaryLabel ? '' : 'none';
  p.textContent = primaryLabel || '';
  $('#modalCancel').style.display = 'inline-flex';
  $('#modalBack').classList.add('open');
}

/* ---------------- credentials manager ---------------- */
function renderCredentialsModal() {
  openModal('Credentials', '+ New credential');
  const body = $('#modalBody');
  body.innerHTML = '';
  if (!state.credentials.length) {
    body.innerHTML = `<div class="lib-empty">No credentials connected yet.<br><br>Add an API key or OAuth token to power AI models and apps. Secrets are stored AES-256 encrypted.</div>`;
  }
  for (const c of state.credentials) {
    const row = document.createElement('div');
    row.className = 'cred-row';
    const fieldStr = Object.keys(c.fields || {}).map((k) => k + ': ' + (c.fields[k] || '')).join(' · ');
    row.innerHTML = `<div class="c-info"><div class="c-name">${esc(c.name)}</div><div class="c-meta">${esc(c.provider || c.type)}${fieldStr ? ' · ' + esc(fieldStr) : ''}</div></div>
      <span class="c-type">${esc(c.type)}</span>
      <button class="btn btn-ghost" data-cdel="${esc(c.id)}">Delete</button>`;
    body.appendChild(row);
  }
  body.querySelectorAll('[data-cdel]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('Delete this credential? Workflows using it will fail until another credential is selected.')) return;
    await api('/credentials/' + b.dataset.cdel, { method: 'DELETE' });
    state.credentials = state.credentials.filter((c) => c.id !== b.dataset.cdel);
    toast('Credential deleted', 'ok');
    renderCredentialsModal();
  }));
  $('#modalPrimary').onclick = () => renderCredentialForm();
}

function renderCredentialForm() {
  openModal('New credential', 'Create credential');
  const provs = state.registry ? state.registry.providers : [];
  const ints = state.registry ? state.registry.integrations : [];
  const targets = [
    ...provs.map((p) => ({ id: p.id, name: p.name, auth: p.auth })),
    ...ints.map((i) => ({ id: i.id, name: i.name, auth: i.auth })),
  ];
  const TYPES = ['apiKey', 'oauth2', 'bearer', 'basic', 'jwt', 'header', 'customOAuth', 'local'];
  const TYPE_LABELS = { apiKey: 'API Key', oauth2: 'OAuth2', bearer: 'Bearer Token', basic: 'Basic Auth', jwt: 'JWT', header: 'Custom Header', customOAuth: 'Custom OAuth', local: 'CLI / local connection' };
  const body = $('#modalBody');
  body.innerHTML = `
    <div class="field"><label>Name</label><input class="input" id="cName" placeholder="My OpenAI key"></div>
    <div class="field"><label>Provider / app</label><select class="select" id="cTarget">${targets.map((t) => `<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('')}</select></div>
    <div class="field"><label>Credential type</label><select class="select" id="cType">${TYPES.map((t) => `<option value="${t}">${TYPE_LABELS[t]}</option>`).join('')}</select></div>
    <div id="cFields"></div>`;
  const tSel = $('#cTarget');
  const tType = $('#cType');
  const fieldHost = $('#cFields');
  function drawFields() {
    const t = targets.find((x) => x.id === tSel.value);
    tType.value = (t && t.auth && t.auth.type) || 'apiKey';
    if (!t || !t.auth || !t.auth.fields || !t.auth.fields.length) {
      fieldHost.innerHTML = `<div class="auth-note">${t && t.auth ? esc(t.auth.notes || 'No secret fields required for this connection.') : 'No secret fields required.'}</div>`;
      return;
    }
    fieldHost.innerHTML = (t.auth.fields || []).map((f) => `
      <div class="field"><label>${esc(f.label)}</label>
      <input class="input" type="${f.secret ? 'password' : 'text'}" data-cf="${esc(f.key)}" autocomplete="off" placeholder="${esc(f.label)}"></div>`).join('');
  }
  tSel.addEventListener('change', drawFields);
  drawFields();
  $('#modalPrimary').onclick = async () => {
    const name = $('#cName').value.trim();
    if (!name) return toast('Give the credential a name.', 'err');
    const fields = {};
    fieldHost.querySelectorAll('[data-cf]').forEach((el) => { if (el.value) fields[el.dataset.cf] = el.value; });
    const r = await api('/credentials', { method: 'POST', body: { name, type: tType.value, provider: tSel.value, fields } });
    if (r.status === 201) {
      state.credentials.unshift(r.data.credential);
      toast('Credential saved (encrypted)', 'ok');
      renderCredentialsModal();
    } else toast(r.data.error || 'Could not save credential', 'err');
  };
}

/* ---------------- templates ---------------- */
async function renderTemplatesModal() {
  openModal('Templates', 'Save current as template');
  const body = $('#modalBody');
  const r = await api('/templates');
  const list = r.status === 200 ? (r.data.templates || []) : [];
  body.innerHTML = '';
  if (!list.length) body.innerHTML = `<div class="lib-empty">No templates yet.<br><br>Save the current workflow as a template to reuse it later.</div>`;
  for (const t of list) {
    const row = document.createElement('div');
    row.className = 'cred-row';
    row.innerHTML = `<div class="c-info"><div class="c-name">${esc(t.name)}</div><div class="c-meta">${t.nodeCount} nodes · ${esc(new Date(t.createdAt).toLocaleDateString())}${t.description ? ' · ' + esc(t.description) : ''}</div></div>
      <button class="btn" data-use="${esc(t.id)}">Use</button>
      <button class="btn btn-ghost" data-tdel="${esc(t.id)}">Delete</button>`;
    body.appendChild(row);
  }
  body.querySelectorAll('[data-use]').forEach((b) => b.addEventListener('click', async () => {
    const full = await api('/templates/' + b.dataset.use);
    if (full.status !== 200) return toast('Could not load template', 'err');
    const wf = full.data.template.workflow || {};
    pushHistory();
    state.workflow.nodes = JSON.parse(JSON.stringify(wf.nodes || []));
    state.workflow.connections = JSON.parse(JSON.stringify(wf.connections || []));
    if (wf.settings) state.workflow.settings = JSON.parse(JSON.stringify(wf.settings));
    state.selected.clear(); state.selectedEdge = null;
    renderAll(); centerView(); markDirty(); closeModal();
    toast('Template applied', 'ok');
  }));
  body.querySelectorAll('[data-tdel]').forEach((b) => b.addEventListener('click', async () => {
    await api('/templates/' + b.dataset.tdel, { method: 'DELETE' });
    toast('Template deleted', 'ok');
    renderTemplatesModal();
  }));
  $('#modalPrimary').onclick = async () => {
    const name = prompt('Template name:', state.workflow.name + ' template');
    if (!name) return;
    await api('/templates', { method: 'POST', body: { name, description: state.workflow.description || '', workflow: { nodes: state.workflow.nodes, connections: state.workflow.connections, settings: state.workflow.settings || {} } } });
    toast('Template saved', 'ok');
    renderTemplatesModal();
  };
}

/* ---------------- build with AI ---------------- */
function openBuildModal() {
  openModal('Build with AI', 'Generate workflow');
  const body = $('#modalBody');
  body.innerHTML = `
    <p class="hint" style="margin:0 0 8px">Describe the workflow in plain language. Core AI plans the nodes, then places them on the canvas — fully editable.</p>
    <textarea class="textarea build-area" id="buildPrompt" placeholder="e.g. Create a workflow that receives a customer question, sends it to an AI agent, searches Google Drive for relevant documents, generates an answer, and sends the response to Telegram."></textarea>
    <div class="build-examples">
      <button class="build-ex">Support triage: incoming question → Support Agent → reply via Telegram</button>
      <button class="build-ex">Research: search YouTube and Reddit, summarize with an AI model</button>
      <button class="build-ex">Lead enrichment: webhook → AI Agent → Google Maps geocode → save to a file</button>
    </div>`;
  body.querySelectorAll('.build-ex').forEach((b) => b.addEventListener('click', () => { $('#buildPrompt').value = b.textContent; }));
  $('#modalPrimary').onclick = runBuild;
}

async function runBuild() {
  const prompt = $('#buildPrompt').value.trim();
  if (!prompt) return toast('Describe the workflow first.', 'err');
  $('#modalBody').innerHTML = `<div class="build-busy"><span class="spinner"></span> Planning your workflow…</div>`;
  const r = await api('/ai/build', { method: 'POST', body: { prompt } });
  if (r.status !== 200) {
    toast(r.data.error || 'Could not build the workflow', 'err');
    openBuildModal();
    return;
  }
  const plan = r.data.plan;
  const nodes = plan.nodes || [];
  const conns = plan.connections || [];
  if (!nodes.length) { toast('Could not plan that workflow — try describing the apps and steps.', 'err'); openBuildModal(); return; }
  pushHistory();
  const idMap = {};
  const fresh = nodes.map((pn) => {
    const nid = 'nd_' + Math.random().toString(36).slice(2, 10);
    idMap[pn.id] = nid;
    return { id: nid, type: pn.type, name: pn.name, position: { x: pn.position.x, y: pn.position.y }, parameters: pn.parameters || {} };
  });
  const isBlank = state.workflow.nodes.length <= 1;
  if (isBlank) {
    state.workflow.nodes = fresh;
    state.workflow.connections = conns.map((c) => ({ from: idMap[c.from], out: c.out || 'main', to: idMap[c.to], in: c.in || 0 }));
    state.workflow.name = plan.name || state.workflow.name;
    updateNameField();
  } else {
    const existingIds = new Set(state.workflow.nodes.map((n) => n.id));
    const base = state.workflow.nodes.length;
    let y = Math.max(...state.workflow.nodes.map((n) => n.position.y)) + 180;
    for (const fn of fresh) { fn.position.y += y; state.workflow.nodes.push(fn); }
    for (const c of conns) if (idMap[c.from] && idMap[c.to]) state.workflow.connections.push({ from: idMap[c.from], out: c.out || 'main', to: idMap[c.to], in: c.in || 0 });
  }
  state.selected = new Set(Object.values(idMap));
  state.selectedEdge = null;
  renderAll(); refreshSelection(); markDirty(); closeModal(); centerView();
  toast('Workflow generated: ' + (plan.name || 'done') + ' (' + (r.data.planner || 'planner') + ')', 'ok');
}

/* ---------------- history ---------------- */
function snapshot() {
  return { nodes: JSON.parse(JSON.stringify(state.workflow.nodes)), connections: JSON.parse(JSON.stringify(state.workflow.connections)) };
}
function pushHistory() {
  const snap = snapshot();
  state.history = state.history.slice(0, state.hIndex + 1);
  state.history.push(snap);
  if (state.history.length > 80) state.history.shift();
  state.hIndex = state.history.length - 1;
}
function restoreHistory(snap) {
  state.workflow.nodes = JSON.parse(JSON.stringify(snap.nodes));
  state.workflow.connections = JSON.parse(JSON.stringify(snap.connections));
  renderAll();
  markDirty();
}
function undo() {
  if (state.hIndex > 0) { state.hIndex--; restoreHistory(state.history[state.hIndex]); }
}
function redo() {
  if (state.hIndex < state.history.length - 1) { state.hIndex++; restoreHistory(state.history[state.hIndex]); }
}

/* ---------------- interactions ---------------- */
function applyView() { applyTransform(); }

canvasWrap.addEventListener('wheel', (e) => {
  e.preventDefault();
  const factor = e.deltaY < 0 ? 1.1 : 1 / 1.1;
  zoomAt(factor, e.clientX, e.clientY);
}, { passive: false });

let panStart = null, panning = false, marquee = null;

canvasWrap.addEventListener('mousedown', (e) => {
  if (e.target.closest('.boot-overlay')) return;
  if (e.button !== 0) { middlePan(e); return; }
  if (e.target.closest('.node') || e.target.closest('.edge-hit') || e.target.closest('.palette')) return;
  if (e.shiftKey) { startMarquee(e); return; }
  panStart = { x: e.clientX, y: e.clientY, px: state.pan.x, py: state.pan.y };
  panning = true;
  canvasWrap.classList.add('dragging');
  clearSelection();
  e.preventDefault();
});

function middlePan(e) {
  if (e.button !== 1) return;
  e.preventDefault();
  const sx = e.clientX, sy = e.clientY, px = state.pan.x, py = state.pan.y;
  const move = (ev) => { state.pan.x = px + (ev.clientX - sx); state.pan.y = py + (ev.clientY - sy); applyView(); renderEdges(); };
  const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); };
  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
}

document.addEventListener('mousemove', (e) => {
  if (panning && panStart) {
    state.pan.x = panStart.px + (e.clientX - panStart.x);
    state.pan.y = panStart.py + (e.clientY - panStart.y);
    applyView();
    renderEdges();
  }
  if (marquee) {
    const rect = marquee;
    const x = Math.min(rect.sx, e.clientX), y = Math.min(rect.sy, e.clientY);
    const w = Math.abs(e.clientX - rect.sx), h = Math.abs(e.clientY - rect.sy);
    const el = $('#marquee');
    el.style.display = 'block';
    el.style.left = x + 'px'; el.style.top = y + 'px'; el.style.width = w + 'px'; el.style.height = h + 'px';
    rect.ex = e.clientX; rect.ey = e.clientY;
  }
  if (tempConnect) {
    const to = worldFromEvent(e);
    const a = tempConnect.from;
    const d = bezier(a, to);
    tempConnect.path.setAttribute('d', d);
  }
});

document.addEventListener('mouseup', (e) => {
  if (panning) { panning = false; panStart = null; canvasWrap.classList.remove('dragging'); }
  if (marquee) { endMarquee(); }
  if (tempConnect) { endConnect(e); }
  if (nodeDrag) { endNodeDrag(); }
});

function startMarquee(e) {
  marquee = { sx: e.clientX, sy: e.clientY };
  const el = $('#marquee');
  el.style.left = e.clientX + 'px'; el.style.top = e.clientY + 'px';
  el.style.width = '0'; el.style.height = '0';
}

function endMarquee() {
  const el = $('#marquee');
  el.style.display = 'none';
  if (!marquee) return;
  const r = { x: Math.min(marquee.sx, marquee.ex), y: Math.min(marquee.sy, marquee.ey), w: Math.abs(marquee.sx - marquee.ex), h: Math.abs(marquee.sy - marquee.ey) };
  marquee = null;
  if (r.w < 6 && r.h < 6) return;
  const wr = world.getBoundingClientRect();
  const ids = [];
  nodeEls.forEach((el, id) => {
    const b = el.getBoundingClientRect();
    const nx = b.left - wr.left, ny = b.top - wr.top;
    if (nx < r.x + r.w && nx + b.width > r.x && ny < r.y + r.h && ny + b.height > r.y) ids.push(id);
  });
  state.selected = new Set(ids);
  state.selectedEdge = null;
  refreshSelection();
  if (ids.length === 1) openInspector(ids[0]); else if (ids.length > 1) closeInspector();
}

/* node drag */
let nodeDrag = null;
function nodeMouseDown(e, node) {
  e.preventDefault();
  if (!state.selected.has(node.id)) {
    if (!e.shiftKey) state.selected.clear();
    state.selected.add(node.id);
    state.selectedEdge = null;
    refreshSelection();
  }
  openInspector(node.id);
  const startWx = worldFromEvent(e);
  const origins = {};
  state.selected.forEach((id) => {
    const n = state.workflow.nodes.find((x) => x.id === id);
    if (n) origins[id] = { x: n.position.x, y: n.position.y };
  });
  nodeDrag = { startWx, origins };
}

function endNodeDrag() {
  if (!nodeDrag) return;
  nodeDrag = null;
  pushHistory();
  markDirty();
}

document.addEventListener('mousemove', (e) => {
  if (!nodeDrag) return;
  const wx = worldFromEvent(e);
  const dx = wx.x - nodeDrag.startWx.x, dy = wx.y - nodeDrag.startWx.y;
  for (const [id, o] of Object.entries(nodeDrag.origins)) {
    const n = state.workflow.nodes.find((x) => x.id === id);
    if (!n) continue;
    n.position.x = Math.round(o.x + dx);
    n.position.y = Math.round(o.y + dy);
    const el = nodeEls.get(id);
    if (el) { el.style.left = n.position.x + 'px'; el.style.top = n.position.y + 'px'; }
  }
  renderEdges();
});

/* connections */
let tempConnect = null;
function startConnect(node, e) {
  const from = portPos(e.target.closest('.node-out').querySelector('.o-dot') || e.target);
  const out = e.target.closest('.node-out').dataset.port;
  const svg = $('#connSvg');
  const ns = 'http://www.w3.org/2000/svg';
  const path = document.createElementNS(ns, 'path');
  path.setAttribute('class', 'temp-edge');
  path.setAttribute('d', bezier(from, from));
  svg.appendChild(path);
  tempConnect = { from, out, nodeId: node.id, path };
}

function endConnect(e) {
  const tc = tempConnect;
  tempConnect = null;
  tc.path.remove();
  const overIn = e.target.closest('.node-in');
  if (!overIn) { renderEdges(); return; }
  const toNode = overIn.closest('.node');
  if (!toNode || toNode.dataset.id === tc.nodeId) { renderEdges(); return; }
  pushHistory();
  const conn = { from: tc.nodeId, out: tc.out, to: toNode.dataset.id, in: 0 };
  if (!state.workflow.connections.some((c) => c.from === conn.from && c.out === conn.out && c.to === conn.to)) {
    state.workflow.connections.push(conn);
  }
  markDirty();
  renderEdges();
}

/* ---------------- keyboard ---------------- */
document.addEventListener('keydown', (e) => {
  const inField = /INPUT|TEXTAREA|SELECT/.test(e.target.tagName);
  const mod = e.metaKey || e.ctrlKey;
  if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); save(); return; }
  if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicateNodes([...state.selected]); return; }
  if (mod && e.key.toLowerCase() === 'c') {
    if (inField) return;
    e.preventDefault();
    state.clipboard = [...state.selected];
    toast('Copied ' + state.clipboard.length + ' node(s)', 'ok');
    return;
  }
  if (mod && e.key.toLowerCase() === 'v') {
    if (inField) return;
    e.preventDefault();
    duplicateNodes(state.clipboard || [...state.selected]);
    return;
  }
  if (mod && e.key.toLowerCase() === 'z') { if (inField) return; e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
  if (mod && e.key.toLowerCase() === 'y') { if (inField) return; e.preventDefault(); redo(); return; }
  if (mod && e.key.toLowerCase() === 'a') { if (inField) return; e.preventDefault(); state.selected = new Set(state.workflow.nodes.map((n) => n.id)); refreshSelection(); return; }
  if (e.key === 'Delete' || e.key === 'Backspace') {
    if (inField) return;
    e.preventDefault();
    if (state.selectedEdge) {
      pushHistory();
      const c = state.selectedEdge;
      state.workflow.connections = state.workflow.connections.filter((x) => x !== c);
      state.selectedEdge = null;
      renderEdges(); markDirty(); closeInspector();
    } else if (state.selected.size) {
      deleteNodes([...state.selected]);
    }
    return;
  }
  if (e.key === 'Escape') {
    closeModal(); closeExecDrawer(); clearSelection();
    return;
  }
});

/* ---------------- topbar wiring ---------------- */
function updateNameField() {
  $('#wfName').value = state.workflow ? state.workflow.name : '';
}

$('#wfName').addEventListener('input', () => {
  if (state.workflow) { state.workflow.name = $('#wfName').value; markDirty(); }
});

$('#btnSave').addEventListener('click', save);
$('#btnRun').addEventListener('click', runWorkflow);
$('#btnNew').addEventListener('click', async () => {
  await save();
  try { await createWorkflow('Untitled workflow'); } catch (e) { toast('Could not create workflow', 'err'); }
});
$('#wfListBtn').addEventListener('click', openWfModal);
$('#btnExecs').addEventListener('click', openExecDrawer);
$('#execClose').addEventListener('click', closeExecDrawer);
$('#zoomIn').addEventListener('click', () => zoomAt(1.2, canvasWrap.getBoundingClientRect().left + canvasWrap.getBoundingClientRect().width / 2, canvasWrap.getBoundingClientRect().top + canvasWrap.getBoundingClientRect().height / 2));
$('#zoomOut').addEventListener('click', () => zoomAt(1 / 1.2, canvasWrap.getBoundingClientRect().left + canvasWrap.getBoundingClientRect().width / 2, canvasWrap.getBoundingClientRect().top + canvasWrap.getBoundingClientRect().height / 2));
$('#zoomFit').addEventListener('click', centerView);
$('#insClose').addEventListener('click', () => { clearSelection(); });
$('#btnDuplicate').addEventListener('click', () => { if (state.insNodeId) duplicateNodes([state.insNodeId]); });
$('#btnDelete').addEventListener('click', () => { if (state.insNodeId) deleteNodes([state.insNodeId]); });
$('#btnTestNode').addEventListener('click', () => { const n = state.workflow.nodes.find((x) => x.id === state.insNodeId); if (n) testNode(n); });
$$('.ins-tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));
$('#palSearch').addEventListener('input', (e) => { state.libSearch = e.target.value; renderPalette(); });
$('#avatarBtn').addEventListener('click', (e) => { e.stopPropagation(); $('#avatarMenu').classList.toggle('open'); });
document.addEventListener('click', (e) => { if (!e.target.closest('#avatarMenu') && !e.target.closest('#avatarBtn')) $('#avatarMenu').classList.remove('open'); });
$('#amAssistant').addEventListener('click', () => location.href = '/app#/');
$('#amDocs').addEventListener('click', () => location.href = '/#how');
$('#amSignout').addEventListener('click', () => { location.href = '/'; });
$('#modalClose').addEventListener('click', closeModal);
$('#modalCancel').addEventListener('click', closeModal);
$('#modalBack').addEventListener('click', (e) => { if (e.target === $('#modalBack')) closeModal(); });

/* ---- Build with AI + side nav ---- */
$('#btnBuild').addEventListener('click', openBuildModal);
$$('#sideNav .side-item').forEach((btn) => btn.addEventListener('click', () => {
  const a = btn.dataset.action;
  $$('#sideNav .side-item').forEach((b) => b.classList.remove('active'));
  if (a === 'library') { state.libFilter = 'ALL'; state.libSearch = ''; $('#palSearch').value = ''; renderPalette(); btn.classList.add('active'); }
  else if (a === 'workflows') openWfModal();
  else if (a === 'models') { state.libFilter = 'AI'; state.libSearch = ''; $('#palSearch').value = ''; renderPalette(); }
  else if (a === 'agents') { state.libFilter = 'AI'; state.libSearch = ''; $('#palSearch').value = ''; renderPalette(); scrollToPalCat('AI Agents'); }
  else if (a === 'apps') { state.libFilter = 'APPS'; state.libSearch = ''; $('#palSearch').value = ''; renderPalette(); }
  else if (a === 'credentials') renderCredentialsModal();
  else if (a === 'templates') renderTemplatesModal();
  else if (a === 'executions') openExecDrawer();
  else if (a === 'build') openBuildModal();
  else if (a === 'soon') toast('Coming soon — this section is on the roadmap.', '');
}));

/* ---------------- views: canvas / spec / code ---------------- */
let currentView = 'canvas';
function switchView(view) {
  currentView = view;
  $('#specView').classList.toggle('active', view === 'spec');
  $('#codeView').classList.toggle('active', view === 'code');
  $$('#viewSeg button').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
  $('#btnCodeLabel').textContent = view === 'code' ? 'Close code' : 'View code';
  if (view === 'spec' && state.workflow) {
    $('#specEditor').value = state.workflow.specification || '';
  }
  if (view === 'code' && state.workflow) {
    $('#codeEditor').value = JSON.stringify({
      name: state.workflow.name,
      description: state.workflow.description || '',
      specification: state.workflow.specification || '',
      nodes: state.workflow.nodes,
      connections: state.workflow.connections,
      settings: state.workflow.settings || { env: {}, webhookSecret: '' },
    }, null, 2);
  }
}

$('#btnSpecSave').addEventListener('click', async () => {
  if (!state.workflow) return;
  state.workflow.specification = $('#specEditor').value;
  await save();
  toast('Specification saved', 'ok');
});

$('#specEditor').addEventListener('input', () => {
  if (!state.workflow) return;
  state.workflow.specification = $('#specEditor').value;
  markDirty();
});

$('#btnCode').addEventListener('click', () => switchView(currentView === 'code' ? 'canvas' : 'code'));

$('#btnCodeClose').addEventListener('click', () => switchView('canvas'));

$('#btnCodeApply').addEventListener('click', async () => {
  if (!state.workflow) return;
  let parsed;
  try { parsed = JSON.parse($('#codeEditor').value); } catch (e) { return toast('Invalid JSON: ' + e.message, 'err'); }
  if (!Array.isArray(parsed.nodes)) return toast('JSON must include a "nodes" array', 'err');
  pushHistory();
  if (parsed.name) state.workflow.name = String(parsed.name);
  state.workflow.nodes = parsed.nodes;
  state.workflow.connections = Array.isArray(parsed.connections) ? parsed.connections : [];
  state.workflow.specification = String(parsed.specification || '');
  state.workflow.settings = parsed.settings || { env: {}, webhookSecret: '' };
  state.selected.clear(); state.selectedEdge = null;
  renderAll(); updateNameField(); markDirty();
  await save();
  switchView('canvas');
  toast('Workflow updated from JSON', 'ok');
});

$$('#viewSeg button').forEach((b) => b.addEventListener('click', () => switchView(b.dataset.view)));

/* ---------------- init ---------------- */
renderPalette();
applyView();
boot();

})();
