'use strict';
/* ============================================================
   Core AI — cinematic agent-workflow demo animation
   ============================================================ */
(function () {
  var board = document.getElementById('demoBoard');
  if (!board) return;

  var svg = document.getElementById('wfSvg');
  var playOverlay = document.getElementById('boardPlay');
  var doneBanner = document.getElementById('boardDone');
  var bcPlay = document.getElementById('bcPlay');
  var bcReplay = document.getElementById('bcReplay');
  var bcFill = document.getElementById('bcFill');
  var bcStatus = document.getElementById('bcStatus');

  var nodes = Array.prototype.slice.call(document.querySelectorAll('.wf-node'));

  // --- timeline constants (ms) ---
  var TOTAL = 10600;
  var HOLD = 1600;
  var DRAW = 480;
  var TRAVEL = 620;
  var DONE_AT = 10200;

  // 10 nodes: 0 Trigger, 1 Research, 2 Knowledge, 3 AI Agent, 4 Decision,
  // 5 Action, 6 Sales, 7 Support, 8 Email, 9 Human Handoff
  var APPEAR = [0, 1500, 3000, 4500, 6000, 9600, 7900, 7600, 7900, 7900];
  var RUN_AT = [400, 1950, 3450, 4950, 6500, 9900, Infinity, 8100, Infinity, Infinity];
  var DONE_AT_NODE = [1500, 3000, 4500, 6000, 9600, 10200, Infinity, 8600, Infinity, Infinity];
  var IS_BRANCH = { 6: 'skipped', 7: 'active', 8: 'ready', 9: 'ready' };
  var STATUS = {
    appear: ['Triggered', 'Processing', 'Retrieving', 'Generating', 'Evaluating', 'Executing', 'Skipped', 'Processing', 'Ready', 'Ready'],
    run:    ['Processing', 'Analysing', 'Indexing', 'Drafting', 'Routing', 'Sending', 'Skipped', 'Replying', 'Ready', 'Ready'],
    done:   ['Completed', 'Completed', 'Completed', 'Completed', 'Completed', 'Completed', 'Skipped', 'Completed', 'Ready', 'Ready'],
  };

  // edges: main bezier + branch orthogonal
  var EDGES = [
    { from: 0, to: 1, draw: 400,  packet: 950,  mode: 'main' },
    { from: 1, to: 2, draw: 1950, packet: 2450, mode: 'main' },
    { from: 2, to: 3, draw: 3450, packet: 3950, mode: 'main' },
    { from: 3, to: 4, draw: 4950, packet: 5450, mode: 'main' },
    { from: 4, to: 7, draw: 6500, packet: 7100, mode: 'branch', active: true },
    { from: 4, to: 6, draw: 7700, packet: null, mode: 'branch', dim: true },
    { from: 4, to: 8, draw: 7700, packet: null, mode: 'branch', dim: true },
    { from: 4, to: 9, draw: 7700, packet: null, mode: 'branch', dim: true },
    { from: 4, to: 5, draw: 8600, packet: 9100, mode: 'main' },
  ];

  var STATUS_TEXT = [
    [0,     'Triggering…'],
    [1500,  'Researching…'],
    [3000,  'Retrieving knowledge…'],
    [4500,  'Generating response…'],
    [6000,  'Evaluating…'],
    [6500,  'Routing to Support Agent…'],
    [7600,  'Support Agent replying…'],
    [9600,  'Executing…'],
    [10200, 'Completed ✓'],
  ];

  // --- svg gradient def ---
  var defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
  var grad = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
  grad.setAttribute('id', 'wfGrad');
  grad.setAttribute('x1', '0'); grad.setAttribute('y1', '0');
  grad.setAttribute('x2', '1'); grad.setAttribute('y2', '0');
  var s1 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
  s1.setAttribute('offset', '0%'); s1.setAttribute('stop-color', '#818cf8');
  var s2 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
  s2.setAttribute('offset', '100%'); s2.setAttribute('stop-color', '#c084fc');
  grad.appendChild(s1); grad.appendChild(s2);
  defs.appendChild(grad);
  svg.appendChild(defs);

  // --- connector elements ---
  var conns = EDGES.map(function () {
    var p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('class', 'wf-connector');
    p.setAttribute('d', 'M0 0 L1 0');
    svg.appendChild(p);
    var c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    c.setAttribute('class', 'wf-packet');
    c.setAttribute('r', '4.5');
    c.setAttribute('visibility', 'hidden');
    svg.appendChild(c);
    var e1 = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    e1.setAttribute('class', 'wf-endpoint');
    e1.setAttribute('r', '3');
    svg.appendChild(e1);
    var e2 = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    e2.setAttribute('class', 'wf-endpoint');
    e2.setAttribute('r', '3');
    svg.appendChild(e2);
    return { path: p, packet: c, ep1: e1, ep2: e2, length: 1 };
  });

  var stacked = false;
  var svgWidth = 1;

  function point(box, x, y) {
    return { x: box.left + box.width * x, y: box.top + box.height * y };
  }

  function layout() {
    var svgRect = svg.getBoundingClientRect();
    svgWidth = svgRect.width;
    var boxes = nodes.map(function (n) { return n.getBoundingClientRect(); });
    // relative boxes
    boxes = boxes.map(function (b) {
      return { left: b.left - svgRect.left, top: b.top - svgRect.top, width: b.width, height: b.height, right: b.right - svgRect.left, bottom: b.bottom - svgRect.top };
    });
    // detect stacked (mobile) layout: Trigger and Research share a column
    stacked = Math.abs(boxes[1].left - boxes[0].left) < 20;

    conns.forEach(function (conn, i) {
      var e = EDGES[i];
      var a = boxes[e.from];
      var b = boxes[e.to];
      var acx = a.left + a.width / 2, acy = a.top + a.height / 2;
      var bcx = b.left + b.width / 2, bcy = b.top + b.height / 2;

      var d;
      if (e.mode === 'branch') {
        d = branchPath(a, b, i);
      } else {
        var horizontal = Math.abs(bcy - acy) <= Math.abs(bcx - acx);
        if (horizontal) {
          var sy, ey;
          var sx, ex;
          if (acx <= bcx) { sx = a.right; ex = b.left; }   // a is left of b
          else            { sx = a.left;  ex = b.right; }  // a is right of b
          sy = acy; ey = bcy;
          var mx = (sx + ex) / 2;
          d = 'M' + sx + ' ' + sy + ' C' + mx + ' ' + sy + ', ' + mx + ' ' + ey + ', ' + ex + ' ' + ey;
        } else {
          var sy2 = a.bottom, ey2 = b.top, sx2 = acx, ex2 = bcx;
          var my = (sy2 + ey2) / 2;
          d = 'M' + sx2 + ' ' + sy2 + ' C' + sx2 + ' ' + my + ', ' + ex2 + ' ' + my + ', ' + ex2 + ' ' + ey2;
        }
      }
      conn.path.setAttribute('d', d);
      try { conn.length = conn.path.getTotalLength() || 1; } catch (err) { conn.length = 1; }
      conn.path.style.strokeDasharray = conn.length;
      conn.path.style.strokeDashoffset = conn.length;

      // endpoint dots at the two path extremes
      try {
        var ps = conn.path.getPointAtLength(0);
        var pe = conn.path.getPointAtLength(conn.length);
        conn.ep1.setAttribute('cx', ps.x); conn.ep1.setAttribute('cy', ps.y);
        conn.ep2.setAttribute('cx', pe.x); conn.ep2.setAttribute('cy', pe.y);
      } catch (err) {}
    });
  }

  function branchPath(a, b, edgeIndex) {
    var idx = EDGES[edgeIndex].to - 6; // 0..3 across branches
    if (stacked) {
      // single-column layout: route down a right-side rail to avoid the
      // Action node that sits between Decision and the branches.
      var railX = Math.min(b.right + 12 + idx * 13, svgWidth - 6);
      var yOut = a.top + a.height / 2;
      var yIn = b.top + b.height / 2;
      return 'M' + a.right + ' ' + yOut + ' L' + railX + ' ' + yOut + ' L' + railX + ' ' + yIn + ' L' + b.right + ' ' + yIn;
    }
    // desktop: fan out from the Decision node's bottom edge (staggered rails)
    var tx = b.left + b.width / 2;
    var ty = b.top;
    var sx = a.left + a.width * (0.22 + 0.17 * idx);
    var sy = a.bottom;
    var busY = a.bottom + 20 + idx * 13;
    return 'M' + sx + ' ' + sy + ' L' + sx + ' ' + busY + ' L' + tx + ' ' + busY + ' L' + tx + ' ' + ty;
  }

  // --- animation state ---
  var elapsed = 0;
  var lastTs = null;
  var raf = null;
  var playing = false;
  var started = false;

  function setNode(i, state, text) {
    var n = nodes[i];
    n.classList.remove('visible', 'running', 'done', 'ready', 'skipped');
    if (state === 'hidden') return;
    if (state === 'skipped') n.classList.add('visible', 'skipped');
    else if (state === 'ready') n.classList.add('visible', 'ready');
    else if (state === 'running') n.classList.add('visible', 'running');
    else if (state === 'done') n.classList.add('visible', 'done');
    var st = n.querySelector('.wn-status');
    if (st) st.textContent = text;
  }

  function render() {
    // nodes
    for (var i = 0; i < 10; i++) {
      if (elapsed < APPEAR[i]) { setNode(i, 'hidden', STATUS.appear[i]); continue; }
      var branchState = IS_BRANCH[i];
      if (branchState === 'skipped') { setNode(i, 'skipped', 'Skipped'); continue; }
      if (branchState === 'ready') { setNode(i, 'ready', 'Ready'); continue; }
      if (elapsed < DONE_AT_NODE[i]) {
        var text = elapsed >= RUN_AT[i] ? STATUS.run[i] : STATUS.appear[i];
        setNode(i, 'running', text);
      } else {
        setNode(i, 'done', STATUS.done[i]);
      }
    }

    // edges
    conns.forEach(function (conn, i) {
      var e = EDGES[i];
      var dp = Math.max(0, Math.min(1, (elapsed - e.draw) / DRAW));
      conn.path.style.strokeDashoffset = conn.length * (1 - dp);
      var drawing = dp > 0 && dp < 1;
      conn.path.classList.toggle('active', drawing && !e.dim);
      conn.path.classList.toggle('dim', !!e.dim && dp > 0);

      var showEp = dp > 0;
      conn.ep1.classList.toggle('on', showEp);
      conn.ep2.classList.toggle('on', showEp);

      if (e.packet != null) {
        var pp = Math.max(0, Math.min(1, (elapsed - e.packet) / TRAVEL));
        if (pp > 0 && pp < 1) {
          var pt = conn.path.getPointAtLength(pp * conn.length);
          conn.packet.setAttribute('cx', pt.x);
          conn.packet.setAttribute('cy', pt.y);
          conn.packet.setAttribute('visibility', 'visible');
        } else {
          conn.packet.setAttribute('visibility', 'hidden');
        }
      }
    });

    // progress + status
    bcFill.style.width = Math.min(100, (elapsed / TOTAL) * 100) + '%';
    var status = 'Completed ✓';
    for (var s = 0; s < STATUS_TEXT.length; s++) {
      if (elapsed >= STATUS_TEXT[s][0]) status = STATUS_TEXT[s][1];
    }
    bcStatus.textContent = status;

    doneBanner.classList.toggle('show', elapsed >= DONE_AT);

    if (elapsed >= TOTAL + HOLD) reset(true);
  }

  function frame(ts) {
    if (!playing) return;
    if (lastTs === null) lastTs = ts;
    elapsed += ts - lastTs;
    lastTs = ts;
    render();
    raf = requestAnimationFrame(frame);
  }

  function play() {
    if (playing) return;
    playing = true;
    started = true;
    lastTs = null;
    playOverlay.classList.add('hide');
    bcPlay.textContent = '⏸';
    raf = requestAnimationFrame(frame);
  }

  function pause() {
    playing = false;
    if (raf) cancelAnimationFrame(raf);
    bcPlay.textContent = '▶';
  }

  function reset(auto) {
    pause();
    elapsed = 0;
    render();
    if (auto) play();
  }

  function toggle() {
    if (playing) pause();
    else { if (elapsed >= TOTAL) reset(false); play(); }
  }

  function fullReset() {
    pause();
    elapsed = 0;
    started = true;
    playOverlay.classList.add('hide');
    render();
    play();
  }

  playOverlay.addEventListener('click', function () {
    if (elapsed >= TOTAL) reset(false);
    play();
  });
  bcPlay.addEventListener('click', toggle);
  bcReplay.addEventListener('click', fullReset);

  // --- reduced motion: static completed view ---
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduced) {
    for (var k = 0; k < 10; k++) {
      var bs = IS_BRANCH[k];
      if (bs === 'skipped') setNode(k, 'skipped', 'Skipped');
      else if (bs === 'ready') setNode(k, 'ready', 'Ready');
      else setNode(k, 'done', STATUS.done[k]);
    }
    conns.forEach(function (conn, i) {
      conn.path.style.strokeDashoffset = 0;
      conn.path.classList.toggle('dim', !!EDGES[i].dim);
      conn.ep1.classList.add('on');
      conn.ep2.classList.add('on');
    });
    playOverlay.classList.add('hide');
    doneBanner.classList.add('show');
    bcFill.style.width = '100%';
    bcStatus.textContent = 'Completed ✓';
    return;
  }

  // --- auto-start on scroll into view ---
  layout();
  window.addEventListener('resize', function () { layout(); render(); });

  var io = null;
  try { io = new IntersectionObserver(onView, { threshold: 0.25 }); } catch (e) { io = null; }
  function onView(entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting && !started) {
        started = true;
        play();
        if (io) io.unobserve(board);
      }
    });
  }
  if (io) io.observe(board);
  else play();
})();
