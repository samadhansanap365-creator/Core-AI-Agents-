/* ============================================================
   Core AI — embeddable chat widget
   Usage: <script src="https://YOUR-HOST/widget.js"></script>
          <script>CoreAIWidget.init({ chatbotId: 'YOUR_BOT_ID' });</script>
   ============================================================ */
(function () {
  'use strict';
  if (window.CoreAIWidget) return;

  // Resolve the API host from the script tag itself (cross-origin safe).
  var API = '';
  try {
    var s = document.currentScript;
    if (s && s.src) {
      var a = document.createElement('a');
      a.href = s.src;
      API = a.protocol + '//' + a.host;
    }
  } catch (e) { API = ''; }
  if (!API) API = window.location.origin;

  var CSS = [
    '.cw-root{--cw:#6366f1;--cwv:#8b5cf6;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;}',
    '.cw-launcher{position:fixed;right:22px;bottom:22px;z-index:2147483000;width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,var(--cw),var(--cwv));box-shadow:0 8px 24px rgba(79,70,229,.45);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .15s ease;}',
    '.cw-launcher:hover{transform:scale(1.06);}',
    '.cw-launcher svg{width:30px;height:30px;fill:#fff;}',
    '.cw-launcher .cw-badge{position:absolute;top:-2px;right:-2px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;border-radius:999px;min-width:18px;height:18px;display:none;align-items:center;justify-content:center;padding:0 5px;border:2px solid #fff;}',
    '.cw-launcher.left{right:auto;left:22px;}',
    '.cw-panel{position:fixed;right:22px;bottom:96px;z-index:2147483000;width:380px;max-width:calc(100vw - 32px);height:min(620px,calc(100vh - 120px));background:#fff;border-radius:18px;box-shadow:0 24px 60px rgba(15,23,42,.35);display:flex;flex-direction:column;overflow:hidden;opacity:0;transform:translateY(16px) scale(.98);pointer-events:none;transition:opacity .22s ease,transform .22s ease;}',
    '.cw-panel.open{opacity:1;transform:none;pointer-events:auto;}',
    '.cw-panel.left{right:auto;left:22px;}',
    '.cw-head{padding:16px 18px;color:#fff;background:linear-gradient(135deg,var(--cw),var(--cwv));display:flex;align-items:center;gap:12px;}',
    '.cw-avatar{width:42px;height:42px;border-radius:12px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;flex-shrink:0;}',
    '.cw-avatar img{width:100%;height:100%;border-radius:12px;object-fit:cover;}',
    '.cw-title{font-weight:700;font-size:15px;line-height:1.2;}',
    '.cw-status{font-size:12px;opacity:.9;display:flex;align-items:center;gap:5px;margin-top:2px;}',
    '.cw-status i{width:7px;height:7px;border-radius:50%;background:#4ade80;display:inline-block;}',
    '.cw-close{margin-left:auto;background:rgba(255,255,255,.18);border:none;color:#fff;width:30px;height:30px;border-radius:9px;font-size:16px;cursor:pointer;flex-shrink:0;}',
    '.cw-msgs{flex:1;overflow-y:auto;padding:16px;background:#f8f8ff;display:flex;flex-direction:column;gap:9px;}',
    '.cw-msg{max-width:82%;padding:10px 13px;border-radius:14px;font-size:14px;line-height:1.5;white-space:pre-wrap;word-wrap:break-word;}',
    '.cw-msg.bot{background:#fff;border:1px solid #e7e8f3;border-bottom-left-radius:4px;align-self:flex-start;box-shadow:0 1px 2px rgba(15,23,42,.05);}',
    '.cw-msg.user{background:linear-gradient(135deg,var(--cw),var(--cwv));color:#fff;border-bottom-right-radius:4px;align-self:flex-end;}',
    '.cw-msg.human{background:#f0fdf4;border:1px solid #bbf7d0;border-bottom-left-radius:4px;align-self:flex-start;color:#14532d;}',
    '.cw-msg .cw-who{font-size:11px;font-weight:700;opacity:.7;margin-bottom:3px;text-transform:uppercase;letter-spacing:.04em;}',
    '.cw-src{display:block;font-size:11px;opacity:.65;margin-top:6px;}',
    '.cw-typing{display:inline-flex;gap:4px;align-items:center;padding:12px 14px;}',
    '.cw-typing i{width:7px;height:7px;border-radius:50%;background:#a5b4fc;animation:cwb 1.2s infinite;}',
    '.cw-typing i:nth-child(2){animation-delay:.2s;}.cw-typing i:nth-child(3){animation-delay:.4s;}',
    '@keyframes cwb{0%,100%{opacity:.25}50%{opacity:1}}',
    '.cw-quick{display:flex;flex-wrap:wrap;gap:7px;padding:0 16px 12px;background:#f8f8ff;}',
    '.cw-quick button{background:#fff;border:1.5px solid var(--cw);color:var(--cw);border-radius:999px;padding:7px 13px;font-size:12.5px;font-weight:600;cursor:pointer;}',
    '.cw-quick button:hover{background:var(--cw);color:#fff;}',
    '.cw-lead{padding:0 16px 10px;background:#f8f8ff;}',
    '.cw-lead .cw-leadbox{background:#eef2ff;border:1px solid #c7d2fe;border-radius:12px;padding:11px 13px;font-size:13px;color:#3730a3;}',
    '.cw-lead .cw-leadbox .cw-leadrow{display:flex;gap:8px;margin-top:9px;}',
    '.cw-lead input{flex:1;border:1px solid #c7d2fe;border-radius:9px;padding:9px 11px;font-size:13.5px;outline:none;}',
    '.cw-lead button{background:var(--cw);border:none;color:#fff;border-radius:9px;padding:9px 13px;font-size:13px;font-weight:600;cursor:pointer;white-space:nowrap;}',
    '.cw-foot{border-top:1px solid #e7e8f3;padding:10px 12px;display:flex;align-items:flex-end;gap:8px;background:#fff;}',
    '.cw-foot textarea{flex:1;border:none;outline:none;resize:none;font-size:14px;line-height:1.4;max-height:120px;padding:6px 2px;font-family:inherit;}',
    '.cw-send{width:38px;height:38px;border-radius:11px;background:linear-gradient(135deg,var(--cw),var(--cwv));border:none;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;}',
    '.cw-send svg{width:18px;height:18px;fill:#fff;}',
    '.cw-human{width:100%;text-align:center;background:none;border:none;color:#64748b;font-size:12px;cursor:pointer;padding:6px 0 4px;text-decoration:underline;}',
    '.cw-human:hover{color:#4f46e5;}',
    '.cw-brand{text-align:center;font-size:11px;color:#94a3b8;padding:5px;background:#fff;}',
    '@media(max-width:520px){.cw-panel{right:12px;left:12px;bottom:88px;width:auto;height:calc(100vh - 108px);}}',
  ].join('');

  var state = {
    chatbotId: null, primaryColor: '#6366f1', name: 'Assistant', logo: '✦', position: 'bottom-right',
    welcome: '', placeholder: 'Type your question…', quickPrompts: [], visitorId: null, email: null,
    escalated: false, agentJoined: false, askedLead: false, polling: null, cfg: null,
  };

  function styleOnce() {
    if (document.getElementById('cw-style')) return;
    var el = document.createElement('style');
    el.id = 'cw-style';
    el.textContent = CSS;
    document.head.appendChild(el);
  }

  function el(html) {
    var d = document.createElement('div');
    d.innerHTML = html.trim();
    return d.firstChild;
  }

  function store() {
    try {
      return {
        get: function (k) { return localStorage.getItem('cw_' + state.chatbotId + '_' + k); },
        set: function (k, v) { localStorage.setItem('cw_' + state.chatbotId + '_' + k, v); },
        del: function (k) { localStorage.removeItem('cw_' + state.chatbotId + '_' + k); },
      };
    } catch (e) { return { get: function () { return null; }, set: function () {}, del: function () {} }; }
  }

  function api(path, opts) {
    opts = opts || {};
    opts.headers = opts.headers || {};
    if (opts.body && typeof opts.body !== 'string') {
      opts.body = JSON.stringify(opts.body);
      opts.headers['Content-Type'] = 'application/json';
    }
    return fetch(API + path, opts).then(function (r) { return r.json(); }).catch(function () {
      return { error: 'network', reply: 'Network error — please try again.' };
    });
  }

  var ui = {};
  function build() {
    styleOnce();
    if (document.getElementById('cw-root')) return;
    var root = el('<div class="cw-root" id="cw-root"></div>');
    var launcher = el(
      '<div class="cw-launcher" title="Chat with us">' +
      '<svg viewBox="0 0 24 24"><path d="M12 3C6.5 3 2 6.9 2 11.7c0 2.6 1.3 4.9 3.4 6.5-.1 1-.5 2.2-1.5 3.3 1.8-.1 3.2-.7 4.2-1.3 1.2.3 2.5.5 3.9.5 5.5 0 10-3.9 10-8.7S17.5 3 12 3z"/></svg>' +
      '<span class="cw-badge"></span></div>'
    );
    var panel = el(
      '<div class="cw-panel">' +
      '  <div class="cw-head">' +
      '    <div class="cw-avatar"></div>' +
      '    <div><div class="cw-title"></div><div class="cw-status"><i></i><span>Online — replies instantly</span></div></div>' +
      '    <button class="cw-close" aria-label="Close">✕</button>' +
      '  </div>' +
      '  <div class="cw-msgs"></div>' +
      '  <div class="cw-quick"></div>' +
      '  <div class="cw-lead"></div>' +
      '  <div class="cw-foot"><textarea rows="1" placeholder=""></textarea><button class="cw-send" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg></button></div>' +
      '  <div class="cw-human">Talk to a human</div>' +
      '  <div class="cw-brand">Powered by <b>Core AI</b></div>' +
      '</div>'
    );
    root.appendChild(launcher);
    root.appendChild(panel);
    document.body.appendChild(root);

    ui.root = root; ui.launcher = launcher; ui.panel = panel;
    ui.msgs = panel.querySelector('.cw-msgs');
    ui.quick = panel.querySelector('.cw-quick');
    ui.lead = panel.querySelector('.cw-lead');
    ui.ta = panel.querySelector('textarea');
    ui.send = panel.querySelector('.cw-send');
    ui.close = panel.querySelector('.cw-close');
    ui.human = panel.querySelector('.cw-human');
    ui.avatar = panel.querySelector('.cw-avatar');
    ui.title = panel.querySelector('.cw-title');

    launcher.addEventListener('click', function () { toggle(true); });
    ui.close.addEventListener('click', function () { toggle(false); });
    ui.send.addEventListener('click', send);
    ui.ta.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
    });
    ui.human.addEventListener('click', requestHuman);
    return root;
  }

  function toggle(force) {
    var open = force !== undefined ? force : !ui.panel.classList.contains('open');
    ui.panel.classList.toggle('open', open);
    ui.launcher.style.display = open ? 'none' : 'flex';
    document.body.classList.toggle('cw-open', open);
    if (open && !ui.msgs.children.length) renderWelcome();
    if (open) { setTimeout(function () { ui.ta.focus(); }, 100); }
    if (!open) stopPolling();
  }

  function applyBrand() {
    var c = state.primaryColor || '#6366f1';
    ui.root.style.setProperty('--cw', c);
    ui.title.textContent = state.name;
    ui.ta.placeholder = state.placeholder || 'Type your question…';
    ui.avatar.textContent = state.logo || '✦';
  }

  function bubble(text, who, meta) {
    var cls = who === 'user' ? 'user' : who === 'human' ? 'human' : 'bot';
    var inner = '';
    if (who === 'human') inner += '<span class="cw-who">Team</span>';
    inner += text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    if (meta && meta.sources && meta.sources.length) {
      inner += '<span class="cw-src">Based on: ' + meta.sources[0].title.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</span>';
    }
    var m = el('<div class="cw-msg ' + cls + '">' + inner + '</div>');
    ui.msgs.appendChild(m);
    scroll();
    return m;
  }

  function typing() {
    var t = el('<div class="cw-msg bot cw-typing"><i></i><i></i><i></i></div>');
    ui.msgs.appendChild(t);
    scroll();
    return t;
  }

  function scroll() { ui.msgs.scrollTop = ui.msgs.scrollHeight; }

  function renderWelcome() {
    var t = typing();
    setTimeout(function () {
      if (t.parentNode) t.parentNode.removeChild(t);
      bubble(state.welcome || 'Hi! Ask me anything.', 'bot');
      renderQuick();
      renderLeadPrompt(false);
    }, 500);
  }

  function renderQuick() {
    ui.quick.innerHTML = '';
    if (!state.quickPrompts || !state.quickPrompts.length) { ui.quick.style.display = 'none'; return; }
    ui.quick.style.display = 'flex';
    state.quickPrompts.forEach(function (q) {
      var b = document.createElement('button');
      b.textContent = q;
      b.addEventListener('click', function () { ui.ta.value = q; send(); });
      ui.quick.appendChild(b);
    });
  }

  function renderLeadPrompt(asked) {
    state.askedLead = asked || state.askedLead;
    if (state.email || state.escalated) { ui.lead.innerHTML = ''; return; }
    ui.lead.innerHTML = '';
    var box = el(
      '<div class="cw-leadbox">' + (asked ? 'Thanks! A follow-up on its way. 🙌' : 'Want us to follow up with you? Leave your email:') +
      (asked ? '' : '<div class="cw-leadrow"><input type="email" placeholder="you@company.com"><button>Save</button></div>') +
      '</div>'
    );
    ui.lead.appendChild(box);
    if (!asked) {
      var inp = box.querySelector('input');
      box.querySelector('button').addEventListener('click', function () { submitLead(inp.value); });
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') submitLead(inp.value); });
    }
  }

  function submitLead(email) {
    email = (email || '').trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { renderLeadPrompt(false); return; }
    api('/api/public/' + state.chatbotId + '/lead', { method: 'POST', body: { visitorId: state.visitorId, email: email } }).then(function (r) {
      if (r.ok !== false) {
        state.email = email;
        ui.lead.innerHTML = '';
        bubble('Thanks! Your email has been saved and the team will follow up. 🙌', 'bot');
      }
    });
  }

  function requestHuman() {
    if (state.escalated) { bubble('You are already in the queue — a human will reply right here shortly.', 'bot'); return; }
    state.escalated = true;
    api('/api/public/' + state.chatbotId + '/handoff', { method: 'POST', body: { visitorId: state.visitorId, email: state.email } }).then(function (r) {
      bubble(r.reply || "You're in the queue! A human will reply right here.", 'bot');
      renderLeadPrompt(true);
      startPolling();
    });
  }

  function send() {
    var text = ui.ta.value.trim();
    if (!text) return;
    ui.ta.value = '';
    ui.ta.style.height = 'auto';
    ui.quick.style.display = 'none';
    bubble(text, 'user');
    var t = typing();
    api('/api/public/' + state.chatbotId + '/chat', { method: 'POST', body: { visitorId: state.visitorId, message: text, email: state.email } })
      .then(function (r) {
        if (t.parentNode) t.parentNode.removeChild(t);
        bubble(r.reply || 'Hmm, something went wrong — please try again.', 'bot', { sources: r.sources });
        if (!state.askedLead && !state.email) renderLeadPrompt(false);
      });
  }

  function startPolling() {
    if (state.polling) return;
    state.polling = setInterval(function () {
      api('/api/public/' + state.chatbotId + '/poll?visitorId=' + encodeURIComponent(state.visitorId) + '&after=' + encodeURIComponent(state._lastPoll || '')).then(function (r) {
        if (r && r.messages && r.messages.length) {
          r.messages.forEach(function (m) { bubble(m.text, 'human'); });
          state._lastPoll = r.messages[r.messages.length - 1].ts;
        }
        state.agentJoined = r.agentJoined;
        if (r.resolved) { stopPolling(); state.escalated = false; bubble('This conversation is resolved. Thanks for reaching out! 👋', 'bot'); }
      });
    }, 3500);
  }
  function stopPolling() { if (state.polling) { clearInterval(state.polling); state.polling = null; } }

  function init(cfg) {
    cfg = cfg || {};
    state.chatbotId = cfg.chatbotId;
    state.primaryColor = cfg.primaryColor || '#6366f1';
    if (!state.chatbotId) return;
    build();
    var st = store();
    state.visitorId = st.get('visitorId');
    if (!state.visitorId) { state.visitorId = 'vis_' + Math.random().toString(36).slice(2) + Date.now().toString(36); st.set('visitorId', state.visitorId); }
    api('/api/public/' + state.chatbotId + '/config').then(function (c) {
      if (!c || c.error) return;
      state.cfg = c;
      state.name = c.name || state.name;
      state.logo = c.logo || state.logo;
      state.primaryColor = c.primaryColor || state.primaryColor;
      state.welcome = c.welcomeMessage || state.welcome;
      state.placeholder = c.placeholder || state.placeholder;
      state.quickPrompts = c.quickPrompts || [];
      if (c.position === 'bottom-left') { ui.launcher.classList.add('left'); ui.panel.classList.add('left'); }
      applyBrand();
    });
  }

  window.CoreAIWidget = { init: init, open: function () { if (ui.panel) toggle(true); }, close: function () { if (ui.panel) toggle(false); } };
})();
